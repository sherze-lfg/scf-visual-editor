<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Site-wide reusable component library and linked-instance resolver.
 *
 * Components store schema descriptors and visual structure, but never reuse
 * per-page node IDs or SCF field keys. Each inserted instance owns its own
 * immutable identities so content remains isolated between pages/instances.
 */
final class SCFVB_Components {
    private const OPTION_KEY = '_scfvb_components_v1';
    private const MAX_COMPONENTS = 100;
    private const MAX_NAME_LENGTH = 120;
    private static ?SCFVB_Components $instance = null;
    private ?array $cache = null;

    public static function instance(): SCFVB_Components {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function all(): array {
        if ( null !== $this->cache ) {
            return $this->cache;
        }
        $raw = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $raw ) ) {
            return array();
        }

        $out = array();
        foreach ( $raw as $id => $component ) {
            if ( ! is_array( $component ) ) {
                continue;
            }
            $clean = $this->normalize_component( $component );
            if ( $clean ) {
                $out[ $clean['id'] ] = $clean;
            }
        }
        uasort(
            $out,
            static function ( array $a, array $b ): int {
                return strcasecmp( $a['name'], $b['name'] );
            }
        );
        $this->cache = $out;
        return $out;
    }

    public function get( string $id ): ?array {
        $id = sanitize_key( $id );
        $all = $this->all();
        return $all[ $id ] ?? null;
    }

    public function create( string $name, array $node ) {
        $all = $this->all();
        if ( count( $all ) >= self::MAX_COMPONENTS ) {
            return new WP_Error( 'scfvb_component_limit', 'The component library is full.', array( 'status' => 400 ) );
        }

        $id = 'component_' . substr( md5( wp_generate_uuid4() ), 0, 12 );
        while ( isset( $all[ $id ] ) ) {
            $id = 'component_' . substr( md5( wp_generate_uuid4() ), 0, 12 );
        }

        $component = array(
            'id'       => $id,
            'name'     => $this->sanitize_name( $name ?: ( $node['name'] ?? 'Component' ) ),
            'revision' => 1,
            'rootType' => (string) ( $node['type'] ?? 'container' ),
            'template' => $this->template_from_node( $node ),
            'updated'  => time(),
        );

        if ( ! in_array( $component['rootType'], array( 'section', 'container' ), true ) ) {
            return new WP_Error( 'scfvb_component_root', 'Only Sections and Containers can be saved as components.', array( 'status' => 400 ) );
        }

        $all[ $id ] = $component;
        $saved = update_option( self::OPTION_KEY, $all, false );
        if ( ! $saved ) {
            $this->cache = null;
            return new WP_Error( 'scfvb_component_save_failed', 'The component could not be saved.', array( 'status' => 500 ) );
        }
        $this->cache = $all;
        return $component;
    }

    public function update( string $id, string $name, array $node ) {
        $id = sanitize_key( $id );
        $all = $this->all();
        if ( ! isset( $all[ $id ] ) ) {
            return new WP_Error( 'scfvb_component_not_found', 'Component not found.', array( 'status' => 404 ) );
        }
        if ( ! in_array( (string) ( $node['type'] ?? '' ), array( 'section', 'container' ), true ) ) {
            return new WP_Error( 'scfvb_component_root', 'Only Sections and Containers can be saved as components.', array( 'status' => 400 ) );
        }

        $existing = $all[ $id ];
        $component = array(
            'id'       => $id,
            'name'     => $this->sanitize_name( $name ?: $existing['name'] ),
            'revision' => max( 1, absint( $existing['revision'] ?? 1 ) + 1 ),
            'rootType' => (string) $node['type'],
            'template' => $this->template_from_node( $node ),
            'updated'  => time(),
        );
        $all[ $id ] = $component;
        $saved = update_option( self::OPTION_KEY, $all, false );
        if ( ! $saved ) {
            $this->cache = null;
            return new WP_Error( 'scfvb_component_save_failed', 'The component update could not be saved.', array( 'status' => 500 ) );
        }
        $this->cache = $all;
        return $component;
    }

    public function delete( string $id ): bool {
        $id = sanitize_key( $id );
        $all = $this->all();
        if ( ! isset( $all[ $id ] ) ) {
            return true;
        }
        unset( $all[ $id ] );
        $saved = update_option( self::OPTION_KEY, $all, false );
        if ( ! $saved ) {
            $this->cache = null;
            return false;
        }
        $this->cache = $all;
        return true;
    }

    /**
     * Resolve linked component instances against their current master template.
     * Missing/deleted masters intentionally leave the stored instance snapshot
     * untouched so deleting a library item never breaks existing pages.
     */
    public function resolve_layout( array $layout ): array {
        $layout = SCFVB_Layout::normalize( $layout );
        $library = $this->all();
        $layout['nodes'] = $this->resolve_nodes( $layout['nodes'] ?? array(), $library );
        return $layout;
    }

    private function resolve_nodes( array $nodes, array $library ): array {
        $out = array();
        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }
            $resolved = $node;
            $ref = isset( $node['component'] ) && is_array( $node['component'] ) ? $node['component'] : null;
            if ( $ref && ! empty( $ref['linked'] ) ) {
                $component_id = sanitize_key( $ref['id'] ?? '' );
                $instance_id = sanitize_key( $ref['instanceId'] ?? '' );
                if ( $component_id && $instance_id && isset( $library[ $component_id ] ) ) {
                    $component = $library[ $component_id ];
                    $resolved = $this->merge_template_into_instance(
                        $component['template'],
                        $node,
                        $instance_id,
                        $component_id,
                        absint( $component['revision'] )
                    );
                }
            }

            if ( ! empty( $resolved['children'] ) && is_array( $resolved['children'] ) ) {
                $resolved['children'] = $this->resolve_nodes( $resolved['children'], $library );
            }
            $out[] = $resolved;
        }
        return $out;
    }

    /**
     * Convert an instance tree to a portable component template. SCF keys and
     * node IDs are deliberately removed; templateKey is the stable bridge used
     * to match corresponding nodes when linked instances sync later.
     */
    public function template_from_node( array $node, ?array &$seen_template_keys = null ): array {
        if ( null === $seen_template_keys ) {
            $seen_template_keys = array();
        }
        $template = $node;
        unset( $template['id'], $template['component'] );
        $candidate = $this->valid_template_key( $node['templateKey'] ?? '' ) ? (string) $node['templateKey'] : '';
        if ( ! $candidate || isset( $seen_template_keys[ $candidate ] ) ) {
            $candidate = $this->new_template_key();
            while ( isset( $seen_template_keys[ $candidate ] ) ) {
                $candidate = $this->new_template_key();
            }
        }
        $seen_template_keys[ $candidate ] = true;
        $template['templateKey'] = $candidate;

        if ( isset( $template['bindings'] ) && is_array( $template['bindings'] ) ) {
            foreach ( $template['bindings'] as &$binding ) {
                if ( is_array( $binding ) ) {
                    unset( $binding['fieldKey'] );
                }
            }
            unset( $binding );
        }
        if ( isset( $template['group'] ) && is_array( $template['group'] ) ) {
            unset( $template['group']['fieldKey'] );
        }
        if ( isset( $template['repeater'] ) && is_array( $template['repeater'] ) ) {
            unset( $template['repeater']['fieldKey'] );
        }
        if ( isset( $template['flexible'] ) && is_array( $template['flexible'] ) ) {
            unset( $template['flexible']['fieldKey'] );
        }
        if ( isset( $template['flexLayout'] ) && is_array( $template['flexLayout'] ) ) {
            unset( $template['flexLayout']['key'] );
        }

        $children = array();
        foreach ( $node['children'] ?? array() as $child ) {
            if ( is_array( $child ) ) {
                $children[] = $this->template_from_node( $child, $seen_template_keys );
            }
        }
        $template['children'] = $children;
        return $template;
    }

    private function merge_template_into_instance( array $template, array $instance, string $instance_id, string $component_id, int $revision ): array {
        $template_key = $this->valid_template_key( $template['templateKey'] ?? '' )
            ? (string) $template['templateKey']
            : $this->new_template_key();

        $same_template = ( $instance['templateKey'] ?? '' ) === $template_key;
        $out = $template;
        $out['templateKey'] = $template_key;
        $out['id'] = $same_template && $this->valid_node_id( $instance['id'] ?? '' )
            ? (string) $instance['id']
            : $this->deterministic_node_id( $instance_id, $template_key );

        $template_bindings = isset( $template['bindings'] ) && is_array( $template['bindings'] ) ? $template['bindings'] : array();
        $instance_bindings = $same_template && isset( $instance['bindings'] ) && is_array( $instance['bindings'] ) ? $instance['bindings'] : array();
        $out['bindings'] = array();
        foreach ( $template_bindings as $binding_name => $binding ) {
            if ( ! is_array( $binding ) ) {
                continue;
            }
            $existing = isset( $instance_bindings[ $binding_name ] ) && is_array( $instance_bindings[ $binding_name ] )
                ? $instance_bindings[ $binding_name ]
                : null;
            if ( 'scf' === ( $binding['source'] ?? 'static' ) ) {
                if ( $existing && 'scf' === ( $existing['source'] ?? 'static' ) && ! empty( $existing['fieldKey'] ) ) {
                    // Keep the per-instance storage identity, but let the linked
                    // master continue to control schema presentation/settings
                    // (label, compatible field type, etc.). This avoids data
                    // moves while still making linked component edits propagate.
                    $merged = $binding;
                    $merged['source'] = 'scf';
                    $merged['fieldKey'] = $existing['fieldKey'];
                    $merged['fieldName'] = $existing['fieldName'] ?? ( $binding['fieldName'] ?? $binding_name );
                    $out['bindings'][ $binding_name ] = $merged;
                } else {
                    $new = $binding;
                    $new['source'] = 'scf';
                    $new['fieldKey'] = $this->deterministic_field_key( $instance_id, $template_key, $binding_name, 'field' );
                    $new['fieldName'] = $this->instance_field_name( $binding['fieldName'] ?? $binding_name, $instance_id );
                    $out['bindings'][ $binding_name ] = $new;
                }
            } else {
                $out['bindings'][ $binding_name ] = $binding;
            }
        }

        // Preserve per-instance fallback content for existing editable fields;
        // static content follows the master component.
        if ( $same_template && isset( $instance['content'] ) && is_array( $instance['content'] ) ) {
            foreach ( $out['bindings'] as $binding_name => $binding ) {
                if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
                    continue;
                }
                $content_key = $binding_name;
                if ( array_key_exists( $content_key, $instance['content'] ) ) {
                    $out['content'][ $content_key ] = $instance['content'][ $content_key ];
                }
                if ( 'image' === $content_key ) {
                    foreach ( array( 'imageId', 'imageUrl' ) as $image_key ) {
                        if ( array_key_exists( $image_key, $instance['content'] ) ) {
                            $out['content'][ $image_key ] = $instance['content'][ $image_key ];
                        }
                    }
                }
            }
        }

        $out = $this->merge_boundary( $out, $instance, $same_template, $instance_id, $template_key, 'group' );
        $out = $this->merge_boundary( $out, $instance, $same_template, $instance_id, $template_key, 'repeater' );
        $out = $this->merge_boundary( $out, $instance, $same_template, $instance_id, $template_key, 'flexible' );

        if ( ! empty( $out['flexLayout'] ) && is_array( $out['flexLayout'] ) ) {
            $existing_layout = $same_template && ! empty( $instance['flexLayout'] ) && is_array( $instance['flexLayout'] ) ? $instance['flexLayout'] : null;
            if ( $existing_layout && ! empty( $existing_layout['key'] ) && ! empty( $existing_layout['name'] ) ) {
                $master = $out['flexLayout'];
                $master['key'] = $existing_layout['key'];
                $master['name'] = $existing_layout['name'];
                $out['flexLayout'] = $master;
            } else {
                $out['flexLayout']['key'] = 'layout_scfvb_' . substr( md5( $instance_id . '|' . $template_key . '|flexLayout' ), 0, 16 );
            }
        }

        $instance_children = $same_template && isset( $instance['children'] ) && is_array( $instance['children'] ) ? $instance['children'] : array();
        $by_template_key = array();
        foreach ( $instance_children as $child ) {
            if ( is_array( $child ) && $this->valid_template_key( $child['templateKey'] ?? '' ) ) {
                $by_template_key[ $child['templateKey'] ] = $child;
            }
        }

        $children = array();
        foreach ( $template['children'] ?? array() as $template_child ) {
            if ( ! is_array( $template_child ) ) {
                continue;
            }
            $key = (string) ( $template_child['templateKey'] ?? '' );
            $existing_child = $key && isset( $by_template_key[ $key ] ) ? $by_template_key[ $key ] : array();
            $children[] = $this->merge_template_into_instance( $template_child, $existing_child, $instance_id, $component_id, $revision );
        }
        $out['children'] = $children;

        // Only the component root carries the library reference. Descendants use
        // templateKey for matching but are ordinary visual/schema nodes.
        if ( ( $instance['component']['instanceId'] ?? '' ) === $instance_id ) {
            $out['component'] = array(
                'id'         => $component_id,
                'linked'     => true,
                'instanceId' => $instance_id,
                'revision'   => $revision,
            );
        } else {
            unset( $out['component'] );
        }

        return $out;
    }

    private function merge_boundary( array $out, array $instance, bool $same_template, string $instance_id, string $template_key, string $kind ): array {
        if ( empty( $out[ $kind ]['enabled'] ) ) {
            unset( $out[ $kind ] );
            return $out;
        }

        $existing = $same_template && ! empty( $instance[ $kind ]['enabled'] ) && is_array( $instance[ $kind ] ) ? $instance[ $kind ] : null;
        if ( $existing && ! empty( $existing['fieldKey'] ) ) {
            // Boundary settings belong to the master; only the storage identity
            // is instance-owned. Repeater layout/min/max/button-label and Group
            // labels therefore propagate without renaming stored meta.
            $merged = $out[ $kind ];
            $merged['enabled'] = true;
            $merged['fieldKey'] = $existing['fieldKey'];
            $merged['fieldName'] = $existing['fieldName'] ?? ( $out[ $kind ]['fieldName'] ?? $kind );
            $out[ $kind ] = $merged;
            return $out;
        }

        $prefix = 'group' === $kind ? 'group' : ( 'flexible' === $kind ? 'flexible' : 'repeater' );
        $out[ $kind ]['enabled'] = true;
        $out[ $kind ]['fieldKey'] = $this->deterministic_field_key( $instance_id, $template_key, $kind, $prefix );
        $out[ $kind ]['fieldName'] = $this->instance_field_name( $out[ $kind ]['fieldName'] ?? $kind, $instance_id );
        return $out;
    }

    private function normalize_component( array $component ): ?array {
        $id = sanitize_key( $component['id'] ?? '' );
        if ( ! preg_match( '/^component_[a-z0-9_-]{6,64}$/', $id ) ) {
            return null;
        }
        $template = isset( $component['template'] ) && is_array( $component['template'] ) ? $component['template'] : null;
        if ( ! $template || ! in_array( (string) ( $template['type'] ?? '' ), array( 'section', 'container' ), true ) ) {
            return null;
        }
        return array(
            'id'       => $id,
            'name'     => $this->sanitize_name( $component['name'] ?? 'Component' ),
            'revision' => max( 1, absint( $component['revision'] ?? 1 ) ),
            'rootType' => (string) $template['type'],
            'template' => $template,
            'updated'  => absint( $component['updated'] ?? time() ),
        );
    }

    private function sanitize_name( string $name ): string {
        $name = sanitize_text_field( $name );
        if ( function_exists( 'mb_substr' ) ) {
            $name = mb_substr( $name, 0, self::MAX_NAME_LENGTH );
        } else {
            $name = substr( $name, 0, self::MAX_NAME_LENGTH );
        }
        return '' !== trim( $name ) ? trim( $name ) : 'Component';
    }

    private function new_template_key(): string {
        return 'tmpl_' . substr( md5( wp_generate_uuid4() ), 0, 16 );
    }

    private function valid_template_key( $value ): bool {
        return is_string( $value ) && (bool) preg_match( '/^tmpl_[a-z0-9_-]{6,64}$/', $value );
    }

    private function valid_node_id( $value ): bool {
        return is_string( $value ) && (bool) preg_match( '/^node_[a-z0-9_-]{4,64}$/', $value );
    }

    private function deterministic_node_id( string $instance_id, string $template_key ): string {
        return 'node_cmp_' . substr( md5( $instance_id . '|' . $template_key ), 0, 16 );
    }

    private function deterministic_field_key( string $instance_id, string $template_key, string $slot, string $kind ): string {
        $hash = substr( md5( $instance_id . '|' . $template_key . '|' . $slot ), 0, 16 );
        if ( 'group' === $kind ) {
            return 'field_scfvb_group_' . $hash;
        }
        if ( 'repeater' === $kind ) {
            return 'field_scfvb_repeater_' . $hash;
        }
        if ( 'flexible' === $kind ) {
            return 'field_scfvb_flexible_' . $hash;
        }
        return 'field_scfvb_' . $hash;
    }

    private function instance_field_name( string $base, string $instance_id ): string {
        $base = sanitize_key( $base );
        $base = '' !== $base ? $base : 'field';
        $suffix = '_' . substr( md5( $instance_id ), 0, 8 );
        $room = max( 1, 64 - strlen( $suffix ) );
        $base = rtrim( substr( $base, 0, $room ), '_' );
        return ( $base ?: 'field' ) . $suffix;
    }
}
