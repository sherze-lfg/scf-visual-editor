# SCF Visual Builder 0.4.1

A schema-aware visual page builder for WordPress integrated with Secure Custom Fields (SCF).

## 0.4.1 hardening

- Preserves quotes and backslashes in stored layout JSON and refuses to overwrite corrupt stored JSON silently.
- Detects physical ACF/SCF post-meta collisions between different logical Group paths.
- Validates field/storage-name lengths before data reaches WordPress metadata.
- Verifies and rolls back Group/field metadata moves before deleting source values, including a failed layout-meta write.
- Protects reactivated field identities from unrelated metadata.
- Caches Group reads on frontend render for better nested-Group efficiency.


## What 0.4 adds

- Convert any Container into an **SCF Group** without changing its visual layout.
- Editable descendants become SCF subfields; layout-only Containers remain transparent to the schema.
- Nest Group Containers to create nested SCF Groups.
- Group field keys remain immutable while Group labels/names can change.
- Canvas and Navigator show clear **GROUP** badges.
- Moving an editable element into, out of, or between Groups safely migrates the SCF/ACF-prefixed post-meta key when the layout is saved.
- Renaming or moving a Group migrates all affected descendant values after conflict preflight.
- Duplicate Group trees receive new Group identities and new descendant field identities.
- The frontend renderer resolves Group arrays through SCF and can fall back to prefixed raw post meta when SCF is unavailable.
- Existing 0.1–0.3 pages remain normal containers unless explicitly converted.


## What 0.3 adds

0.3 expands the visual layout engine while retaining the 0.2 SCF field/data model.

### CSS Grid

Sections and Containers can now switch between Flexbox and CSS Grid. Grid controls include:

- 1–6 fixed columns.
- Auto Fit and Auto Fill columns.
- Configurable minimum auto-column width.
- Automatic or 1–6 explicit rows.
- Separate column/row gaps.
- Row/column dense auto-flow options.
- Responsive Grid/Flex overrides at each breakpoint.

### Advanced sizing

All visual nodes now expose:

- Width / Min Width / Max Width.
- Height / Min Height / Max Height.
- Existing responsive units such as px, %, rem, em, vw, vh, vmin and vmax.

### Positioning

Nodes can use:

- Normal / Static.
- Relative.
- Absolute.
- Fixed.
- Sticky.
- Top / Right / Bottom / Left offsets.
- Z-index.

Absolute/fixed positioning is opt-in; normal page construction remains flow-based Flexbox/Grid.

### Overflow

Sections and Containers support Visible, Hidden, Auto, Scroll and Clip overflow behavior.

### Section and Container background images

Both Sections and Containers now have a responsive Background panel:

- None / Color / Image.
- WordPress Media Library image selection.
- Fallback background color.
- Cover / Contain / Auto sizing.
- Nine background positions.
- No Repeat / Repeat / Repeat X / Repeat Y.
- Scroll / Fixed / Local attachment.
- Different background images or settings can be assigned per responsive breakpoint.

Background images store both the WordPress attachment ID and URL. Frontend rendering prefers the attachment ID so media URLs can follow WordPress changes while retaining the URL as a fallback.

### Better Image elements

Image nodes now support:

- Object Fit: Cover, Contain, Fill, None, Scale Down.
- Object Position.
- Custom CSS aspect ratio such as `16 / 9`, `1 / 1`, or `auto`.
- The advanced min/max dimensions and positioning controls available to other nodes.

## Responsive modes

The four responsive modes remain:

- Desktop: 1199px+ (1920px default preview)
- Laptop / Small Desktop: 992–1198px
- Tablet: 768–991px
- Mobile: 320–767px (390px default preview)

Frontend cascade:

```css
/* Desktop: base styles */
@media (max-width: 1198px) { /* Laptop */ }
@media (max-width: 991px)  { /* Tablet */ }
@media (max-width: 767px)  { /* Mobile */ }
```

## Existing behavior retained

- Direct palette-to-canvas drag/drop.
- Canvas and Navigator reordering/re-parenting.
- Stable overlay drop targets (no layout-shifting drag zones).
- Resize and visual padding handles.
- Responsive preview widths and inherited overrides.
- Theme / Full Width / Builder Canvas page modes.
- Static or SCF-backed Heading, Text, Image and Button content.
- Text / Textarea / Image / URL SCF field generation.
- Stable `field_scfvb_*` field identities.
- Safe field-name migration and conflict checks.
- REST permission and hierarchy validation.
- Undo/redo and unsaved-change protection.

## Layout schema

0.4 uses layout schema version 4. Existing 0.1–0.3 layouts are normalized in memory and remain compatible; stored metadata is rewritten only when the user saves.

## Install / upgrade in LocalWP

1. WordPress Admin → Plugins → Add Plugin → Upload Plugin.
2. Upload `scf-visual-builder-v0.4.1.zip`.
3. Choose **Replace current with uploaded**.
4. Keep Secure Custom Fields active.
5. Hard-refresh the builder after upgrading if an old JavaScript asset is cached.

Builder layouts and SCF content are database data and are not removed when replacing plugin files.

## Next roadmap area

The next major phase is SCF Repeaters. Reusable components and additional SCF field types remain later milestones.


## v0.4

Container elements can be converted into SCF Groups. Editable descendants become subfields, nested Groups are supported, and values are migrated safely when schema boundaries move.
