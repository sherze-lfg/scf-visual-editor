# SCF Visual Builder 0.2.2

A schema-aware visual page builder for WordPress that integrates visual components with Secure Custom Fields (SCF).


## 0.2.2 hardening patch

0.2.2 is a stability pass over the 0.2 editor and SCF persistence layer.

- Prevents a completed save request from overwriting newer edits made while that request was still in flight.
- Makes canvas drop targeting ref-backed so a drop cannot use a stale React render target.
- Clears stale canvas drop targets when hovering an invalid region or leaving the canvas.
- Prevents root-level Section drops from activating merely because an invalid nested dragover bubbled to the canvas stage.
- Makes image selection one undoable edit instead of two separate history entries.
- Cleans up pointer gestures on `pointercancel` as well as `pointerup`.
- Preflights all SCF field renames before changing post meta, preventing partial migrations when a later rename conflicts.
- Detects destination SCF reference-meta conflicts during field renames.
- Preserves SCF-bound frontend content from raw post meta if SCF is temporarily unavailable, rather than exposing design-time placeholder text.
- Filters malformed scalar nodes/children during layout normalization so corrupt legacy meta cannot reach typed render paths.
- Restricts heading tag settings to `h1`–`h6` on save.
- Adds `noopener noreferrer` to the builder's new-tab View action and removes a duplicate editor CSS rule.

## 0.2.1 canvas drag/drop patch

0.2.1 replaces the original in-flow canvas drop lines with stable hit testing. Dragging an element no longer inserts/removes temporary DOM rows between every node, which could cause repeated reflow and canvas shaking.

- Drag palette elements directly over a valid Section or Container.
- Hover the center of a compatible container to drop inside it.
- Hover near the leading/trailing edge of an existing child to insert before/after it.
- Drop indicators use outlines/pseudo-elements and do not consume layout space.
- Existing canvas nodes can also be moved directly on the canvas.
- Invalid self/descendant targets are suppressed.
- Navigator drag/drop remains available for precision.

## What 0.2 adds

- Drag elements directly from the Elements panel onto compatible canvas elements.
- Reorder and re-parent nodes directly in the canvas; Navigator keeps explicit drop lines for precision.
- Hover/selection outlines and an on-canvas context toolbar.
- Width/height resize handles for non-section elements.
- On-canvas draggable padding handles for Sections and Containers.
- Improved Navigator with collapse/expand, inline rename, drag/reorder, duplicate and delete.
- Four responsive modes with cascading overrides:
  - Desktop: 1199px+ (1920px default preview)
  - Laptop / Small Desktop: 992–1198px
  - Tablet: 768–991px
  - Mobile: 320–767px (390px default preview)
- Editable preview width inside each responsive range.
- Scaled canvas preview so large desktop widths still fit inside WordPress admin.
- Responsive inheritance and a per-breakpoint “Reset overrides” action.
- Page layout modes:
  - Theme — builder stays in the theme content area.
  - Full Width — theme header/footer remain, builder content breaks out to viewport width.
  - Builder Canvas — bypasses the theme template and renders only the builder page while preserving `wp_head()`, `wp_body_open()`, `wp_footer()`, and the logged-in admin bar.
- Layout schema version 2 with automatic in-memory migration from 0.1 layouts.

## Responsive cascade

The generated frontend CSS uses Desktop as the base and cascades overrides downward:

```text
Desktop
  ↓
Laptop
  ↓
Tablet
  ↓
Mobile
```

The generated breakpoints are:

```css
/* Desktop: base styles */
@media (max-width: 1198px) { /* Laptop overrides */ }
@media (max-width: 991px)  { /* Tablet overrides */ }
@media (max-width: 767px)  { /* Mobile overrides */ }
```

This means a Laptop value is inherited by Tablet/Mobile unless a smaller breakpoint overrides it.

## 0.1 layout migration

0.1 used Desktop / Tablet / Mobile. When an older layout is loaded in 0.2, its old Tablet overrides are also copied into the new Laptop band in memory. This avoids an unstyled gap when upgrading. The stored layout is only rewritten when the user explicitly clicks Save.

## Existing SCF behavior retained

- Static or SCF-backed Heading, Text, Image and Button content.
- Text / Textarea / Image / URL SCF field generation.
- Stable `field_scfvb_*` identities.
- Field-name migration when a field is renamed.
- Duplicate field-name and field-key validation.
- REST permission checks and server-side layout validation.
- Empty SCF values stay empty rather than falling back to design placeholders.
- Textarea paragraph formatting is applied exactly once.

## Install / upgrade in LocalWP

1. WordPress Admin → Plugins → Add Plugin → Upload Plugin.
2. Upload `scf-visual-builder-v0.2.2.zip`.
3. Choose **Replace current with uploaded** when upgrading from 0.1.x.
4. Keep Secure Custom Fields active.
5. Open Pages → **Edit with Visual Builder**.

Your layouts and SCF content are stored in the WordPress database and are not removed by replacing the plugin files.

## Current scope

0.2 remains a Flexbox-first builder. CSS Grid, free/absolute positioning, advanced backgrounds, reusable components, Groups, Repeaters and Flexible Content remain later roadmap items.
