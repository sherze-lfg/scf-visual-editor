=== SCF Visual Builder ===
Contributors: openai
Tags: secure custom fields, scf, custom fields, page builder, visual builder
Requires at least: 6.5
Requires PHP: 8.0
Stable tag: 0.2.2
License: GPLv2 or later

A schema-aware visual page builder integrated with Secure Custom Fields.

== Description ==

SCF Visual Builder lets a designer visually create WordPress page layouts while binding editable content directly to Secure Custom Fields.

Version 0.2.2 hardens save concurrency, canvas drop targeting, SCF field-rename migration, malformed-layout handling, media undo history, and SCF-deactivation fallback behavior. Version 0.2.1 rebuilt direct canvas drag/drop using stable hit targets and non-layout-shifting visual indicators. Version 0.2 introduced resize handles, visual padding controls, responsive previews, four responsive modes, and Theme / Full Width / Builder Canvas page modes.

Responsive modes:

* Desktop: 1199px+ (1920px default preview)
* Laptop / Small Desktop: 992–1198px
* Tablet: 768–991px
* Mobile: 320–767px

== Installation ==

1. Install and activate Secure Custom Fields.
2. Upload and activate SCF Visual Builder.
3. Open Pages and choose "Edit with Visual Builder" for a page.

== Changelog ==

= 0.2.2 =
* Prevented save responses from overwriting newer local edits made while a save request is in flight.
* Hardened canvas drop targeting against stale targets and invalid nested dragover bubbling.
* Cleared drop state when leaving the canvas or hovering invalid regions.
* Made media selection one undoable history action.
* Added pointer-cancel cleanup for viewport, resize, and padding gestures.
* Preflighted all SCF field renames before mutating metadata to prevent partial migrations.
* Added destination SCF field-reference conflict detection during renames.
* Preserved SCF-bound content from raw post meta when SCF is temporarily unavailable.
* Filtered malformed scalar layout nodes/children during normalization.
* Restricted saved Heading tags to h1-h6 and added safer new-tab link attributes.

= 0.2.1 =
* Rebuilt canvas drag/drop so dragging no longer injects temporary drop-zone elements into the page layout.
* Added direct drop targeting on Sections, Containers and sibling elements in the visual canvas.
* Added stable inside/before/after drop indicators that do not change canvas geometry.
* Prevented invalid self/descendant drop targets while moving existing nodes.
* Disabled canvas height animation during an active drag to prevent visual feedback loops.
* Disabled native image dragging inside preview nodes so image elements move as builder nodes.
* Navigator drag/drop remains available for precise tree operations.

= 0.2.0 =
* Added four responsive modes and cascading frontend breakpoints.
* Added adjustable/scaled responsive canvas previews.
* Added palette-to-canvas drag and drop.
* Added drop-line reordering and re-parenting in canvas and Navigator.
* Added selection hover states, context toolbar, resize handles and visual padding handles.
* Added collapsible Navigator and inline node rename.
* Added Theme, Full Width and Builder Canvas page layout modes.
* Added schema v2 normalization and migration of 0.1 responsive layouts.

= 0.1.2 =
* Hardened renderer, REST validation, field identity rules and textarea rendering.
