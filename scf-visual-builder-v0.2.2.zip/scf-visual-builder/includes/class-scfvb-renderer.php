<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_Renderer {
    private const STYLE_MAP = array(
        'display' => 'display', 'width' => 'width', 'maxWidth' => 'max-width', 'height' => 'height', 'minHeight' => 'min-height',
        'paddingTop' => 'padding-top', 'paddingRight' => 'padding-right', 'paddingBottom' => 'padding-bottom', 'paddingLeft' => 'padding-left',
        'marginTop' => 'margin-top', 'marginRight' => 'margin-right', 'marginBottom' => 'margin-bottom', 'marginLeft' => 'margin-left',
        'flexDirection' => 'flex-direction', 'justifyContent' => 'justify-content', 'alignItems' => 'align-items', 'gap' => 'gap',
        'backgroundColor' => 'background-color', 'color' => 'color', 'fontSize' => 'font-size', 'fontWeight' => 'font-weight',
        'borderWidth' => 'border-width', 'borderColor' => 'border-color', 'borderRadius' => 'border-radius', 'textAlign' => 'text-align',
    );

    public function hooks(): void {
        add_filter( 'the_content', array( $this, 'filter_content' ), 20 );
        add_filter( 'template_include', array( $this, 'template_include' ), 99 );
        add_filter( 'body_class', array( $this, 'body_classes' ) );
    }

    public function template_include( string $template ): string {
        if ( is_admin() || ! is_singular( 'page' ) ) {
            return $template;
        }

        $post_id = get_queried_object_id();
        if ( ! $this->is_builder_page( $post_id ) ) {
            return $template;
        }

        $layout = $this->load_layout( $post_id );
        if ( 'canvas' !== SCFVB_Layout::page_layout( $layout ) ) {
            return $template;
        }

        $canvas_template = SCFVB_DIR . 'templates/builder-canvas.php';
        return file_exists( $canvas_template ) ? $canvas_template : $template;
    }

    public function body_classes( array $classes ): array {
        if ( ! is_singular( 'page' ) ) {
            return $classes;
        }

        $post_id = get_queried_object_id();
        if ( ! $this->is_builder_page( $post_id ) ) {
            return $classes;
        }

        $mode = SCFVB_Layout::page_layout( $this->load_layout( $post_id ) );
        $classes[] = 'scfvb-enabled-page';
        $classes[] = 'scfvb-page-layout-' . sanitize_html_class( $mode );
        return $classes;
    }

    public function filter_content( string $content ): string {
        if ( is_admin() || ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        $post_id = get_the_ID();
        if ( ! $this->is_builder_page( $post_id ) ) {
            return $content;
        }

        $layout = $this->load_layout( $post_id );
        if ( 'canvas' === SCFVB_Layout::page_layout( $layout ) || empty( $layout['nodes'] ) ) {
            return $content;
        }

        return $this->render_page_markup( $post_id, $layout );
    }

    public function render_page_markup( int $post_id, ?array $layout = null ): string {
        $layout = $layout ?: $this->load_layout( $post_id );
        if ( empty( $layout['nodes'] ) ) {
            return '';
        }

        $mode = SCFVB_Layout::page_layout( $layout );
        $html = '';
        foreach ( $layout['nodes'] as $node ) {
            $html .= $this->render_node( $node, $post_id );
        }

        $classes = array( 'scfvb-page', 'scfvb-layout-' . $mode );
        if ( 'fullwidth' === $mode ) {
            $classes[] = 'alignfull';
        }

        $css = $this->render_css( $layout );
        return '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">' . $html . '</div>' . ( $css ? '<style id="scfvb-page-styles">' . $css . '</style>' : '' );
    }

    private function is_builder_page( int $post_id ): bool {
        return $post_id > 0 && (bool) get_post_meta( $post_id, '_scfvb_enabled', true );
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, '_scfvb_layout', true );
        $decoded = is_string( $raw ) ? json_decode( $raw, true ) : null;
        return is_array( $decoded ) ? SCFVB_Layout::normalize( $decoded ) : SCFVB_Layout::default_layout();
    }

    private function node_class( array $node ): string {
        return 'scfvb-node-' . sanitize_html_class( preg_replace( '/^node_/', '', $node['id'] ?? '' ) );
    }

    private function render_node( array $node, int $post_id ): string {
        $class = 'scfvb-node ' . $this->node_class( $node );
        $type = $node['type'] ?? '';

        if ( 'section' === $type || 'container' === $type ) {
            $tag = 'section' === $type ? 'section' : 'div';
            $children = '';
            foreach ( $node['children'] ?? array() as $child ) {
                $children .= $this->render_node( $child, $post_id );
            }
            return '<' . $tag . ' class="' . esc_attr( $class ) . '">' . $children . '</' . $tag . '>';
        }

        if ( 'heading' === $type ) {
            $tag = $node['settings']['tag'] ?? 'h2';
            if ( ! in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
                $tag = 'h2';
            }
            $value = $this->resolve_value( $node, 'text', $post_id, $node['content']['text'] ?? '' );
            return '<' . $tag . ' class="' . esc_attr( $class ) . '">' . esc_html( (string) $value ) . '</' . $tag . '>';
        }

        if ( 'text' === $type ) {
            $value = $this->resolve_value( $node, 'text', $post_id, $node['content']['text'] ?? '' );
            // SCF textarea fields are registered with new_lines disabled. Escape as
            // text first, then let WordPress create paragraphs exactly once.
            return '<div class="' . esc_attr( $class ) . '">' . wpautop( esc_html( (string) $value ) ) . '</div>';
        }

        if ( 'image' === $type ) {
            $fallback_image = ! empty( $node['content']['imageId'] )
                ? (int) $node['content']['imageId']
                : ( $node['content']['imageUrl'] ?? '' );
            $value = $this->resolve_value( $node, 'image', $post_id, $fallback_image );
            $src = '';
            $alt = '';
            $attachment_id = 0;

            if ( is_array( $value ) ) {
                $src = $value['url'] ?? '';
                $alt = $value['alt'] ?? '';
                $attachment_id = absint( $value['ID'] ?? $value['id'] ?? 0 );
            } elseif ( is_numeric( $value ) && (int) $value > 0 ) {
                $attachment_id = (int) $value;
                $src = wp_get_attachment_image_url( $attachment_id, 'full' ) ?: '';
                $alt = (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
            } elseif ( is_string( $value ) ) {
                $src = $value;
            }

            if ( ! $src ) {
                return '';
            }

            if ( $attachment_id ) {
                $image = wp_get_attachment_image(
                    $attachment_id,
                    'full',
                    false,
                    array(
                        'class' => $class,
                        'alt'   => $alt,
                    )
                );
                if ( $image ) {
                    return $image;
                }
            }

            return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '">';
        }

        if ( 'button' === $type ) {
            $label = $this->resolve_value( $node, 'label', $post_id, $node['content']['label'] ?? 'Button' );
            $url = $this->resolve_value( $node, 'url', $post_id, $node['content']['url'] ?? '#' );
            return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( (string) $url ) . '">' . esc_html( (string) $label ) . '</a>';
        }

        return '';
    }

    /**
     * Once a binding is SCF-backed, SCF is the source of truth. An intentionally
     * empty field remains empty instead of falling back to design-time content.
     *
     * @param mixed $fallback Static builder value used when the node is not SCF-bound.
     * @return mixed
     */
    private function resolve_value( array $node, string $key, int $post_id, $fallback ) {
        $binding = $node['bindings'][ $key ] ?? array( 'source' => 'static' );
        if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
            return $fallback;
        }

        $selector = $binding['fieldKey'] ?? $binding['fieldName'] ?? '';
        if ( ! $selector ) {
            return '';
        }

        if ( function_exists( 'get_field' ) ) {
            return get_field( $selector, $post_id );
        }

        // Graceful degradation if SCF is temporarily unavailable: bound content
        // remains the source of truth instead of exposing design-time placeholders.
        $field_name = $binding['fieldName'] ?? '';
        if ( $field_name && metadata_exists( 'post', $post_id, $field_name ) ) {
            return get_post_meta( $post_id, $field_name, true );
        }

        return '';
    }

    private function render_css( array $layout ): string {
        $rules = array(
            'desktop' => '',
            'laptop'  => '',
            'tablet'  => '',
            'mobile'  => '',
        );

        $walk = function ( array $nodes ) use ( &$walk, &$rules ): void {
            foreach ( $nodes as $node ) {
                $selector = '.' . $this->node_class( $node );
                $styles = $node['styles'] ?? array();
                foreach ( array_keys( $rules ) as $breakpoint ) {
                    $declarations = $this->style_declarations( $styles[ $breakpoint ] ?? array() );
                    if ( $declarations ) {
                        $rules[ $breakpoint ] .= $selector . '{' . $declarations . '}';
                    }
                }

                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };

        $walk( $layout['nodes'] ?? array() );

        $css = '.scfvb-page{box-sizing:border-box;width:100%;max-width:none}.scfvb-page,.scfvb-page *{box-sizing:border-box}.scfvb-page img{max-width:100%;height:auto}.scfvb-page a.scfvb-node{display:inline-block;text-decoration:none}';
        $css .= '.scfvb-layout-fullwidth{position:relative;width:100vw;max-width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important}';
        $css .= 'body.scfvb-page-layout-canvas{margin:0}body.scfvb-page-layout-canvas .scfvb-page{width:100%;max-width:none;margin:0}';
        $css .= $rules['desktop'];

        // Max-width queries intentionally cascade downward. Laptop overrides are
        // inherited by Tablet/Mobile unless a smaller breakpoint overrides them.
        if ( $rules['laptop'] ) {
            $css .= '@media(max-width:1198px){' . $rules['laptop'] . '}';
        }
        if ( $rules['tablet'] ) {
            $css .= '@media(max-width:991px){' . $rules['tablet'] . '}';
        }
        if ( $rules['mobile'] ) {
            $css .= '@media(max-width:767px){' . $rules['mobile'] . '}';
        }
        return $css;
    }

    private function style_declarations( array $styles ): string {
        $out = '';
        foreach ( self::STYLE_MAP as $key => $property ) {
            if ( ! isset( $styles[ $key ] ) || '' === $styles[ $key ] ) {
                continue;
            }
            $value = $this->sanitize_css_value( $key, (string) $styles[ $key ] );
            if ( null !== $value ) {
                $out .= $property . ':' . $value . ';';
                if ( 'borderWidth' === $key && '0' !== $value && '0px' !== $value ) {
                    $out .= 'border-style:solid;';
                }
            }
        }
        return $out;
    }

    private function sanitize_css_value( string $key, string $value ): ?string {
        $value = trim( $value );

        $dimension_keys = array( 'width', 'maxWidth', 'height', 'minHeight', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'gap', 'fontSize', 'borderWidth', 'borderRadius' );
        if ( in_array( $key, $dimension_keys, true ) ) {
            if ( 'auto' === $value ) {
                return in_array( $key, array( 'width', 'maxWidth', 'height', 'minHeight', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft' ), true ) ? $value : null;
            }

            if ( '0' === $value ) {
                return $value;
            }

            if ( ! preg_match( '/^-?\d+(?:\.\d+)?(?:px|%|rem|em|vw|vh|vmin|vmax)$/', $value ) ) {
                return null;
            }

            $allows_negative = in_array( $key, array( 'marginTop', 'marginRight', 'marginBottom', 'marginLeft' ), true );
            if ( str_starts_with( $value, '-' ) && ! $allows_negative ) {
                return null;
            }

            return $value;
        }

        if ( in_array( $key, array( 'backgroundColor', 'color', 'borderColor' ), true ) ) {
            return preg_match( '/^#[0-9a-fA-F]{3,8}$/', $value ) || 'transparent' === $value ? $value : null;
        }

        $enums = array(
            'display'        => array( 'block', 'flex', 'inline-block', 'none' ),
            'flexDirection'  => array( 'row', 'column', 'row-reverse', 'column-reverse' ),
            'justifyContent' => array( 'flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly' ),
            'alignItems'     => array( 'stretch', 'flex-start', 'center', 'flex-end', 'baseline' ),
            'textAlign'      => array( 'left', 'center', 'right', 'justify' ),
        );
        if ( isset( $enums[ $key ] ) ) {
            return in_array( $value, $enums[ $key ], true ) ? $value : null;
        }

        if ( 'fontWeight' === $key ) {
            return preg_match( '/^[1-9]00$/', $value ) || in_array( $value, array( 'normal', 'bold' ), true ) ? $value : null;
        }

        return null;
    }
}
