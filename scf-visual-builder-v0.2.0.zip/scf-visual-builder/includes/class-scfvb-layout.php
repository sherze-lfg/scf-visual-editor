<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class SCFVB_Layout {
    public const VERSION = 2;
    public const PAGE_LAYOUTS = array( 'theme', 'fullwidth', 'canvas' );
    public const BREAKPOINTS = array( 'desktop', 'laptop', 'tablet', 'mobile' );

    public static function default_layout(): array {
        return array(
            'version'  => self::VERSION,
            'settings' => array(
                // Preserve the full-width behavior introduced in 0.1.1 for existing/new pages.
                'pageLayout' => 'fullwidth',
            ),
            'nodes'    => array(),
        );
    }

    /**
     * Normalize layouts loaded from storage. This is intentionally non-destructive:
     * it upgrades the in-memory shape without rewriting post meta until the user saves.
     */
    public static function normalize( array $layout ): array {
        $source_version = isset( $layout['version'] ) ? absint( $layout['version'] ) : 1;
        $page_layout = isset( $layout['settings']['pageLayout'] ) ? sanitize_key( $layout['settings']['pageLayout'] ) : 'fullwidth';
        if ( ! in_array( $page_layout, self::PAGE_LAYOUTS, true ) ) {
            $page_layout = 'fullwidth';
        }

        $nodes = isset( $layout['nodes'] ) && is_array( $layout['nodes'] ) ? $layout['nodes'] : array();
        foreach ( $nodes as &$node ) {
            self::normalize_node( $node, $source_version );
        }
        unset( $node );

        return array(
            'version'  => self::VERSION,
            'settings' => array( 'pageLayout' => $page_layout ),
            'nodes'    => $nodes,
        );
    }

    public static function page_layout( array $layout ): string {
        $layout = self::normalize( $layout );
        return $layout['settings']['pageLayout'];
    }

    private static function normalize_node( &$node, int $source_version ): void {
        if ( ! is_array( $node ) ) {
            return;
        }

        $styles = isset( $node['styles'] ) && is_array( $node['styles'] ) ? $node['styles'] : array();
        $desktop = isset( $styles['desktop'] ) && is_array( $styles['desktop'] ) ? $styles['desktop'] : array();
        $tablet  = isset( $styles['tablet'] ) && is_array( $styles['tablet'] ) ? $styles['tablet'] : array();
        $mobile  = isset( $styles['mobile'] ) && is_array( $styles['mobile'] ) ? $styles['mobile'] : array();

        // 0.1 had Desktop / Tablet / Mobile. Carry its Tablet overrides into the
        // new Laptop band as well so upgrading does not create an abrupt gap.
        if ( isset( $styles['laptop'] ) && is_array( $styles['laptop'] ) ) {
            $laptop = $styles['laptop'];
        } elseif ( $source_version < self::VERSION ) {
            $laptop = $tablet;
        } else {
            $laptop = array();
        }

        $node['styles'] = array(
            'desktop' => $desktop,
            'laptop'  => $laptop,
            'tablet'  => $tablet,
            'mobile'  => $mobile,
        );

        if ( ! isset( $node['children'] ) || ! is_array( $node['children'] ) ) {
            $node['children'] = array();
        }

        foreach ( $node['children'] as &$child ) {
            self::normalize_node( $child, $source_version );
        }
        unset( $child );
    }
}
