(function () {
    'use strict';

    const config = window.SCFVB_CONFIG || {};
    const { createElement: h, Fragment, useEffect, useMemo, useRef, useState } = wp.element;
    const { Button, Spinner, Notice } = wp.components;
    const apiFetch = wp.apiFetch;

    if (apiFetch && apiFetch.createNonceMiddleware && config.nonce) {
        apiFetch.use(apiFetch.createNonceMiddleware(config.nonce));
    }

    const CONTENT_TYPES = ['heading', 'text', 'image', 'button'];
    const CONTAINER_TYPES = ['section', 'container'];
    const BREAKPOINT_ORDER = ['desktop', 'laptop', 'tablet', 'mobile'];
    const BREAKPOINTS = config.breakpoints || {
        desktop: { label: 'Desktop', min: 1199, max: 2560, defaultWidth: 1920 },
        laptop: { label: 'Laptop', min: 992, max: 1198, defaultWidth: 1198 },
        tablet: { label: 'Tablet', min: 768, max: 991, defaultWidth: 991 },
        mobile: { label: 'Mobile', min: 320, max: 767, defaultWidth: 390 }
    };
    const LAYOUT_VERSION = Number(config.layoutVersion || 2);

    function token() {
        if (window.crypto && window.crypto.randomUUID) {
            return window.crypto.randomUUID().replace(/-/g, '').slice(0, 10);
        }
        return (Date.now().toString(36) + Math.random().toString(36).slice(2)).slice(0, 10);
    }

    function nodeId() { return 'node_' + token(); }
    function fieldKey() { return 'field_scfvb_' + token(); }

    function slugify(value) {
        const slug = String(value || '')
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '');
        return slug || 'field';
    }

    function clone(value) { return JSON.parse(JSON.stringify(value)); }

    function emptyStyles() {
        return { desktop: {}, laptop: {}, tablet: {}, mobile: {} };
    }

    function baseStyles(type) {
        const styles = emptyStyles();
        if (type === 'section') {
            styles.desktop = {
                display: 'flex', width: '100%', minHeight: '300px',
                paddingTop: '48px', paddingRight: '24px', paddingBottom: '48px', paddingLeft: '24px',
                flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'stretch', gap: '16px',
                backgroundColor: '#ffffff'
            };
        } else if (type === 'container') {
            styles.desktop = {
                display: 'flex', width: '100%', flexDirection: 'column',
                justifyContent: 'flex-start', alignItems: 'stretch', gap: '16px'
            };
        } else if (type === 'heading') {
            styles.desktop = {
                width: 'auto', marginTop: '0px', marginBottom: '8px',
                color: '#111111', fontSize: '48px', fontWeight: '700', textAlign: 'left'
            };
        } else if (type === 'text') {
            styles.desktop = {
                width: 'auto', marginTop: '0px', marginBottom: '8px',
                color: '#333333', fontSize: '18px', fontWeight: '400', textAlign: 'left'
            };
        } else if (type === 'image') {
            styles.desktop = { width: '100%', borderWidth: '0px', borderColor: '#dddddd', borderRadius: '0px' };
        } else if (type === 'button') {
            styles.desktop = {
                display: 'inline-block', width: 'auto',
                paddingTop: '12px', paddingRight: '20px', paddingBottom: '12px', paddingLeft: '20px',
                backgroundColor: '#111111', color: '#ffffff', fontSize: '16px', fontWeight: '600',
                borderWidth: '0px', borderColor: '#111111', borderRadius: '4px', textAlign: 'center'
            };
        }
        return styles;
    }

    function newNode(type) {
        const common = {
            id: nodeId(),
            type,
            name: type.charAt(0).toUpperCase() + type.slice(1),
            settings: {}, content: {}, bindings: {}, styles: baseStyles(type), children: []
        };

        if (type === 'heading') {
            common.settings.tag = 'h2';
            common.content.text = 'Your heading';
            common.bindings.text = { source: 'static', fieldType: 'text' };
        } else if (type === 'text') {
            common.content.text = 'Add your text here.';
            common.bindings.text = { source: 'static', fieldType: 'textarea' };
        } else if (type === 'image') {
            common.content.imageId = 0;
            common.content.imageUrl = '';
            common.bindings.image = { source: 'static', fieldType: 'image' };
        } else if (type === 'button') {
            common.content.label = 'Button';
            common.content.url = '#';
            common.bindings.label = { source: 'static', fieldType: 'text' };
            common.bindings.url = { source: 'static', fieldType: 'url' };
        }
        return common;
    }

    function normalizeLayout(raw) {
        const source = raw && typeof raw === 'object' ? clone(raw) : {};
        const sourceVersion = Number(source.version || 1);
        const layout = {
            version: LAYOUT_VERSION,
            settings: { pageLayout: (source.settings && source.settings.pageLayout) || 'fullwidth' },
            nodes: Array.isArray(source.nodes) ? source.nodes : []
        };
        if (!['theme', 'fullwidth', 'canvas'].includes(layout.settings.pageLayout)) {
            layout.settings.pageLayout = 'fullwidth';
        }

        function walk(node) {
            const styles = node.styles && typeof node.styles === 'object' ? node.styles : {};
            const oldTablet = styles.tablet && typeof styles.tablet === 'object' ? styles.tablet : {};
            node.styles = {
                desktop: styles.desktop && typeof styles.desktop === 'object' ? styles.desktop : {},
                laptop: styles.laptop && typeof styles.laptop === 'object'
                    ? styles.laptop
                    : (sourceVersion < 2 ? clone(oldTablet) : {}),
                tablet: oldTablet,
                mobile: styles.mobile && typeof styles.mobile === 'object' ? styles.mobile : {}
            };
            node.children = Array.isArray(node.children) ? node.children : [];
            node.children.forEach(walk);
        }
        layout.nodes.forEach(walk);
        return layout;
    }

    function findNode(nodes, id) {
        for (const node of nodes || []) {
            if (node.id === id) return node;
            const child = findNode(node.children || [], id);
            if (child) return child;
        }
        return null;
    }

    function findLocation(nodes, id, parentIdValue) {
        for (let i = 0; i < (nodes || []).length; i++) {
            const node = nodes[i];
            if (node.id === id) return { parentId: parentIdValue || null, index: i };
            const child = findLocation(node.children || [], id, node.id);
            if (child) return child;
        }
        return null;
    }

    function updateNode(nodes, id, updater) {
        return (nodes || []).map((node) => {
            if (node.id === id) return updater(clone(node));
            if (node.children && node.children.length) {
                return Object.assign({}, node, { children: updateNode(node.children, id, updater) });
            }
            return node;
        });
    }

    function removeNode(nodes, id) {
        let removed = null;
        const next = [];
        for (const node of nodes || []) {
            if (node.id === id) {
                removed = node;
                continue;
            }
            if (node.children && node.children.length) {
                const result = removeNode(node.children, id);
                if (result.removed) {
                    removed = result.removed;
                    next.push(Object.assign({}, node, { children: result.nodes }));
                    continue;
                }
            }
            next.push(node);
        }
        return { nodes: next, removed };
    }

    function insertAt(nodes, parentIdValue, index, child) {
        if (!parentIdValue) {
            const copy = [...nodes];
            const safeIndex = Math.max(0, Math.min(Number(index), copy.length));
            copy.splice(safeIndex, 0, child);
            return copy;
        }
        return updateNode(nodes, parentIdValue, (node) => {
            const children = [...(node.children || [])];
            const safeIndex = Math.max(0, Math.min(Number(index), children.length));
            children.splice(safeIndex, 0, child);
            node.children = children;
            return node;
        });
    }

    function isDescendant(node, id) {
        for (const child of node.children || []) {
            if (child.id === id || isDescendant(child, id)) return true;
        }
        return false;
    }

    function canContain(parentType, childType) {
        if (!parentType) return childType === 'section';
        if (parentType === 'section') return childType === 'container';
        if (parentType === 'container') return childType === 'container' || CONTENT_TYPES.includes(childType);
        return false;
    }

    function moveSibling(nodes, id, delta) {
        const copy = clone(nodes);
        function walk(list) {
            const index = list.findIndex((n) => n.id === id);
            if (index >= 0) {
                const target = index + delta;
                if (target >= 0 && target < list.length) {
                    const temp = list[index];
                    list[index] = list[target];
                    list[target] = temp;
                }
                return true;
            }
            for (const node of list) {
                if (walk(node.children || [])) return true;
            }
            return false;
        }
        walk(copy);
        return copy;
    }

    function duplicateNodeTree(node) {
        const copy = clone(node);
        function remap(item) {
            item.id = nodeId();
            item.name = item.name + ' Copy';
            Object.keys(item.bindings || {}).forEach((key) => {
                const binding = item.bindings[key];
                if (binding.fieldKey) binding.fieldKey = fieldKey();
                if (binding.fieldName) binding.fieldName = binding.fieldName + '_copy_' + token().slice(0, 4);
            });
            (item.children || []).forEach(remap);
        }
        remap(copy);
        return copy;
    }

    function effectiveStyles(node, breakpoint) {
        const orderIndex = BREAKPOINT_ORDER.indexOf(breakpoint);
        const out = {};
        BREAKPOINT_ORDER.slice(0, Math.max(0, orderIndex) + 1).forEach((name) => {
            Object.assign(out, (node.styles && node.styles[name]) || {});
        });
        return out;
    }

    function toReactStyle(styles) {
        const style = Object.assign({}, styles || {});
        if (style.borderWidth && style.borderWidth !== '0' && style.borderWidth !== '0px') {
            style.borderStyle = 'solid';
        }
        return style;
    }

    function pxNumber(value, fallback) {
        const match = String(value || '').trim().match(/^(-?\d+(?:\.\d+)?)px$/);
        return match ? Number(match[1]) : Number(fallback || 0);
    }

    function clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }

    function useHistoryState(initialValue) {
        const [history, setHistory] = useState({ past: [], present: initialValue, future: [] });

        function reset(value) { setHistory({ past: [], present: value, future: [] }); }
        function commit(valueOrFn) {
            setHistory((current) => {
                const next = typeof valueOrFn === 'function' ? valueOrFn(current.present) : valueOrFn;
                if (next === current.present || JSON.stringify(next) === JSON.stringify(current.present)) return current;
                return { past: [...current.past, current.present].slice(-60), present: next, future: [] };
            });
        }
        function replace(valueOrFn) {
            setHistory((current) => {
                const next = typeof valueOrFn === 'function' ? valueOrFn(current.present) : valueOrFn;
                return Object.assign({}, current, { present: next, future: [] });
            });
        }
        function checkpoint(base) {
            setHistory((current) => {
                if (!base || JSON.stringify(base) === JSON.stringify(current.present)) return current;
                return { past: [...current.past, base].slice(-60), present: current.present, future: [] };
            });
        }
        function undo() {
            setHistory((current) => {
                if (!current.past.length) return current;
                const previous = current.past[current.past.length - 1];
                return { past: current.past.slice(0, -1), present: previous, future: [current.present, ...current.future] };
            });
        }
        function redo() {
            setHistory((current) => {
                if (!current.future.length) return current;
                const next = current.future[0];
                return { past: [...current.past, current.present].slice(-60), present: next, future: current.future.slice(1) };
            });
        }
        return { history, reset, commit, replace, checkpoint, undo, redo };
    }

    function LabeledInput(props) {
        return h('label', { className: 'scfvb-field' },
            h('span', null, props.label),
            h('input', {
                type: props.type || 'text', value: props.value == null ? '' : props.value,
                min: props.min, max: props.max, step: props.step,
                placeholder: props.placeholder || '',
                onChange: (event) => props.onChange(event.target.value)
            })
        );
    }

    function LabeledSelect(props) {
        return h('label', { className: 'scfvb-field' },
            h('span', null, props.label),
            h('select', { value: props.value, onChange: (event) => props.onChange(event.target.value) },
                props.options.map((option) => {
                    const value = typeof option === 'string' ? option : option.value;
                    const label = typeof option === 'string' ? option : option.label;
                    return h('option', { key: value, value }, label);
                })
            )
        );
    }

    function SectionTitle(props) {
        return h('div', { className: 'scfvb-inspector-title-row' },
            h('h3', { className: 'scfvb-inspector-title' }, props.children),
            props.action || null
        );
    }

    function App() {
        const initial = normalizeLayout({ version: LAYOUT_VERSION, settings: { pageLayout: 'fullwidth' }, nodes: [] });
        const { history, reset, commit, replace, checkpoint, undo, redo } = useHistoryState(initial);
        const [selectedId, setSelectedId] = useState(null);
        const [breakpoint, setBreakpoint] = useState('desktop');
        const [previewWidths, setPreviewWidths] = useState(() => {
            const result = {};
            BREAKPOINT_ORDER.forEach((key) => { result[key] = Number(BREAKPOINTS[key].defaultWidth); });
            return result;
        });
        const [loading, setLoading] = useState(true);
        const [saving, setSaving] = useState(false);
        const [notice, setNotice] = useState(null);
        const [savedSnapshot, setSavedSnapshot] = useState(JSON.stringify(initial));
        const [dragging, setDragging] = useState(null);
        const gestureBase = useRef(null);

        const layout = history.present;
        const selected = useMemo(() => selectedId ? findNode(layout.nodes, selectedId) : null, [layout, selectedId]);
        const dirty = JSON.stringify(layout) !== savedSnapshot;
        const previewWidth = previewWidths[breakpoint];

        useEffect(() => {
            apiFetch({ path: config.restPath }).then((response) => {
                const loaded = normalizeLayout(response && response.layout ? response.layout : initial);
                reset(loaded);
                setSavedSnapshot(JSON.stringify(loaded));
                setLoading(false);
            }).catch((error) => {
                setNotice({ status: 'error', message: error.message || 'Could not load the layout.' });
                setLoading(false);
            });
        }, []);

        useEffect(() => {
            function keydown(event) {
                const activeTag = document.activeElement && document.activeElement.tagName;
                if (['INPUT', 'TEXTAREA', 'SELECT'].includes(activeTag)) return;
                const meta = event.ctrlKey || event.metaKey;
                const key = event.key.toLowerCase();
                if (meta && key === 'z') {
                    event.preventDefault();
                    if (event.shiftKey) redo(); else undo();
                } else if (meta && key === 'y') {
                    event.preventDefault();
                    redo();
                } else if ((event.key === 'Delete' || event.key === 'Backspace') && selectedId) {
                    event.preventDefault();
                    deleteNode(selectedId);
                }
            }
            window.addEventListener('keydown', keydown);
            return () => window.removeEventListener('keydown', keydown);
        });

        useEffect(() => {
            if (selectedId && !findNode(layout.nodes, selectedId)) setSelectedId(null);
        }, [layout, selectedId]);

        useEffect(() => {
            function beforeUnload(event) {
                if (!dirty) return;
                event.preventDefault();
                event.returnValue = '';
            }
            window.addEventListener('beforeunload', beforeUnload);
            return () => window.removeEventListener('beforeunload', beforeUnload);
        }, [dirty]);

        function showMessage(message, status) { setNotice({ message, status: status || 'info' }); }

        function updateNodeById(id, updater, transient) {
            const fn = transient ? replace : commit;
            fn((current) => Object.assign({}, current, { nodes: updateNode(current.nodes, id, updater) }));
        }

        function updateSelected(updater) {
            if (selectedId) updateNodeById(selectedId, updater, false);
        }

        function patchStyleById(id, key, value, transient) {
            updateNodeById(id, (copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                copy.styles[breakpoint] = Object.assign({}, copy.styles[breakpoint] || {}, { [key]: value });
                return copy;
            }, transient);
        }

        function beginGesture() {
            if (!gestureBase.current) gestureBase.current = clone(history.present);
        }

        function endGesture() {
            const base = gestureBase.current;
            gestureBase.current = null;
            checkpoint(base);
        }

        function parentType(parentIdValue) {
            if (!parentIdValue) return null;
            const parent = findNode(layout.nodes, parentIdValue);
            return parent ? parent.type : null;
        }

        function addAt(type, parentIdValue, index) {
            if (!canContain(parentType(parentIdValue), type)) {
                showMessage('That element cannot be placed there.', 'warning');
                return;
            }
            const child = newNode(type);
            commit((current) => Object.assign({}, current, { nodes: insertAt(current.nodes, parentIdValue, index, child) }));
            setSelectedId(child.id);
        }

        function addElement(type) {
            if (type === 'section') {
                addAt(type, null, layout.nodes.length);
                return;
            }
            if (!selected) {
                showMessage(type === 'container' ? 'Select a Section or Container first.' : 'Select a Container first.', 'warning');
                return;
            }
            if (!canContain(selected.type, type)) {
                showMessage(type === 'container' ? 'Containers can be placed inside Sections or Containers.' : 'Content elements must be placed inside a Container.', 'warning');
                return;
            }
            addAt(type, selected.id, (selected.children || []).length);
        }

        function moveNodeTo(id, targetParentId, targetIndex) {
            const dragged = findNode(layout.nodes, id);
            if (!dragged) return;
            const targetParent = targetParentId ? findNode(layout.nodes, targetParentId) : null;
            if (targetParent && (targetParent.id === id || isDescendant(dragged, targetParent.id))) {
                showMessage('An element cannot be moved inside itself.', 'warning');
                return;
            }
            if (!canContain(targetParent ? targetParent.type : null, dragged.type)) {
                showMessage('That element cannot be placed there.', 'warning');
                return;
            }

            const oldLocation = findLocation(layout.nodes, id, null);
            let adjustedIndex = Number(targetIndex);
            if (oldLocation && oldLocation.parentId === targetParentId && oldLocation.index < adjustedIndex) adjustedIndex -= 1;

            commit((current) => {
                const result = removeNode(current.nodes, id);
                if (!result.removed) return current;
                return Object.assign({}, current, { nodes: insertAt(result.nodes, targetParentId, adjustedIndex, result.removed) });
            });
            setSelectedId(id);
        }

        function deleteNode(id) {
            if (!findNode(layout.nodes, id)) return;
            commit((current) => Object.assign({}, current, { nodes: removeNode(current.nodes, id).nodes }));
            if (selectedId === id) setSelectedId(null);
        }

        function duplicateNode(id) {
            const node = findNode(layout.nodes, id);
            const location = findLocation(layout.nodes, id, null);
            if (!node || !location) return;
            const copy = duplicateNodeTree(node);
            commit((current) => Object.assign({}, current, {
                nodes: insertAt(current.nodes, location.parentId, location.index + 1, copy)
            }));
            setSelectedId(copy.id);
        }

        function moveNodeSibling(id, delta) {
            if (!findNode(layout.nodes, id)) return;
            commit((current) => Object.assign({}, current, { nodes: moveSibling(current.nodes, id, delta) }));
        }

        function renameNode(id, name) {
            updateNodeById(id, (copy) => { copy.name = String(name || '').trim() || copy.type; return copy; }, false);
        }

        function handleDrop(event, targetParentId, targetIndex) {
            event.preventDefault();
            event.stopPropagation();
            let newType = event.dataTransfer.getData('application/x-scfvb-new') || '';
            let existingId = event.dataTransfer.getData('application/x-scfvb-node') || '';
            if (!newType && !existingId && dragging) {
                if (dragging.kind === 'new') newType = dragging.type;
                if (dragging.kind === 'node') existingId = dragging.id;
            }
            if (newType) addAt(newType, targetParentId, targetIndex);
            else if (existingId) moveNodeTo(existingId, targetParentId, targetIndex);
            setDragging(null);
        }

        function currentDragType() {
            if (!dragging) return '';
            if (dragging.kind === 'new') return dragging.type;
            const node = findNode(layout.nodes, dragging.id);
            return node ? node.type : '';
        }

        function canDropOn(parentIdValue) {
            return canContain(parentType(parentIdValue), currentDragType());
        }

        function save() {
            setSaving(true);
            setNotice(null);
            apiFetch({ path: config.restPath, method: 'PUT', data: { layout } }).then((response) => {
                const saved = normalizeLayout(response && response.layout ? response.layout : layout);
                reset(saved);
                setSavedSnapshot(JSON.stringify(saved));
                setSaving(false);
                setNotice({ status: 'success', message: 'Layout saved.' });
            }).catch((error) => {
                setSaving(false);
                setNotice({ status: 'error', message: error.message || 'Could not save the layout.' });
            });
        }

        function setPageLayout(value) {
            commit((current) => Object.assign({}, current, {
                settings: Object.assign({}, current.settings || {}, { pageLayout: value })
            }));
        }

        function updatePreviewWidth(value) {
            const meta = BREAKPOINTS[breakpoint];
            const number = clamp(parseInt(value || meta.defaultWidth, 10), Number(meta.min), Number(meta.max));
            setPreviewWidths((current) => Object.assign({}, current, { [breakpoint]: number }));
        }

        if (loading) return h('div', { className: 'scfvb-loading' }, h(Spinner), 'Loading visual builder…');

        return h('div', { className: 'scfvb-app' },
            h(Toolbar, {
                breakpoint, setBreakpoint, previewWidth, updatePreviewWidth,
                pageLayout: (layout.settings && layout.settings.pageLayout) || 'fullwidth', setPageLayout,
                canUndo: history.past.length > 0, canRedo: history.future.length > 0, undo, redo,
                save, saving, dirty
            }),
            notice && h('div', { className: 'scfvb-notice-wrap' },
                h(Notice, { status: notice.status, isDismissible: true, onRemove: () => setNotice(null) }, notice.message)
            ),
            h('div', { className: 'scfvb-workspace' },
                h(ElementPanel, { addElement, setDragging }),
                h('main', { className: 'scfvb-center' },
                    h(Canvas, {
                        layout, breakpoint, previewWidth, updatePreviewWidth, selectedId, setSelectedId,
                        dragging, setDragging, canDropOn, handleDrop,
                        moveNodeSibling, duplicateNode, deleteNode,
                        beginGesture, endGesture, patchStyleById
                    }),
                    h(Navigator, {
                        nodes: layout.nodes, selectedId, setSelectedId, dragging, setDragging,
                        canDropOn, handleDrop, moveNodeSibling, duplicateNode, deleteNode, renameNode
                    })
                ),
                h(Inspector, {
                    node: selected, breakpoint, updateSelected, scfAvailable: config.scfAvailable,
                    pageLayout: (layout.settings && layout.settings.pageLayout) || 'fullwidth', setPageLayout
                })
            )
        );
    }

    function Toolbar(props) {
        const meta = BREAKPOINTS[props.breakpoint];
        return h('header', { className: 'scfvb-toolbar' },
            h('div', { className: 'scfvb-toolbar-left' },
                h('a', { href: config.pagesUrl, className: 'scfvb-link' }, '← Pages'),
                h('strong', null, config.postTitle || 'Page'),
                props.dirty && h('span', { className: 'scfvb-dirty' }, 'Unsaved'),
                h('label', { className: 'scfvb-toolbar-select' },
                    h('span', null, 'Layout'),
                    h('select', { value: props.pageLayout, onChange: (e) => props.setPageLayout(e.target.value) },
                        h('option', { value: 'theme' }, 'Theme'),
                        h('option', { value: 'fullwidth' }, 'Full Width'),
                        h('option', { value: 'canvas' }, 'Builder Canvas')
                    )
                )
            ),
            h('div', { className: 'scfvb-toolbar-center' },
                h('div', { className: 'scfvb-breakpoints' },
                    BREAKPOINT_ORDER.map((key) => h('button', {
                        key, type: 'button', className: props.breakpoint === key ? 'is-active' : '',
                        onClick: () => props.setBreakpoint(key),
                        title: breakpointRangeLabel(key)
                    }, BREAKPOINTS[key].label))
                ),
                h('label', { className: 'scfvb-preview-width' },
                    h('input', {
                        type: 'number', value: props.previewWidth, min: meta.min, max: meta.max,
                        onChange: (e) => props.updatePreviewWidth(e.target.value)
                    }),
                    h('span', null, 'px')
                ),
                h('span', { className: 'scfvb-range-label' }, breakpointRangeLabel(props.breakpoint))
            ),
            h('div', { className: 'scfvb-toolbar-right' },
                h(Button, { variant: 'secondary', disabled: !props.canUndo, onClick: props.undo }, 'Undo'),
                h(Button, { variant: 'secondary', disabled: !props.canRedo, onClick: props.redo }, 'Redo'),
                h(Button, { variant: 'secondary', href: config.editUrl }, 'Edit SCF Content'),
                h(Button, { variant: 'secondary', href: config.viewUrl, target: '_blank' }, 'View'),
                h(Button, { variant: 'primary', isBusy: props.saving, disabled: props.saving, onClick: props.save }, props.saving ? 'Saving…' : 'Save')
            )
        );
    }

    function breakpointRangeLabel(key) {
        const meta = BREAKPOINTS[key];
        if (key === 'desktop') return meta.min + 'px+';
        return meta.min + '–' + meta.max + 'px';
    }

    function ElementPanel(props) {
        function item(type, label) {
            return h('button', {
                type: 'button', draggable: true,
                onClick: () => props.addElement(type),
                onDragStart: (event) => {
                    event.dataTransfer.effectAllowed = 'copy';
                    event.dataTransfer.setData('application/x-scfvb-new', type);
                    event.dataTransfer.setData('text/plain', type);
                    props.setDragging({ kind: 'new', type });
                },
                onDragEnd: () => props.setDragging(null)
            }, h('span', { className: 'scfvb-element-icon' }, elementIcon(type)), h('span', null, label));
        }
        return h('aside', { className: 'scfvb-sidebar scfvb-elements' },
            h('h2', null, 'Elements'),
            h('div', { className: 'scfvb-palette-group' },
                h('h3', null, 'Layout'), item('section', 'Section'), item('container', 'Container')
            ),
            h('div', { className: 'scfvb-palette-group' },
                h('h3', null, 'Content'), item('heading', 'Heading'), item('text', 'Text'), item('image', 'Image'), item('button', 'Button')
            ),
            h('p', { className: 'description' }, 'Drag an element into a valid drop line, or click it to add to the selected container.')
        );
    }

    function elementIcon(type) {
        return { section: 'S', container: '□', heading: 'H', text: 'T', image: 'I', button: 'B' }[type] || '•';
    }

    function Canvas(props) {
        const hostRef = useRef(null);
        const stageRef = useRef(null);
        const [hostWidth, setHostWidth] = useState(900);
        const [stageHeight, setStageHeight] = useState(640);

        useEffect(() => {
            if (!hostRef.current || !window.ResizeObserver) return;
            const observer = new ResizeObserver((entries) => {
                const width = entries[0] && entries[0].contentRect ? entries[0].contentRect.width : hostRef.current.clientWidth;
                setHostWidth(width || 900);
            });
            observer.observe(hostRef.current);
            return () => observer.disconnect();
        }, []);

        useEffect(() => {
            if (!stageRef.current || !window.ResizeObserver) return;
            const observer = new ResizeObserver(() => setStageHeight(Math.max(640, stageRef.current.offsetHeight || 640)));
            observer.observe(stageRef.current);
            return () => observer.disconnect();
        }, []);

        const available = Math.max(320, hostWidth - 48);
        const scale = Math.min(1, Math.max(0.45, available / props.previewWidth));
        const canRootDrop = props.dragging && props.canDropOn(null);

        return h('section', { className: 'scfvb-canvas-shell' },
            h('div', { className: 'scfvb-canvas-header' },
                h('strong', null, 'Canvas'),
                h('span', null, BREAKPOINTS[props.breakpoint].label + ' · ' + props.previewWidth + 'px · ' + Math.round(scale * 100) + '%')
            ),
            h('div', { className: 'scfvb-canvas-host', ref: hostRef },
                h('div', { className: 'scfvb-canvas-scaled-wrap', style: { height: Math.ceil(stageHeight * scale) + 'px' } },
                    h('div', {
                        ref: stageRef,
                        className: 'scfvb-canvas-stage',
                        style: { width: props.previewWidth + 'px', transform: 'translateX(-50%) scale(' + scale + ')' },
                        onClick: () => props.setSelectedId(null),
                        onDragOver: canRootDrop ? (e) => e.preventDefault() : undefined,
                        onDrop: canRootDrop ? (e) => props.handleDrop(e, null, props.layout.nodes.length) : undefined
                    },
                        props.dragging && h(DropZone, {
                            parentId: null, index: 0, active: canRootDrop, direction: 'column', handleDrop: props.handleDrop
                        }),
                        props.layout.nodes.length
                            ? props.layout.nodes.map((node, index) => h(Fragment, { key: node.id },
                                index > 0 && props.dragging && h(DropZone, {
                                    parentId: null, index, active: canRootDrop, direction: 'column', handleDrop: props.handleDrop
                                }),
                                h(PreviewNode, Object.assign({}, props, { node, scale }))
                            ))
                            : h('div', { className: 'scfvb-empty-canvas' }, props.dragging ? 'Drop a Section here' : 'Drag or add a Section to begin.'),
                        props.layout.nodes.length > 0 && props.dragging && h(DropZone, {
                            parentId: null, index: props.layout.nodes.length, active: canRootDrop, direction: 'column', handleDrop: props.handleDrop
                        }),
                        h(ViewportHandle, { breakpoint: props.breakpoint, previewWidth: props.previewWidth, scale, updatePreviewWidth: props.updatePreviewWidth })
                    )
                )
            )
        );
    }

    function ViewportHandle(props) {
        function start(event) {
            event.preventDefault(); event.stopPropagation();
            const startX = event.clientX;
            const startWidth = Number(props.previewWidth);
            const meta = BREAKPOINTS[props.breakpoint];
            function move(e) {
                const next = Math.round(clamp(startWidth + (e.clientX - startX) / props.scale, Number(meta.min), Number(meta.max)));
                props.updatePreviewWidth(next);
            }
            function up() {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            }
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up, { once: true });
        }
        return h('button', {
            type: 'button', className: 'scfvb-viewport-handle', draggable: false,
            title: 'Drag to change preview width within this breakpoint',
            onPointerDown: start, onClick: (e) => { e.preventDefault(); e.stopPropagation(); }
        }, '↔');
    }

    function DropZone(props) {
        return h('div', {
            className: 'scfvb-drop-zone ' + (props.direction && props.direction.indexOf('row') === 0 ? 'is-row' : 'is-column') + (props.active ? ' is-active' : ' is-disabled'),
            onDragOver: props.active ? (event) => { event.preventDefault(); event.dataTransfer.dropEffect = 'move'; } : undefined,
            onDrop: props.active ? (event) => props.handleDrop(event, props.parentId, props.index) : undefined
        }, props.active ? h('span', null, '+') : null);
    }

    function PreviewNode(props) {
        const node = props.node;
        const selected = props.selectedId === node.id;
        const styles = toReactStyle(effectiveStyles(node, props.breakpoint));
        const direction = (styles.flexDirection || 'column');
        const canAppend = props.dragging && props.canDropOn(node.id);
        const children = node.children || [];

        const common = {
            className: 'scfvb-preview-node scfvb-preview-' + node.type + (selected ? ' is-selected' : ''),
            style: styles,
            draggable: true,
            onClick: (event) => { event.stopPropagation(); props.setSelectedId(node.id); },
            onDragStart: (event) => {
                event.stopPropagation();
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('application/x-scfvb-node', node.id);
                event.dataTransfer.setData('text/plain', node.id);
                props.setDragging({ kind: 'node', id: node.id });
            },
            onDragEnd: () => props.setDragging(null),
            title: node.name + ' (' + node.type + ')'
        };

        let content;
        if (node.type === 'section' || node.type === 'container') {
            const items = [];
            if (props.dragging) items.push(h(DropZone, { key: 'drop-0', parentId: node.id, index: 0, active: canAppend, direction, handleDrop: props.handleDrop }));
            children.forEach((child, index) => {
                items.push(h(PreviewNode, Object.assign({}, props, { key: child.id, node: child })));
                if (props.dragging) items.push(h(DropZone, { key: 'drop-' + (index + 1), parentId: node.id, index: index + 1, active: canAppend, direction, handleDrop: props.handleDrop }));
            });
            if (!children.length && !props.dragging) items.push(h('div', { key: 'empty', className: 'scfvb-empty-node' }, node.type === 'section' ? 'Drop a Container' : 'Drop content'));
            content = items;
        } else if (node.type === 'heading') {
            const tag = (node.settings && node.settings.tag) || 'h2';
            content = h(tag, { className: 'scfvb-preview-content' }, node.content.text || 'Heading', isScf(node.bindings.text) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        } else if (node.type === 'text') {
            content = h('div', { className: 'scfvb-preview-content' }, h('p', null, node.content.text || 'Text'), isScf(node.bindings.text) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        } else if (node.type === 'image') {
            content = node.content.imageUrl
                ? h(Fragment, null, h('img', { className: 'scfvb-preview-content scfvb-preview-image-content', src: node.content.imageUrl, alt: '' }), isScf(node.bindings.image) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'))
                : h(Fragment, null, h('div', { className: 'scfvb-image-placeholder' }, 'Image'), isScf(node.bindings.image) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        } else if (node.type === 'button') {
            content = h('span', { className: 'scfvb-preview-content' }, node.content.label || 'Button', (isScf(node.bindings.label) || isScf(node.bindings.url)) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        }

        return h('div', common,
            h('span', { className: 'scfvb-node-label' }, node.name),
            content,
            selected && h(ContextToolbar, { node, move: props.moveNodeSibling, duplicate: props.duplicateNode, remove: props.deleteNode }),
            selected && node.type !== 'section' && h(ResizeChrome, {
                node, scale: props.scale, breakpoint: props.breakpoint,
                beginGesture: props.beginGesture, endGesture: props.endGesture, patchStyle: props.patchStyleById
            }),
            selected && CONTAINER_TYPES.includes(node.type) && h(PaddingChrome, {
                node, scale: props.scale, breakpoint: props.breakpoint,
                beginGesture: props.beginGesture, endGesture: props.endGesture, patchStyle: props.patchStyleById
            })
        );
    }

    function ContextToolbar(props) {
        function button(label, onClick, destructive) {
            return h('button', {
                type: 'button', className: destructive ? 'is-destructive' : '', draggable: false,
                onPointerDown: (e) => e.stopPropagation(),
                onClick: (e) => { e.preventDefault(); e.stopPropagation(); onClick(); }
            }, label);
        }
        return h('div', { className: 'scfvb-node-toolbar', draggable: false, onDragStart: (e) => e.preventDefault() },
            h('strong', null, props.node.name),
            button('↑', () => props.move(props.node.id, -1)),
            button('↓', () => props.move(props.node.id, 1)),
            button('Duplicate', () => props.duplicate(props.node.id)),
            button('Delete', () => props.remove(props.node.id), true)
        );
    }

    function ResizeChrome(props) {
        function start(event, axis) {
            event.preventDefault(); event.stopPropagation();
            const nodeElement = event.currentTarget.closest('.scfvb-preview-node');
            if (!nodeElement) return;
            const rect = nodeElement.getBoundingClientRect();
            const startX = event.clientX, startY = event.clientY;
            const startWidth = rect.width / props.scale;
            const startHeight = rect.height / props.scale;
            props.beginGesture();

            function move(e) {
                if (axis.indexOf('e') !== -1) {
                    const width = Math.round(clamp(startWidth + (e.clientX - startX) / props.scale, 40, 2400));
                    props.patchStyle(props.node.id, 'width', width + 'px', true);
                }
                if (axis.indexOf('s') !== -1) {
                    const height = Math.round(clamp(startHeight + (e.clientY - startY) / props.scale, 20, 2000));
                    props.patchStyle(props.node.id, 'height', height + 'px', true);
                }
            }
            function up() {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
                props.endGesture();
            }
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up, { once: true });
        }
        return h(Fragment, null,
            h('span', { className: 'scfvb-resize-handle is-east', draggable: false, onPointerDown: (e) => start(e, 'e'), title: 'Drag to resize width' }),
            h('span', { className: 'scfvb-resize-handle is-south', draggable: false, onPointerDown: (e) => start(e, 's'), title: 'Drag to resize height' }),
            h('span', { className: 'scfvb-resize-handle is-southeast', draggable: false, onPointerDown: (e) => start(e, 'es'), title: 'Drag to resize' })
        );
    }

    function PaddingChrome(props) {
        const effective = effectiveStyles(props.node, props.breakpoint);
        const sides = [
            ['Top', 'paddingTop', 'vertical'], ['Right', 'paddingRight', 'horizontal'],
            ['Bottom', 'paddingBottom', 'vertical'], ['Left', 'paddingLeft', 'horizontal']
        ];
        function start(event, key, axis) {
            event.preventDefault(); event.stopPropagation();
            const startX = event.clientX, startY = event.clientY;
            const startValue = pxNumber(effective[key], 0);
            props.beginGesture();
            function move(e) {
                const rawDelta = axis === 'horizontal' ? (e.clientX - startX) : (e.clientY - startY);
                const next = Math.round(clamp(startValue + rawDelta / props.scale, 0, 500));
                props.patchStyle(props.node.id, key, next + 'px', true);
            }
            function up() {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
                props.endGesture();
            }
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up, { once: true });
        }
        return h(Fragment, null, sides.map((side) => h('button', {
            key: side[1], type: 'button', draggable: false,
            className: 'scfvb-padding-handle is-' + side[0].toLowerCase(),
            title: 'Drag ' + side[0].toLowerCase() + ' padding',
            onPointerDown: (e) => start(e, side[1], side[2]),
            onClick: (e) => { e.preventDefault(); e.stopPropagation(); }
        }, pxNumber(effective[side[1]], 0))));
    }

    function isScf(binding) { return binding && binding.source === 'scf'; }

    function Navigator(props) {
        const [collapsed, setCollapsed] = useState({});
        const [editingId, setEditingId] = useState(null);

        function toggle(id) { setCollapsed((current) => Object.assign({}, current, { [id]: !current[id] })); }

        return h('section', { className: 'scfvb-navigator' },
            h('div', { className: 'scfvb-navigator-header' },
                h('div', null, h('strong', null, 'Navigator'), h('span', { className: 'description' }, 'Double-click a name to rename')),
                h('div', null,
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.moveNodeSibling(props.selectedId, -1) }, '↑'),
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.moveNodeSibling(props.selectedId, 1) }, '↓'),
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.duplicateNode(props.selectedId) }, 'Duplicate'),
                    h(Button, { size: 'compact', isDestructive: true, disabled: !props.selectedId, onClick: () => props.deleteNode(props.selectedId) }, 'Delete')
                )
            ),
            h('div', { className: 'scfvb-tree' },
                props.nodes.length
                    ? h(NavigatorChildren, Object.assign({}, props, { parentId: null, nodes: props.nodes, depth: 0, collapsed, toggle, editingId, setEditingId }))
                    : h('span', { className: 'description scfvb-tree-empty' }, 'No nodes yet.')
            )
        );
    }

    function NavigatorChildren(props) {
        const items = [];
        const canDrop = props.dragging && props.canDropOn(props.parentId);
        if (props.dragging) items.push(h(NavDropZone, { key: 'drop0', parentId: props.parentId, index: 0, active: canDrop, handleDrop: props.handleDrop, depth: props.depth }));
        props.nodes.forEach((node, index) => {
            items.push(h(NavigatorNode, Object.assign({}, props, { key: node.id, node, depth: props.depth })));
            if (props.dragging) items.push(h(NavDropZone, { key: 'drop' + (index + 1), parentId: props.parentId, index: index + 1, active: canDrop, handleDrop: props.handleDrop, depth: props.depth }));
        });
        return h(Fragment, null, items);
    }

    function NavDropZone(props) {
        return h('div', {
            className: 'scfvb-nav-drop' + (props.active ? ' is-active' : ''),
            style: { marginLeft: (12 + props.depth * 18) + 'px' },
            onDragOver: props.active ? (e) => e.preventDefault() : undefined,
            onDrop: props.active ? (e) => props.handleDrop(e, props.parentId, props.index) : undefined
        });
    }

    function NavigatorNode(props) {
        const node = props.node;
        const hasChildren = (node.children || []).length > 0;
        const collapsed = !!props.collapsed[node.id];
        const editing = props.editingId === node.id;
        return h(Fragment, null,
            h('div', {
                className: 'scfvb-tree-row' + (props.selectedId === node.id ? ' is-selected' : ''),
                style: { paddingLeft: (6 + props.depth * 18) + 'px' },
                draggable: !editing,
                onClick: () => props.setSelectedId(node.id),
                onDoubleClick: () => props.setEditingId(node.id),
                onDragStart: (event) => {
                    event.dataTransfer.effectAllowed = 'move';
                    event.dataTransfer.setData('application/x-scfvb-node', node.id);
                    event.dataTransfer.setData('text/plain', node.id);
                    props.setDragging({ kind: 'node', id: node.id });
                },
                onDragEnd: () => props.setDragging(null)
            },
                h('button', {
                    type: 'button', className: 'scfvb-tree-toggle', disabled: !hasChildren,
                    onClick: (e) => { e.stopPropagation(); if (hasChildren) props.toggle(node.id); }
                }, hasChildren ? (collapsed ? '›' : '⌄') : '·'),
                h('span', { className: 'scfvb-tree-type' }, elementIcon(node.type)),
                editing
                    ? h('input', {
                        className: 'scfvb-tree-rename', autoFocus: true, defaultValue: node.name,
                        onClick: (e) => e.stopPropagation(),
                        onKeyDown: (e) => {
                            if (e.key === 'Enter') { props.renameNode(node.id, e.currentTarget.value); props.setEditingId(null); }
                            if (e.key === 'Escape') props.setEditingId(null);
                        },
                        onBlur: (e) => { props.renameNode(node.id, e.currentTarget.value); props.setEditingId(null); }
                    })
                    : h('span', { className: 'scfvb-tree-name' }, node.name),
                Object.values(node.bindings || {}).some(isScf) && h('span', { className: 'scfvb-tree-scf' }, 'SCF')
            ),
            hasChildren && !collapsed && h(NavigatorChildren, Object.assign({}, props, { parentId: node.id, nodes: node.children, depth: props.depth + 1 }))
        );
    }

    function Inspector(props) {
        const node = props.node;
        if (!node) {
            return h('aside', { className: 'scfvb-sidebar scfvb-inspector' },
                h('h2', null, 'Page'),
                h(LabeledSelect, {
                    label: 'Page Layout', value: props.pageLayout,
                    options: [
                        { value: 'theme', label: 'Theme' },
                        { value: 'fullwidth', label: 'Full Width' },
                        { value: 'canvas', label: 'Builder Canvas' }
                    ],
                    onChange: props.setPageLayout
                }),
                h('p', { className: 'description' },
                    props.pageLayout === 'canvas'
                        ? 'Builder Canvas bypasses the theme template and renders only the visual-builder page, while keeping WordPress head/footer hooks and the admin bar.'
                        : props.pageLayout === 'fullwidth'
                            ? 'Full Width keeps the theme header/footer but breaks the builder content out of the theme content constraint.'
                            : 'Theme keeps the builder inside the theme content area.'
                )
            );
        }

        function patchContent(key, value) {
            props.updateSelected((copy) => { copy.content = Object.assign({}, copy.content, { [key]: value }); return copy; });
        }
        function patchSetting(key, value) {
            props.updateSelected((copy) => { copy.settings = Object.assign({}, copy.settings, { [key]: value }); return copy; });
        }
        function patchStyle(key, value) {
            props.updateSelected((copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                copy.styles[props.breakpoint] = Object.assign({}, copy.styles[props.breakpoint] || {}, { [key]: value });
                return copy;
            });
        }
        function resetBreakpoint() {
            if (props.breakpoint === 'desktop') return;
            props.updateSelected((copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                copy.styles[props.breakpoint] = {};
                return copy;
            });
        }
        function patchBinding(key, patch) {
            props.updateSelected((copy) => {
                const current = Object.assign({ source: 'static' }, (copy.bindings && copy.bindings[key]) || {});
                copy.bindings = Object.assign({}, copy.bindings, { [key]: Object.assign(current, patch) });
                return copy;
            });
        }
        function toggleBinding(key, defaultType, labelSuffix) {
            props.updateSelected((copy) => {
                const current = Object.assign({ source: 'static', fieldType: defaultType }, (copy.bindings && copy.bindings[key]) || {});
                if (current.source === 'scf') {
                    current.source = 'static';
                } else {
                    current.source = 'scf';
                    current.fieldType = current.fieldType || defaultType;
                    current.fieldKey = current.fieldKey || fieldKey();
                    const baseLabel = copy.name + (labelSuffix ? ' ' + labelSuffix : '');
                    current.label = current.label || baseLabel;
                    current.fieldName = current.fieldName || slugify(baseLabel);
                }
                copy.bindings = Object.assign({}, copy.bindings, { [key]: current });
                return copy;
            });
        }

        return h('aside', { className: 'scfvb-sidebar scfvb-inspector' },
            h('h2', null, 'Properties'),
            h(LabeledInput, { label: 'Name', value: node.name || '', onChange: (value) => props.updateSelected((copy) => { copy.name = value; return copy; }) }),
            h(ContentInspector, {
                node, patchContent, patchSetting, toggleBinding, patchBinding, scfAvailable: props.scfAvailable
            }),
            h(StyleInspector, { node, breakpoint: props.breakpoint, patchStyle, resetBreakpoint })
        );
    }

    function ContentInspector(props) {
        const node = props.node;
        const rows = [h(SectionTitle, { key: 'title' }, 'Content')];

        if (node.type === 'heading' || node.type === 'text') {
            rows.push(h('label', { className: 'scfvb-field', key: 'text' },
                h('span', null, 'Text'),
                h('textarea', { rows: node.type === 'text' ? 5 : 3, value: node.content.text || '', onChange: (e) => props.patchContent('text', e.target.value) })
            ));
            if (node.type === 'heading') {
                rows.push(h(LabeledSelect, { key: 'tag', label: 'HTML Tag', value: node.settings.tag || 'h2', options: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], onChange: (value) => props.patchSetting('tag', value) }));
            }
            rows.push(h(BindingEditor, {
                key: 'binding', bindingKey: 'text', binding: node.bindings.text || { source: 'static' },
                fieldTypes: node.type === 'text' ? ['text', 'textarea'] : ['text'],
                defaultType: node.type === 'text' ? 'textarea' : 'text',
                toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        if (node.type === 'image') {
            rows.push(h('div', { className: 'scfvb-media-row', key: 'media' },
                node.content.imageUrl ? h('img', { src: node.content.imageUrl, alt: '' }) : h('div', { className: 'scfvb-media-empty' }, 'No image'),
                h(Button, { variant: 'secondary', onClick: () => openMedia(props.patchContent) }, 'Choose Image')
            ));
            rows.push(h(BindingEditor, {
                key: 'binding', bindingKey: 'image', binding: node.bindings.image || { source: 'static' },
                fieldTypes: ['image'], defaultType: 'image', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        if (node.type === 'button') {
            rows.push(h(LabeledInput, { key: 'label', label: 'Label', value: node.content.label || '', onChange: (value) => props.patchContent('label', value) }));
            rows.push(h(BindingEditor, {
                key: 'label-binding', title: 'Label Binding', bindingKey: 'label', binding: node.bindings.label || { source: 'static' },
                fieldTypes: ['text'], defaultType: 'text', labelSuffix: 'Label', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
            rows.push(h(LabeledInput, { key: 'url', label: 'URL', value: node.content.url || '', onChange: (value) => props.patchContent('url', value) }));
            rows.push(h(BindingEditor, {
                key: 'url-binding', title: 'URL Binding', bindingKey: 'url', binding: node.bindings.url || { source: 'static' },
                fieldTypes: ['url'], defaultType: 'url', labelSuffix: 'URL', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        return h(Fragment, null, rows);
    }

    function BindingEditor(props) {
        const binding = props.binding || { source: 'static' };
        const editable = binding.source === 'scf';
        return h('div', { className: 'scfvb-binding-box' },
            props.title && h('strong', null, props.title),
            h('label', { className: 'scfvb-toggle-row' },
                h('input', { type: 'checkbox', checked: editable, disabled: !props.scfAvailable, onChange: () => props.toggle(props.bindingKey, props.defaultType, props.labelSuffix) }),
                h('span', null, 'Editable with SCF')
            ),
            editable && h(Fragment, null,
                h(LabeledInput, { label: 'Field Label', value: binding.label || '', onChange: (value) => props.patch(props.bindingKey, { label: value }) }),
                h(LabeledInput, { label: 'Field Name', value: binding.fieldName || '', onChange: (value) => props.patch(props.bindingKey, { fieldName: slugify(value) }) }),
                h(LabeledSelect, { label: 'Field Type', value: binding.fieldType || props.defaultType, options: props.fieldTypes, onChange: (value) => props.patch(props.bindingKey, { fieldType: value }) }),
                h('code', { className: 'scfvb-field-key' }, binding.fieldKey || '')
            )
        );
    }

    function openMedia(patchContent) {
        if (!wp.media) return;
        const frame = wp.media({ title: 'Select image', library: { type: 'image' }, multiple: false });
        frame.on('select', function () {
            const item = frame.state().get('selection').first().toJSON();
            patchContent('imageId', item.id || 0);
            patchContent('imageUrl', item.url || '');
        });
        frame.open();
    }

    function StyleInspector(props) {
        const node = props.node;
        const current = (node.styles && node.styles[props.breakpoint]) || {};
        const effective = effectiveStyles(node, props.breakpoint);
        const value = (key, fallback) => current[key] !== undefined ? current[key] : (effective[key] !== undefined ? effective[key] : fallback);
        const inherited = (key) => props.breakpoint !== 'desktop' && current[key] === undefined;
        const titleAction = props.breakpoint === 'desktop' ? null : h('button', { type: 'button', className: 'scfvb-reset-overrides', onClick: props.resetBreakpoint }, 'Reset overrides');
        const rows = [h(SectionTitle, { key: 'title', action: titleAction }, 'Style — ' + BREAKPOINTS[props.breakpoint].label)];

        if (CONTAINER_TYPES.includes(node.type)) {
            rows.push(h(LabeledSelect, { key: 'direction', label: 'Direction', value: value('flexDirection', 'column'), options: ['row', 'column', 'row-reverse', 'column-reverse'], onChange: (v) => props.patchStyle('flexDirection', v) }));
            rows.push(h(LabeledSelect, { key: 'justify', label: 'Justify', value: value('justifyContent', 'flex-start'), options: ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], onChange: (v) => props.patchStyle('justifyContent', v) }));
            rows.push(h(LabeledSelect, { key: 'align', label: 'Align', value: value('alignItems', 'stretch'), options: ['stretch', 'flex-start', 'center', 'flex-end', 'baseline'], onChange: (v) => props.patchStyle('alignItems', v) }));
            rows.push(h(ResponsiveInput, { key: 'gap', label: 'Gap', value: value('gap', '16px'), inherited: inherited('gap'), onChange: (v) => props.patchStyle('gap', v) }));
            rows.push(h(ResponsiveInput, { key: 'minheight', label: 'Min Height', value: value('minHeight', ''), inherited: inherited('minHeight'), onChange: (v) => props.patchStyle('minHeight', v) }));
        }

        rows.push(h(ResponsiveInput, { key: 'width', label: 'Width', value: value('width', 'auto'), inherited: inherited('width'), onChange: (v) => props.patchStyle('width', v) }));
        rows.push(h(ResponsiveInput, { key: 'maxwidth', label: 'Max Width', value: value('maxWidth', ''), inherited: inherited('maxWidth'), onChange: (v) => props.patchStyle('maxWidth', v) }));
        rows.push(h(ResponsiveInput, { key: 'height', label: 'Height', value: value('height', ''), inherited: inherited('height'), onChange: (v) => props.patchStyle('height', v) }));

        rows.push(h(SpacingGrid, { key: 'margin', title: 'Margin', prefix: 'margin', value, inherited, patchStyle: props.patchStyle }));
        if (CONTAINER_TYPES.includes(node.type) || node.type === 'button') {
            rows.push(h(SpacingGrid, { key: 'padding', title: 'Padding', prefix: 'padding', value, inherited, patchStyle: props.patchStyle }));
        }

        if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
            rows.push(h(ResponsiveInput, { key: 'fontsize', label: 'Font Size', value: value('fontSize', '16px'), inherited: inherited('fontSize'), onChange: (v) => props.patchStyle('fontSize', v) }));
            rows.push(h(LabeledSelect, { key: 'weight', label: 'Font Weight', value: value('fontWeight', node.type === 'button' ? '600' : '400'), options: ['300', '400', '500', '600', '700', '800', '900'], onChange: (v) => props.patchStyle('fontWeight', v) }));
            rows.push(h(LabeledSelect, { key: 'aligntext', label: 'Text Align', value: value('textAlign', 'left'), options: ['left', 'center', 'right', 'justify'], onChange: (v) => props.patchStyle('textAlign', v) }));
        }

        if (node.type !== 'image') rows.push(h(ColorField, { key: 'color', label: 'Text Color', value: value('color', '#111111'), onChange: (v) => props.patchStyle('color', v) }));
        if (CONTAINER_TYPES.includes(node.type) || node.type === 'button') rows.push(h(ColorField, { key: 'bg', label: 'Background', value: value('backgroundColor', '#ffffff'), onChange: (v) => props.patchStyle('backgroundColor', v) }));

        if (node.type === 'image' || node.type === 'button' || CONTAINER_TYPES.includes(node.type)) {
            rows.push(h(ResponsiveInput, { key: 'radius', label: 'Border Radius', value: value('borderRadius', '0px'), inherited: inherited('borderRadius'), onChange: (v) => props.patchStyle('borderRadius', v) }));
            rows.push(h(ResponsiveInput, { key: 'borderwidth', label: 'Border Width', value: value('borderWidth', '0px'), inherited: inherited('borderWidth'), onChange: (v) => props.patchStyle('borderWidth', v) }));
            rows.push(h(ColorField, { key: 'bordercolor', label: 'Border Color', value: value('borderColor', '#dddddd'), onChange: (v) => props.patchStyle('borderColor', v) }));
        }

        return h(Fragment, null, rows);
    }

    function ResponsiveInput(props) {
        return h('label', { className: 'scfvb-field' + (props.inherited ? ' is-inherited' : '') },
            h('span', null, props.label, props.inherited && h('em', null, ' inherited')),
            h('input', { type: 'text', value: props.value == null ? '' : props.value, onChange: (e) => props.onChange(e.target.value) })
        );
    }

    function SpacingGrid(props) {
        return h('div', { className: 'scfvb-spacing-grid' },
            h('span', { className: 'scfvb-spacing-title' }, props.title),
            ['Top', 'Right', 'Bottom', 'Left'].map((side) => {
                const key = props.prefix + side;
                return h('label', { key, className: props.inherited(key) ? 'is-inherited' : '' },
                    h('span', null, side.charAt(0)),
                    h('input', { type: 'text', value: props.value(key, '0px'), title: side, onChange: (e) => props.patchStyle(key, e.target.value) })
                );
            })
        );
    }

    function ColorField(props) {
        const safe = /^#[0-9a-fA-F]{6}$/.test(props.value || '') ? props.value : '#000000';
        return h('label', { className: 'scfvb-field scfvb-color-field' },
            h('span', null, props.label),
            h('div', null,
                h('input', { type: 'color', value: safe, onChange: (e) => props.onChange(e.target.value) }),
                h('input', { type: 'text', value: props.value || '', onChange: (e) => props.onChange(e.target.value) })
            )
        );
    }

    const root = document.getElementById('scfvb-editor-root');
    if (root) {
        if (wp.element.createRoot) wp.element.createRoot(root).render(h(App));
        else wp.element.render(h(App), root);
    }
}());
