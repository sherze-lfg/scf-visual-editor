# SCF Visual Builder 0.2.0

A schema-aware visual page builder for WordPress that integrates visual components with Secure Custom Fields (SCF).

## What 0.2 adds

- Drag elements directly from the Elements panel into valid canvas drop positions.
- Reorder and re-parent nodes using drop lines in both the canvas and Navigator.
- Hover/selection outlines and an on-canvas context toolbar.
- Width/height resize handles for non-section elements.
- On-canvas draggable padding handles for Sections and Containers.
- Improved Navigator with collapse/expand, inline rename, drag/reorder, duplicate and delete.
- Four responsive modes with cascading overrides:
  - Desktop: 1199px+ (1920px default preview)
  - Laptop / Small Desktop: 992–1198px
  - Tablet: 768–991px
  - Mobile: 320–767px (390px default preview)
- Editable preview width inside each responsive range.
- Scaled canvas preview so large desktop widths still fit inside WordPress admin.
- Responsive inheritance and a per-breakpoint “Reset overrides” action.
- Page layout modes:
  - Theme — builder stays in the theme content area.
  - Full Width — theme header/footer remain, builder content breaks out to viewport width.
  - Builder Canvas — bypasses the theme template and renders only the builder page while preserving `wp_head()`, `wp_body_open()`, `wp_footer()`, and the logged-in admin bar.
- Layout schema version 2 with automatic in-memory migration from 0.1 layouts.

## Responsive cascade

The generated frontend CSS uses Desktop as the base and cascades overrides downward:

```text
Desktop
  ↓
Laptop
  ↓
Tablet
  ↓
Mobile
```

The generated breakpoints are:

```css
/* Desktop: base styles */
@media (max-width: 1198px) { /* Laptop overrides */ }
@media (max-width: 991px)  { /* Tablet overrides */ }
@media (max-width: 767px)  { /* Mobile overrides */ }
```

This means a Laptop value is inherited by Tablet/Mobile unless a smaller breakpoint overrides it.

## 0.1 layout migration

0.1 used Desktop / Tablet / Mobile. When an older layout is loaded in 0.2, its old Tablet overrides are also copied into the new Laptop band in memory. This avoids an unstyled gap when upgrading. The stored layout is only rewritten when the user explicitly clicks Save.

## Existing SCF behavior retained

- Static or SCF-backed Heading, Text, Image and Button content.
- Text / Textarea / Image / URL SCF field generation.
- Stable `field_scfvb_*` identities.
- Field-name migration when a field is renamed.
- Duplicate field-name and field-key validation.
- REST permission checks and server-side layout validation.
- Empty SCF values stay empty rather than falling back to design placeholders.
- Textarea paragraph formatting is applied exactly once.

## Install / upgrade in LocalWP

1. WordPress Admin → Plugins → Add Plugin → Upload Plugin.
2. Upload `scf-visual-builder-v0.2.0.zip`.
3. Choose **Replace current with uploaded** when upgrading from 0.1.x.
4. Keep Secure Custom Fields active.
5. Open Pages → **Edit with Visual Builder**.

Your layouts and SCF content are stored in the WordPress database and are not removed by replacing the plugin files.

## Current scope

0.2 remains a Flexbox-first builder. CSS Grid, free/absolute positioning, advanced backgrounds, reusable components, Groups, Repeaters and Flexible Content remain later roadmap items.
