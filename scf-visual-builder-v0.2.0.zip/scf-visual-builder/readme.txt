=== SCF Visual Builder ===
Contributors: openai
Tags: secure custom fields, scf, custom fields, page builder, visual builder
Requires at least: 6.5
Requires PHP: 8.0
Stable tag: 0.2.0
License: GPLv2 or later

A schema-aware visual page builder integrated with Secure Custom Fields.

== Description ==

SCF Visual Builder lets a designer visually create WordPress page layouts while binding editable content directly to Secure Custom Fields.

Version 0.2.0 adds a substantially improved visual-editing foundation: canvas and Navigator drag/reorder, resize handles, visual padding controls, responsive previews, four responsive modes, and Theme / Full Width / Builder Canvas page modes.

Responsive modes:

* Desktop: 1199px+ (1920px default preview)
* Laptop / Small Desktop: 992–1198px
* Tablet: 768–991px
* Mobile: 320–767px

== Installation ==

1. Install and activate Secure Custom Fields.
2. Upload and activate SCF Visual Builder.
3. Open Pages and choose "Edit with Visual Builder" for a page.

== Changelog ==

= 0.2.0 =
* Added four responsive modes and cascading frontend breakpoints.
* Added adjustable/scaled responsive canvas previews.
* Added palette-to-canvas drag and drop.
* Added drop-line reordering and re-parenting in canvas and Navigator.
* Added selection hover states, context toolbar, resize handles and visual padding handles.
* Added collapsible Navigator and inline node rename.
* Added Theme, Full Width and Builder Canvas page layout modes.
* Added schema v2 normalization and migration of 0.1 responsive layouts.

= 0.1.2 =
* Hardened renderer, REST validation, field identity rules and textarea rendering.
