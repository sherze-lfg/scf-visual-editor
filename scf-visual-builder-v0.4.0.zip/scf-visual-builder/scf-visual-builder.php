<?php
/**
 * Plugin Name: SCF Visual Builder
 * Description: A schema-aware visual page builder integrated with Secure Custom Fields.
 * Version: 0.4.0
 * Author: OpenAI
 * Requires at least: 6.5
 * Requires PHP: 8.0
 * Text Domain: scf-visual-builder
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SCFVB_VERSION', '0.4.0' );
define( 'SCFVB_FILE', __FILE__ );
define( 'SCFVB_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCFVB_URL', plugin_dir_url( __FILE__ ) );

require_once SCFVB_DIR . 'includes/class-scfvb-layout.php';
require_once SCFVB_DIR . 'includes/class-scfvb-plugin.php';
require_once SCFVB_DIR . 'includes/class-scfvb-editor.php';
require_once SCFVB_DIR . 'includes/class-scfvb-rest.php';
require_once SCFVB_DIR . 'includes/class-scfvb-scf.php';
require_once SCFVB_DIR . 'includes/class-scfvb-renderer.php';

SCFVB_Plugin::instance()->boot();
