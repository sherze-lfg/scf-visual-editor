=== SCF Visual Builder ===
Contributors: openai
Tags: secure custom fields, scf, custom fields, page builder, visual builder
Requires at least: 6.5
Requires PHP: 8.0
Stable tag: 0.7.0
License: GPLv2 or later

A schema-aware visual page builder integrated with Secure Custom Fields.

== Description ==

SCF Visual Builder lets a designer visually create WordPress page layouts while binding editable content directly to Secure Custom Fields.

Version 0.7 expands visual bindings to richer Secure Custom Fields types including WYSIWYG, choices, dates, galleries, files, links, relationships, taxonomies, post objects, numbers, email, and color fields while retaining Groups, Repeaters, and reusable Components.

Responsive modes:

* Desktop: 1199px+ (1920px default preview)
* Laptop / Small Desktop: 992–1198px
* Tablet: 768–991px
* Mobile: 320–767px

== Installation ==

1. Install and activate Secure Custom Fields.
2. Upload and activate SCF Visual Builder.
3. Open Pages and choose "Edit with Visual Builder" for a page.

== Changelog ==

= 0.7.0 =
* Added WYSIWYG, Number, Email, Select, Checkbox, Radio, True/False, Gallery, File, Link, Page Link, Post Object, Relationship, Taxonomy, Date Picker, Date/Time Picker, and Color Picker binding support.
* Added compatibility-aware field type choices for Heading, Text, Image, and Button bindings.
* Added field-specific Inspector settings for choice lists, number min/max/step, True/False labels, post-type filtering, multiple selection, relationship/gallery limits, taxonomy slug, date display format, WYSIWYG media upload, and color opacity.
* Image elements can render SCF Gallery values as responsive image collections.
* Text rendering now safely handles rich WYSIWYG HTML, mail links, file/link/page/post links, relationships, taxonomy terms, dates, choice labels, and True/False labels.
* Raw WordPress post-meta fallback supports the new field types when SCF is temporarily unavailable.
* Advanced field options propagate through Groups, Repeaters, and linked Components while preserving immutable per-instance field keys/names.
* Updated layout schema to version 7 with non-destructive compatibility for existing 0.1–0.6 layouts.


= 0.5.1 =
* Duplicate SCF field, Group, and Repeater names in the same schema scope are automatically suffixed with _2, _3, and so on when saving.
* Existing explicit numbered names are preserved; automatic suffixing skips names already in use.
* Immutable field keys remain unchanged so renamed duplicates keep their identity and existing content can migrate safely.
* The editor reloads the normalized field names returned by WordPress and reports how many duplicates were renamed.

= 0.5.0 =
* Added opt-in SCF Repeater mode for Container elements.
* One visual Container becomes the reusable row template; the frontend renders one copy for every SCF Repeater row.
* Added Repeater label/name, editor layout, add-row button text, minimum rows and maximum rows controls.
* Added REPEATER badges in the canvas and Navigator.
* Repeater containers generate real Secure Custom Fields Repeater fields with visual descendants mapped to subfields.
* Groups can live inside Repeaters and Repeaters can live inside Groups; nested Repeaters are also supported by the schema and renderer.
* Raw post-meta fallback can render stored Repeater rows if SCF is temporarily unavailable.
* Duplicate Repeater trees receive new immutable Repeater and child field identities to prevent data sharing.
* Added Repeater-aware schema-name, stable-key and physical WordPress meta-path collision validation.
* Populated fields are protected from unsafe cross-Repeater schema moves; potentially lossy migrations are blocked instead of silently reassigning row data.
* Updated layout schema to version 5 with non-destructive migration of existing 0.1–0.4 layouts.

= 0.4.1 =
* Hardened Group/meta storage before the Repeater phase.
* Fixed layout JSON persistence by slashing encoded JSON before WordPress metadata storage so quotes and backslashes survive saves.
* Corrupt/non-JSON stored layouts are now surfaced and protected from accidental overwrite in the editor.
* Added physical SCF post-meta collision detection for logically different Group paths that flatten to the same underscore storage key.
* Added safe maximum field/storage path lengths to prevent truncated or ambiguous Group metadata.
* Stable field keys are now unique even for temporarily-static bindings, protecting migration identity.
* Reactivating an old binding now verifies that existing metadata still belongs to the same immutable field key.
* Group/field moves now stage and verify destination metadata before deleting source keys, with rollback on write failure.
* Layout storage itself is verified before old Group/field source metadata is deleted; failed layout writes roll staged moves back.
* Metadata migrations preserve literal backslashes and escaped text values.
* Cached root Group values during frontend rendering so multiple descendants do not repeatedly call get_field() for the same Group.
* Bounded generated/copied field names in the editor so long labels cannot create unsavable SCF names.

= 0.4.0 =
* Added opt-in SCF Group mode for Container elements.
* Group containers generate real Secure Custom Fields Group fields with visual descendants mapped to subfields.
* Added nested Group support; normal layout containers remain transparent to the SCF schema.
* Added Group label/name editing with immutable stable Group field keys.
* Added GROUP badges in the canvas and Navigator.
* Dragging an SCF-bound element into/out of/between Groups now changes the schema and safely migrates its prefixed post-meta storage on save.
* Renaming a Group safely migrates all descendant SCF values whose physical meta names change.
* Converting Group containers back to normal containers safely migrates descendant values back to their new schema level.
* Group-aware renderer resolves nested SCF arrays and falls back to prefixed raw post meta if SCF is temporarily unavailable.
* Duplicate Group trees generate new node IDs, Group keys/names, and descendant field keys/names to prevent data sharing.
* Field-name uniqueness is now scoped to SCF sibling levels, allowing the same child name in separate Groups while still preventing collisions.
* Updated layout schema to version 4 with non-destructive migration of all 0.1–0.3 layouts.

= 0.3.2 =
* Hardened the 0.3 layout engine before the SCF Group phase.
* Empty responsive CSS inputs now remove the override and correctly inherit from the larger breakpoint.
* Normalization removes legacy empty-string style overrides so editor and frontend inheritance stay in sync.
* REST saves now reject invalid CSS values instead of storing phantom overrides that the renderer later ignores.
* Corrected right and bottom visual padding drag directions.
* Prevented Full Width / Builder Canvas pages from producing a horizontal viewport scrollbar from full-bleed 100vw layouts.
* Removed the builder's global image max-width clamp so explicit Image sizing is respected.
* Hardened frontend textarea typography against theme paragraph styles while preserving paragraph spacing.
* Tightened valid hex color and aspect-ratio validation.
* Hardened SCF field rename conflicts so unrelated destination post meta is never silently adopted.
* Blocked new SCF field identities from silently claiming orphaned or unrelated post meta that already uses the same field name.
* Improved responsive background normalization for empty media references.
* Improved color-picker previews for shorthand and alpha hex values.

= 0.3.1 =
* Fixed background image defaults being shown in the Inspector without being applied to the canvas/frontend.
* Existing 0.3.0 image backgrounds now normalize to Cover / Center / No Repeat / Scroll unless explicitly overridden.
* Fixed responsive Image-mode overrides accidentally clearing an inherited background image when no new media was selected.
* Fixed the same displayed-default mismatch when first switching a Section or Container to CSS Grid.
* Grid mode now persists its initial columns, rows, gaps and auto-flow values immediately.
* Preserved legacy Image object-fit behavior while keeping new Image nodes on the 0.3 Cover default.
* Hardened REST style sanitization so container-only and image-only style metadata cannot leak onto incompatible nodes.

= 0.3.0 =
* Added Flexbox / CSS Grid layout switching for Sections and Containers.
* Added fixed-column and Auto Fit / Auto Fill Grid controls with row/column gaps.
* Added min/max width and min/max height controls.
* Added Static, Relative, Absolute, Fixed and Sticky positioning with offsets and z-index.
* Added Section/Container overflow controls.
* Added responsive Section and Container background images through the WordPress Media Library.
* Added background size, position, repeat and attachment controls.
* Added Image object-fit, object-position and custom aspect-ratio controls.
* Background media stores attachment ID plus URL fallback and resolves the attachment on frontend render.
* Updated layout schema to version 3 while preserving 0.1/0.2 layout compatibility.

= 0.2.2 =
* Prevented save responses from overwriting newer local edits made while a save request is in flight.
* Hardened canvas drop targeting against stale targets and invalid nested dragover bubbling.
* Cleared drop state when leaving the canvas or hovering invalid regions.
* Made media selection one undoable history action.
* Added pointer-cancel cleanup for viewport, resize, and padding gestures.
* Preflighted all SCF field renames before mutating metadata to prevent partial migrations.
* Added destination SCF field-reference conflict detection during renames.
* Preserved SCF-bound content from raw post meta when SCF is temporarily unavailable.
* Filtered malformed scalar layout nodes/children during normalization.
* Restricted saved Heading tags to h1-h6 and added safer new-tab link attributes.

= 0.2.1 =
* Rebuilt canvas drag/drop so dragging no longer injects temporary drop-zone elements into the page layout.
* Added direct drop targeting on Sections, Containers and sibling elements in the visual canvas.
* Added stable inside/before/after drop indicators that do not change canvas geometry.
* Prevented invalid self/descendant drop targets while moving existing nodes.
* Disabled canvas height animation during an active drag to prevent visual feedback loops.
* Disabled native image dragging inside preview nodes so image elements move as builder nodes.
* Navigator drag/drop remains available for precise tree operations.

= 0.2.0 =
* Added four responsive modes and cascading frontend breakpoints.
* Added adjustable/scaled responsive canvas previews.
* Added palette-to-canvas drag and drop.
* Added drop-line reordering and re-parenting in canvas and Navigator.
* Added selection hover states, context toolbar, resize handles and visual padding handles.
* Added collapsible Navigator and inline node rename.
* Added Theme, Full Width and Builder Canvas page layout modes.
* Added schema v2 normalization and migration of 0.1 responsive layouts.

= 0.1.2 =
* Hardened renderer, REST validation, field identity rules and textarea rendering.
