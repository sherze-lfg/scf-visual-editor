<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_SCF {
    private const SUPPORTED_FIELD_TYPES = array(
        'text', 'textarea', 'wysiwyg', 'number', 'email', 'select', 'checkbox', 'radio', 'true_false',
        'image', 'gallery', 'file', 'url', 'link', 'page_link', 'post_object', 'relationship', 'taxonomy',
        'date_picker', 'date_time_picker', 'color_picker'
    );
    public function hooks(): void {
        add_action( 'acf/init', array( $this, 'register_fields' ) );
    }

    public function register_fields(): void {
        if ( ! function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }

        $pages = get_posts(
            array(
                'post_type'      => 'page',
                'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_key'       => '_scfvb_enabled',
                'meta_value'     => '1',
                'no_found_rows'  => true,
            )
        );

        foreach ( $pages as $post_id ) {
            $layout = $this->load_layout( (int) $post_id );
            $fields = $this->collect_level_fields( $layout['nodes'] ?? array() );
            if ( empty( $fields ) ) {
                continue;
            }

            acf_add_local_field_group(
                array(
                    'key'          => 'group_scfvb_page_' . $post_id,
                    'title'        => 'Visual Builder Content — ' . get_the_title( $post_id ),
                    'fields'       => array_values( $fields ),
                    'location'     => array(
                        array(
                            array(
                                'param'    => 'page',
                                'operator' => '==',
                                'value'    => (string) $post_id,
                            ),
                        ),
                    ),
                    'position'     => 'normal',
                    'style'        => 'default',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'active'       => true,
                    'show_in_rest' => 1,
                )
            );
        }
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, '_scfvb_layout', true );
        if ( is_string( $raw ) ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                return SCFVB_Components::instance()->resolve_layout( SCFVB_Layout::normalize( $decoded ) );
            }
        }
        return SCFVB_Layout::default_layout();
    }

    /**
     * Build one logical SCF schema level. Presentation-only containers are
     * transparent. Group and Repeater containers establish real schema boundaries.
     */
    private function collect_level_fields( array $nodes ): array {
        $fields = array();

        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }

            $repeater = $this->active_repeater( $node );
            if ( $repeater ) {
                $sub_fields = $this->collect_level_fields( $node['children'] ?? array() );
                if ( ! empty( $sub_fields ) ) {
                    $fields[ $repeater['fieldKey'] ] = array(
                        'key'          => $repeater['fieldKey'],
                        'label'        => $repeater['label'],
                        'name'         => $repeater['fieldName'],
                        'type'         => 'repeater',
                        'layout'       => $repeater['layout'],
                        'button_label' => $repeater['buttonLabel'],
                        'min'          => $repeater['min'],
                        'max'          => $repeater['max'],
                        'sub_fields'   => array_values( $sub_fields ),
                        'required'     => 0,
                        'wrapper'      => array( 'width' => '', 'class' => '', 'id' => '' ),
                    );
                }
                continue;
            }

            $group = $this->active_group( $node );
            if ( $group ) {
                $sub_fields = $this->collect_level_fields( $node['children'] ?? array() );
                if ( ! empty( $sub_fields ) ) {
                    $fields[ $group['fieldKey'] ] = array(
                        'key'        => $group['fieldKey'],
                        'label'      => $group['label'],
                        'name'       => $group['fieldName'],
                        'type'       => 'group',
                        'layout'     => 'block',
                        'sub_fields' => array_values( $sub_fields ),
                        'required'   => 0,
                        'wrapper'    => array( 'width' => '', 'class' => '', 'id' => '' ),
                    );
                }
                continue;
            }

            foreach ( $node['bindings'] ?? array() as $binding ) {
                if ( 'scf' !== ( $binding['source'] ?? 'static' ) || empty( $binding['fieldKey'] ) || empty( $binding['fieldName'] ) ) {
                    continue;
                }

                $field = $this->field_from_binding( $binding );
                $fields[ $field['key'] ] = $field;
            }

            if ( ! empty( $node['children'] ) ) {
                foreach ( $this->collect_level_fields( $node['children'] ) as $key => $field ) {
                    $fields[ $key ] = $field;
                }
            }
        }

        return $fields;
    }

    private function active_group( array $node ): ?array {
        if ( 'container' !== ( $node['type'] ?? '' ) || empty( $node['group']['enabled'] ) || ! empty( $node['repeater']['enabled'] ) ) {
            return null;
        }

        $group = $node['group'];
        if ( empty( $group['fieldKey'] ) || empty( $group['fieldName'] ) ) {
            return null;
        }

        return array(
            'fieldKey'  => (string) $group['fieldKey'],
            'fieldName' => (string) $group['fieldName'],
            'label'     => (string) ( $group['label'] ?? ucwords( str_replace( '_', ' ', $group['fieldName'] ) ) ),
        );
    }

    private function active_repeater( array $node ): ?array {
        if ( 'container' !== ( $node['type'] ?? '' ) || empty( $node['repeater']['enabled'] ) ) {
            return null;
        }

        $repeater = $node['repeater'];
        if ( empty( $repeater['fieldKey'] ) || empty( $repeater['fieldName'] ) ) {
            return null;
        }

        $layout = (string) ( $repeater['layout'] ?? 'block' );
        if ( ! in_array( $layout, array( 'block', 'row', 'table' ), true ) ) {
            $layout = 'block';
        }

        $min = max( 0, absint( $repeater['min'] ?? 0 ) );
        $max = max( 0, absint( $repeater['max'] ?? 0 ) );
        if ( $max > 0 && $min > $max ) {
            $min = $max;
        }

        return array(
            'fieldKey'    => (string) $repeater['fieldKey'],
            'fieldName'   => (string) $repeater['fieldName'],
            'label'       => (string) ( $repeater['label'] ?? ucwords( str_replace( '_', ' ', $repeater['fieldName'] ) ) ),
            'layout'      => $layout,
            'buttonLabel' => (string) ( $repeater['buttonLabel'] ?? 'Add Row' ),
            'min'         => $min,
            'max'         => $max,
        );
    }

    private function field_from_binding( array $binding ): array {
        $type = sanitize_key( (string) ( $binding['fieldType'] ?? 'text' ) );
        if ( ! in_array( $type, self::SUPPORTED_FIELD_TYPES, true ) ) {
            $type = 'text';
        }
        $options = isset( $binding['options'] ) && is_array( $binding['options'] ) ? $binding['options'] : array();
        $field = array(
            'key'      => $binding['fieldKey'],
            'label'    => $binding['label'] ?? ucwords( str_replace( '_', ' ', $binding['fieldName'] ) ),
            'name'     => $binding['fieldName'],
            'type'     => $type,
            'required' => 0,
            'wrapper'  => array( 'width' => '', 'class' => '', 'id' => '' ),
        );

        switch ( $type ) {
            case 'image':
                $field['return_format'] = 'array';
                $field['preview_size']  = 'medium';
                $field['library']       = 'all';
                break;

            case 'gallery':
                $field['return_format'] = 'array';
                $field['preview_size']  = 'medium';
                $field['library']       = 'all';
                $field['min']           = max( 0, absint( $options['minItems'] ?? 0 ) );
                $field['max']           = max( 0, absint( $options['maxItems'] ?? 0 ) );
                break;

            case 'textarea':
                $field['rows']      = 5;
                $field['new_lines'] = '';
                break;

            case 'wysiwyg':
                $field['tabs']         = 'all';
                $field['toolbar']      = 'full';
                $field['media_upload'] = ! array_key_exists( 'mediaUpload', $options ) || ! empty( $options['mediaUpload'] ) ? 1 : 0;
                break;

            case 'number':
                foreach ( array( 'min', 'max', 'step' ) as $key ) {
                    if ( isset( $options[ $key ] ) && '' !== (string) $options[ $key ] && is_numeric( $options[ $key ] ) ) {
                        $field[ $key ] = 0 + $options[ $key ];
                    }
                }
                break;

            case 'select':
            case 'checkbox':
            case 'radio':
                $field['choices'] = $this->parse_choices( (string) ( $options['choicesText'] ?? '' ) );
                $field['return_format'] = 'label';
                if ( 'select' === $type ) {
                    $field['multiple'] = ! empty( $options['multiple'] ) ? 1 : 0;
                    $field['ui'] = 1;
                }
                if ( 'checkbox' === $type ) {
                    $field['layout'] = 'vertical';
                    $field['toggle'] = 0;
                }
                if ( 'radio' === $type ) {
                    $field['layout'] = 'vertical';
                    $field['other_choice'] = 0;
                    $field['save_other_choice'] = 0;
                }
                if ( in_array( $type, array( 'select', 'radio' ), true ) ) {
                    $field['allow_null'] = ! empty( $options['allowNull'] ) ? 1 : 0;
                }
                break;

            case 'true_false':
                $field['ui'] = 1;
                $field['ui_on_text'] = sanitize_text_field( (string) ( $options['trueLabel'] ?? 'Yes' ) );
                $field['ui_off_text'] = sanitize_text_field( (string) ( $options['falseLabel'] ?? 'No' ) );
                break;

            case 'file':
                $field['return_format'] = 'array';
                $field['library'] = 'all';
                break;

            case 'link':
                $field['return_format'] = 'array';
                break;

            case 'page_link':
                $field['allow_null'] = 1;
                $field['multiple'] = 0;
                break;

            case 'post_object':
                $field['return_format'] = 'object';
                $field['allow_null'] = ! empty( $options['allowNull'] ) ? 1 : 0;
                $field['multiple'] = ! empty( $options['multiple'] ) ? 1 : 0;
                if ( ! empty( $options['postTypes'] ) && is_array( $options['postTypes'] ) ) {
                    $field['post_type'] = array_values( array_filter( array_map( 'sanitize_key', $options['postTypes'] ) ) );
                }
                break;

            case 'relationship':
                $field['return_format'] = 'object';
                $field['min'] = max( 0, absint( $options['minItems'] ?? 0 ) );
                $field['max'] = max( 0, absint( $options['maxItems'] ?? 0 ) );
                if ( ! empty( $options['postTypes'] ) && is_array( $options['postTypes'] ) ) {
                    $field['post_type'] = array_values( array_filter( array_map( 'sanitize_key', $options['postTypes'] ) ) );
                }
                break;

            case 'taxonomy':
                $field['taxonomy'] = sanitize_key( (string) ( $options['taxonomy'] ?? 'category' ) ) ?: 'category';
                $field['field_type'] = ! empty( $options['multiple'] ) ? 'multi_select' : 'select';
                $field['allow_null'] = ! empty( $options['allowNull'] ) ? 1 : 0;
                $field['add_term'] = 0;
                $field['save_terms'] = 0;
                $field['load_terms'] = 0;
                $field['return_format'] = 'object';
                break;

            case 'date_picker':
                $date_format = $this->safe_date_format( (string) ( $options['displayFormat'] ?? 'F j, Y' ), 'F j, Y' );
                $field['display_format'] = $date_format;
                $field['return_format'] = $date_format;
                $field['first_day'] = 1;
                break;

            case 'date_time_picker':
                $date_format = $this->safe_date_format( (string) ( $options['displayFormat'] ?? 'F j, Y g:i a' ), 'F j, Y g:i a' );
                $field['display_format'] = $date_format;
                $field['return_format'] = $date_format;
                $field['first_day'] = 1;
                break;

            case 'color_picker':
                $field['enable_opacity'] = ! empty( $options['enableOpacity'] ) ? 1 : 0;
                break;
        }

        return $field;
    }

    private function safe_date_format( string $format, string $fallback ): string {
        $format = sanitize_text_field( $format );
        if ( '' === $format || strlen( $format ) > 60 || ! preg_match( '/^[A-Za-z0-9 _.,:\/\\-]+$/', $format ) ) {
            return $fallback;
        }
        return $format;
    }

    /**
     * Choices are entered visually as one item per line. "value : Label" and
     * "value | Label" are supported; a bare line uses the same value/label.
     */
    private function parse_choices( string $text ): array {
        $choices = array();
        $lines = preg_split( '/\r\n|\r|\n/', $text );
        foreach ( $lines ?: array() as $line ) {
            $line = trim( wp_strip_all_tags( (string) $line ) );
            if ( '' === $line ) {
                continue;
            }
            $parts = preg_split( '/\s*(?::|\|)\s*/', $line, 2 );
            $value = trim( (string) ( $parts[0] ?? '' ) );
            $label = trim( (string) ( $parts[1] ?? $value ) );
            if ( '' === $value ) {
                continue;
            }
            $choices[ $value ] = '' !== $label ? $label : $value;
            if ( count( $choices ) >= 200 ) {
                break;
            }
        }
        return $choices;
    }

}
