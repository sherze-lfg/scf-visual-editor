<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_REST {
    private const META_ENABLED = '_scfvb_enabled';
    private const META_LAYOUT  = '_scfvb_layout';
    private const META_VERSION = '_scfvb_layout_version';

    private const ALLOWED_TYPES = array( 'section', 'container', 'heading', 'text', 'image', 'button' );
    private const ALLOWED_STYLE_KEYS = array(
        'display',
        'width', 'minWidth', 'maxWidth', 'height', 'minHeight', 'maxHeight',
        'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
        'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
        'flexDirection', 'justifyContent', 'alignItems', 'gap',
        'gridTemplateColumns', 'gridTemplateRows', 'columnGap', 'rowGap', 'gridAutoFlow',
        'position', 'top', 'right', 'bottom', 'left', 'zIndex', 'overflow',
        'backgroundType', 'backgroundColor', 'backgroundImageId', 'backgroundImageUrl',
        'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment',
        'color', 'fontSize', 'fontWeight',
        'borderWidth', 'borderColor', 'borderRadius', 'textAlign',
        'objectFit', 'objectPosition', 'aspectRatio',
    );

    public function hooks(): void {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route(
            'scfvb/v1',
            '/pages/(?P<id>\d+)/layout',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_layout' ),
                    'permission_callback' => array( $this, 'can_edit' ),
                ),
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'save_layout' ),
                    'permission_callback' => array( $this, 'can_edit' ),
                ),
            )
        );
    }

    public function can_edit( WP_REST_Request $request ): bool {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );
        return (bool) ( $post && 'page' === $post->post_type && current_user_can( 'edit_post', $post_id ) );
    }

    public function get_layout( WP_REST_Request $request ): WP_REST_Response {
        $post_id = absint( $request['id'] );
        return rest_ensure_response(
            array(
                'enabled' => (bool) get_post_meta( $post_id, self::META_ENABLED, true ),
                'layout'  => $this->load_layout( $post_id ),
            )
        );
    }

    public function save_layout( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $params = $request->get_json_params();

        if ( ! isset( $params['layout'] ) || ! is_array( $params['layout'] ) ) {
            return new WP_Error( 'scfvb_invalid_layout', 'A layout object is required.', array( 'status' => 400 ) );
        }

        $sanitized = $this->sanitize_layout( $params['layout'] );
        if ( is_wp_error( $sanitized ) ) {
            return $sanitized;
        }

        $identity_validation = $this->validate_unique_field_bindings( $sanitized );
        if ( is_wp_error( $identity_validation ) ) {
            return $identity_validation;
        }

        $old_layout = $this->load_layout( $post_id );
        $migration = $this->migrate_renamed_fields( $post_id, $old_layout, $sanitized );
        if ( is_wp_error( $migration ) ) {
            return $migration;
        }

        update_post_meta( $post_id, self::META_ENABLED, 1 );
        update_post_meta( $post_id, self::META_VERSION, SCFVB_Layout::VERSION );
        update_post_meta( $post_id, self::META_LAYOUT, wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES ) );

        return rest_ensure_response(
            array(
                'saved'  => true,
                'layout' => $sanitized,
            )
        );
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, self::META_LAYOUT, true );
        if ( is_string( $raw ) && '' !== $raw ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                return SCFVB_Layout::normalize( $decoded );
            }
        }

        return SCFVB_Layout::default_layout();
    }

    private function sanitize_layout( array $layout ) {
        $nodes = isset( $layout['nodes'] ) && is_array( $layout['nodes'] ) ? $layout['nodes'] : array();
        if ( count( $nodes ) > 200 ) {
            return new WP_Error( 'scfvb_too_many_nodes', 'The layout contains too many root nodes.', array( 'status' => 400 ) );
        }

        $count = 0;
        $seen_node_ids = array();
        $sanitized_nodes = array();
        foreach ( $nodes as $node ) {
            $clean = $this->sanitize_node( $node, 0, $count, null, $seen_node_ids );
            if ( is_wp_error( $clean ) ) {
                return $clean;
            }
            $sanitized_nodes[] = $clean;
        }

        $page_layout = isset( $layout['settings']['pageLayout'] ) ? sanitize_key( $layout['settings']['pageLayout'] ) : 'fullwidth';
        if ( ! in_array( $page_layout, SCFVB_Layout::PAGE_LAYOUTS, true ) ) {
            return new WP_Error( 'scfvb_invalid_page_layout', 'Unsupported page layout mode.', array( 'status' => 400 ) );
        }

        return array(
            'version'  => SCFVB_Layout::VERSION,
            'settings' => array( 'pageLayout' => $page_layout ),
            'nodes'    => $sanitized_nodes,
        );
    }

    private function sanitize_node( $node, int $depth, int &$count, ?string $parent_type, array &$seen_node_ids ) {
        if ( ! is_array( $node ) || $depth > 20 || ++$count > 500 ) {
            return new WP_Error( 'scfvb_invalid_tree', 'The layout tree is invalid or too deeply nested.', array( 'status' => 400 ) );
        }

        $type = isset( $node['type'] ) ? sanitize_key( $node['type'] ) : '';
        if ( ! in_array( $type, self::ALLOWED_TYPES, true ) ) {
            return new WP_Error( 'scfvb_invalid_node_type', 'Unsupported node type.', array( 'status' => 400 ) );
        }

        if ( ! $this->can_contain( $parent_type, $type ) ) {
            return new WP_Error(
                'scfvb_invalid_hierarchy',
                sprintf( 'A %s element cannot be placed inside %s.', $type, null === $parent_type ? 'the page root' : $parent_type ),
                array( 'status' => 400 )
            );
        }

        $id = isset( $node['id'] ) ? sanitize_key( $node['id'] ) : '';
        if ( ! preg_match( '/^node_[a-z0-9_-]{4,64}$/', $id ) ) {
            return new WP_Error( 'scfvb_invalid_node_id', 'Every node must have a stable node_* ID.', array( 'status' => 400 ) );
        }
        if ( isset( $seen_node_ids[ $id ] ) ) {
            return new WP_Error( 'scfvb_duplicate_node_id', sprintf( 'Duplicate node ID "%s" detected.', $id ), array( 'status' => 400 ) );
        }
        $seen_node_ids[ $id ] = true;

        $bindings = $this->sanitize_bindings(
            isset( $node['bindings'] ) && is_array( $node['bindings'] ) ? $node['bindings'] : array(),
            $type
        );
        if ( is_wp_error( $bindings ) ) {
            return $bindings;
        }

        $clean = array(
            'id'       => $id,
            'type'     => $type,
            'name'     => isset( $node['name'] ) ? sanitize_text_field( $node['name'] ) : ucfirst( $type ),
            'settings' => $this->sanitize_settings( isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : array(), $type ),
            'content'  => $this->sanitize_content( isset( $node['content'] ) && is_array( $node['content'] ) ? $node['content'] : array() ),
            'bindings' => $bindings,
            'styles'   => $this->sanitize_styles( isset( $node['styles'] ) && is_array( $node['styles'] ) ? $node['styles'] : array(), $type ),
            'children' => array(),
        );

        $children = isset( $node['children'] ) && is_array( $node['children'] ) ? $node['children'] : array();
        if ( ! empty( $children ) && ! in_array( $type, array( 'section', 'container' ), true ) ) {
            return new WP_Error( 'scfvb_leaf_has_children', sprintf( 'The %s element cannot contain child elements.', $type ), array( 'status' => 400 ) );
        }

        foreach ( $children as $child ) {
            $clean_child = $this->sanitize_node( $child, $depth + 1, $count, $type, $seen_node_ids );
            if ( is_wp_error( $clean_child ) ) {
                return $clean_child;
            }
            $clean['children'][] = $clean_child;
        }

        return $clean;
    }

    private function can_contain( ?string $parent_type, string $child_type ): bool {
        if ( null === $parent_type ) {
            return 'section' === $child_type;
        }
        if ( 'section' === $parent_type ) {
            return 'container' === $child_type;
        }
        if ( 'container' === $parent_type ) {
            return in_array( $child_type, array( 'container', 'heading', 'text', 'image', 'button' ), true );
        }
        return false;
    }

    private function sanitize_settings( array $settings, string $node_type ): array {
        $clean = array();
        if ( 'heading' === $node_type && isset( $settings['tag'] ) ) {
            $tag = strtolower( sanitize_key( $settings['tag'] ) );
            if ( in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
                $clean['tag'] = $tag;
            }
        }
        return $clean;
    }

    private function sanitize_content( array $content ): array {
        $clean = array();
        if ( isset( $content['text'] ) ) {
            $clean['text'] = sanitize_textarea_field( $content['text'] );
        }
        if ( isset( $content['label'] ) ) {
            $clean['label'] = sanitize_text_field( $content['label'] );
        }
        if ( isset( $content['url'] ) ) {
            $clean['url'] = esc_url_raw( $content['url'] );
        }
        if ( isset( $content['imageId'] ) ) {
            $clean['imageId'] = absint( $content['imageId'] );
        }
        if ( isset( $content['imageUrl'] ) ) {
            $clean['imageUrl'] = esc_url_raw( $content['imageUrl'] );
        }
        return $clean;
    }

    private function binding_schema( string $node_type ): array {
        $schema = array(
            'heading' => array( 'text' => array( 'text' ) ),
            'text'    => array( 'text' => array( 'text', 'textarea' ) ),
            'image'   => array( 'image' => array( 'image' ) ),
            'button'  => array( 'label' => array( 'text' ), 'url' => array( 'url' ) ),
        );
        return $schema[ $node_type ] ?? array();
    }

    private function sanitize_bindings( array $bindings, string $node_type ) {
        $clean = array();
        foreach ( $this->binding_schema( $node_type ) as $key => $allowed_types ) {
            if ( empty( $bindings[ $key ] ) || ! is_array( $bindings[ $key ] ) ) {
                continue;
            }

            $binding = $bindings[ $key ];
            $source = isset( $binding['source'] ) && 'scf' === $binding['source'] ? 'scf' : 'static';
            $field_key = isset( $binding['fieldKey'] ) ? sanitize_key( $binding['fieldKey'] ) : '';
            $field_name = isset( $binding['fieldName'] ) ? sanitize_key( $binding['fieldName'] ) : '';
            $field_type = isset( $binding['fieldType'] ) ? sanitize_key( $binding['fieldType'] ) : $allowed_types[0];
            $label = isset( $binding['label'] ) ? sanitize_text_field( $binding['label'] ) : ucwords( str_replace( '_', ' ', $field_name ) );

            if ( ! in_array( $field_type, $allowed_types, true ) ) {
                if ( 'scf' === $source ) {
                    return new WP_Error(
                        'scfvb_invalid_field_type',
                        sprintf( 'Field type "%s" is not valid for the %s binding on a %s element.', $field_type, $key, $node_type ),
                        array( 'status' => 400 )
                    );
                }
                $field_type = $allowed_types[0];
            }

            $item = array(
                'source'    => $source,
                'fieldType' => $field_type,
            );

            if ( $field_key && preg_match( '/^field_scfvb_[a-z0-9_-]{4,64}$/', $field_key ) ) {
                $item['fieldKey'] = $field_key;
            }
            if ( $field_name ) {
                $item['fieldName'] = $field_name;
            }
            if ( $label ) {
                $item['label'] = $label;
            }

            if ( 'scf' === $source ) {
                if ( empty( $item['fieldKey'] ) || empty( $item['fieldName'] ) ) {
                    return new WP_Error(
                        'scfvb_invalid_scf_binding',
                        sprintf( 'The %s binding on %s is missing a valid stable field key or field name.', $key, $node_type ),
                        array( 'status' => 400 )
                    );
                }
            }

            $clean[ $key ] = $item;
        }
        return $clean;
    }

    private function sanitize_styles( array $styles, string $node_type ): array {
        $clean = array( 'desktop' => array(), 'laptop' => array(), 'tablet' => array(), 'mobile' => array() );
        foreach ( $clean as $breakpoint => $_ ) {
            if ( empty( $styles[ $breakpoint ] ) || ! is_array( $styles[ $breakpoint ] ) ) {
                continue;
            }
            foreach ( self::ALLOWED_STYLE_KEYS as $key ) {
                if ( ! array_key_exists( $key, $styles[ $breakpoint ] ) ) {
                    continue;
                }

                $container_only = array(
                    'flexDirection', 'justifyContent', 'alignItems', 'gap',
                    'gridTemplateColumns', 'gridTemplateRows', 'columnGap', 'rowGap', 'gridAutoFlow',
                    'overflow', 'backgroundType', 'backgroundImageId', 'backgroundImageUrl',
                    'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment',
                );
                if ( in_array( $key, $container_only, true ) && ! in_array( $node_type, array( 'section', 'container' ), true ) ) {
                    continue;
                }
                if ( in_array( $key, array( 'objectFit', 'objectPosition', 'aspectRatio' ), true ) && 'image' !== $node_type ) {
                    continue;
                }

                if ( 'backgroundImageId' === $key ) {
                    $clean[ $breakpoint ][ $key ] = absint( $styles[ $breakpoint ][ $key ] );
                    continue;
                }

                if ( 'backgroundImageUrl' === $key ) {
                    $raw_url = trim( (string) $styles[ $breakpoint ][ $key ] );
                    if ( 'none' === $raw_url ) {
                        $clean[ $breakpoint ][ $key ] = 'none';
                    } elseif ( '' === $raw_url ) {
                        $clean[ $breakpoint ][ $key ] = '';
                    } else {
                        $url = esc_url_raw( $raw_url );
                        if ( $url ) {
                            $clean[ $breakpoint ][ $key ] = $url;
                        }
                    }
                    continue;
                }

                $value = sanitize_text_field( (string) $styles[ $breakpoint ][ $key ] );
                if ( strlen( $value ) <= 120 ) {
                    $clean[ $breakpoint ][ $key ] = $value;
                }
            }
        }
        return $clean;
    }

    private function validate_unique_field_bindings( array $layout ) {
        $seen_names = array();
        $seen_keys = array();
        $error = null;

        $walk = function ( array $nodes ) use ( &$walk, &$seen_names, &$seen_keys, &$error ): void {
            foreach ( $nodes as $node ) {
                if ( $error ) {
                    return;
                }

                foreach ( $node['bindings'] ?? array() as $binding ) {
                    if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
                        continue;
                    }

                    $field_key = $binding['fieldKey'] ?? '';
                    $field_name = $binding['fieldName'] ?? '';

                    if ( isset( $seen_keys[ $field_key ] ) ) {
                        $error = new WP_Error(
                            'scfvb_duplicate_field_key',
                            sprintf( 'SCF field key "%s" is used more than once. Each editable binding must have a unique stable key.', $field_key ),
                            array( 'status' => 400 )
                        );
                        return;
                    }
                    $seen_keys[ $field_key ] = true;

                    if ( isset( $seen_names[ $field_name ] ) ) {
                        $error = new WP_Error(
                            'scfvb_duplicate_field_name',
                            sprintf( 'SCF field name "%s" is used more than once. Field names must be unique on a page.', $field_name ),
                            array( 'status' => 400 )
                        );
                        return;
                    }
                    $seen_names[ $field_name ] = true;
                }

                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };

        $walk( $layout['nodes'] ?? array() );
        return $error ?: true;
    }

    private function collect_field_bindings( array $layout, bool $only_scf = true ): array {
        $fields = array();
        $walk = function ( array $nodes ) use ( &$walk, &$fields, $only_scf ): void {
            foreach ( $nodes as $node ) {
                foreach ( $node['bindings'] ?? array() as $binding ) {
                    $has_identity = ! empty( $binding['fieldKey'] ) && ! empty( $binding['fieldName'] );
                    $active = 'scf' === ( $binding['source'] ?? 'static' );
                    if ( $has_identity && ( ! $only_scf || $active ) ) {
                        $fields[ $binding['fieldKey'] ] = $binding;
                    }
                }
                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };
        $walk( $layout['nodes'] ?? array() );
        return $fields;
    }

    private function migrate_renamed_fields( int $post_id, array $old_layout, array $new_layout ) {
        $old_fields = $this->collect_field_bindings( $old_layout, false );
        $new_fields = $this->collect_field_bindings( $new_layout, false );
        $renames = array();

        // Preflight every rename before mutating post meta. This prevents a later
        // conflict from leaving earlier fields half-migrated while the layout save fails.
        foreach ( $new_fields as $field_key => $new_field ) {
            if ( empty( $old_fields[ $field_key ] ) ) {
                continue;
            }

            $old_name = $old_fields[ $field_key ]['fieldName'];
            $new_name = $new_field['fieldName'];
            if ( $old_name === $new_name ) {
                continue;
            }

            $has_old = metadata_exists( 'post', $post_id, $old_name );
            $has_new = metadata_exists( 'post', $post_id, $new_name );
            $new_reference_key = '_' . $new_name;
            $has_new_reference = metadata_exists( 'post', $post_id, $new_reference_key );
            $new_reference = $has_new_reference ? (string) get_post_meta( $post_id, $new_reference_key, true ) : '';

            if ( $has_old && $has_new ) {
                return new WP_Error(
                    'scfvb_field_rename_conflict',
                    sprintf( 'Cannot rename "%s" to "%s" because the destination meta key already contains data.', $old_name, $new_name ),
                    array( 'status' => 409 )
                );
            }

            if ( $has_new_reference && $new_reference && $new_reference !== $field_key ) {
                return new WP_Error(
                    'scfvb_field_reference_conflict',
                    sprintf( 'Cannot rename "%s" to "%s" because the destination field reference belongs to another SCF field.', $old_name, $new_name ),
                    array( 'status' => 409 )
                );
            }

            $renames[] = array(
                'field_key' => $field_key,
                'old_name'  => $old_name,
                'new_name'  => $new_name,
                'has_old'   => $has_old,
            );
        }

        foreach ( $renames as $rename ) {
            if ( $rename['has_old'] ) {
                update_post_meta( $post_id, $rename['new_name'], get_post_meta( $post_id, $rename['old_name'], true ) );
                delete_post_meta( $post_id, $rename['old_name'] );
            }

            update_post_meta( $post_id, '_' . $rename['new_name'], $rename['field_key'] );
            delete_post_meta( $post_id, '_' . $rename['old_name'] );
        }

        return true;
    }
}
