# SCF Visual Builder v0.1.1

A schema-aware visual page builder for WordPress Pages that can create Secure Custom Fields bindings directly from the visual editor.

## v0.1 workflow

1. Go to **Pages** and choose **Edit with Visual Builder**.
2. Add a **Section**.
3. Select the Section and add a **Container**.
4. Select the Container and add Heading, Text, Image, or Button elements.
5. Configure layout and responsive styles in the Inspector.
6. For content that should be editable outside the design, enable **Editable with SCF**.
7. Save the layout.
8. Use **Edit SCF Content** to edit the generated SCF fields on the normal WordPress Page editor.
9. The normal page content area is replaced with the rendered builder layout on the frontend.

## Included in v0.1

- Section and Container layout elements.
- Heading, Text, Image, and Button content elements.
- Flexbox direction, alignment, justification, gap, dimensions, padding, margins, colors, typography, borders, and radius.
- Desktop, tablet, and mobile style layers with cascading preview behavior.
- Navigator tree.
- Drag a node onto a compatible Section/Container to re-parent it.
- Move up/down, duplicate, delete.
- Undo/redo (60-state history).
- JSON layout persistence in `_scfvb_layout`.
- REST API save/load with `edit_post` capability checks and WordPress REST nonces.
- Static content or SCF-backed content.
- Automatic local SCF field groups targeted to the specific WordPress Page.
- Stable `field_scfvb_*` keys.
- Duplicate active field-name validation.
- Safe post-meta migration when an existing bound field is renamed.
- Frontend PHP renderer with CSS value allowlisting and context-aware escaping.

## Intentional v0.1 limits

- The builder owns the WordPress Page content area only; the active theme still owns the header, footer, and outer template.
- Layout is flexbox-first. CSS Grid and free/absolute positioning are not implemented yet.
- Repeater, Group, Flexible Content, templates/components, animations, custom CSS, and dynamic queries are not part of v0.1.
- Dragging is for tree re-parenting. Sibling ordering is handled with the Navigator up/down actions.
- SCF values are edited on the normal WordPress Page edit screen in this version; the visual canvas displays the builder's design-time fallback content.

## Requirements

- WordPress 6.5+
- PHP 8.0+
- Secure Custom Fields for editable SCF bindings

SCF 6.9.5 and WordPress 7.1 were the current releases when this v0.1 package was assembled. The package was syntax-checked locally but should still be installed on a staging WordPress site before production use.


## 0.1.1

- Added a frontend WordPress admin-bar **Edit with Visual Builder** action on editable pages.
- Builder output now uses an `alignfull` wrapper and removes its own max-width so `width: 100%` sections can use the full available content width in block themes.
