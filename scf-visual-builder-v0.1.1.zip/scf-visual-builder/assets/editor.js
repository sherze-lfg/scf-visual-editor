(function () {
    'use strict';

    const config = window.SCFVB_CONFIG || {};
    const { createElement: h, Fragment, useEffect, useMemo, useState } = wp.element;
    const { Button, Spinner, Notice } = wp.components;
    const apiFetch = wp.apiFetch;

    if (apiFetch && apiFetch.createNonceMiddleware && config.nonce) {
        apiFetch.use(apiFetch.createNonceMiddleware(config.nonce));
    }

    const CONTENT_TYPES = ['heading', 'text', 'image', 'button'];
    const CONTAINER_TYPES = ['section', 'container'];
    const BREAKPOINTS = ['desktop', 'tablet', 'mobile'];

    function token() {
        if (window.crypto && window.crypto.randomUUID) {
            return window.crypto.randomUUID().replace(/-/g, '').slice(0, 10);
        }
        return (Date.now().toString(36) + Math.random().toString(36).slice(2)).slice(0, 10);
    }

    function nodeId() {
        return 'node_' + token();
    }

    function fieldKey() {
        return 'field_scfvb_' + token();
    }

    function slugify(value) {
        const slug = String(value || '')
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '');
        return slug || 'field';
    }

    function emptyStyles() {
        return { desktop: {}, tablet: {}, mobile: {} };
    }

    function baseStyles(type) {
        const styles = emptyStyles();
        if (type === 'section') {
            styles.desktop = {
                display: 'flex', width: '100%', minHeight: '300px',
                paddingTop: '48px', paddingRight: '24px', paddingBottom: '48px', paddingLeft: '24px',
                flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'stretch', gap: '16px',
                backgroundColor: '#ffffff'
            };
        } else if (type === 'container') {
            styles.desktop = {
                display: 'flex', width: '100%', flexDirection: 'column',
                justifyContent: 'flex-start', alignItems: 'stretch', gap: '16px'
            };
        } else if (type === 'heading') {
            styles.desktop = {
                width: 'auto', marginTop: '0px', marginBottom: '8px',
                color: '#111111', fontSize: '48px', fontWeight: '700', textAlign: 'left'
            };
        } else if (type === 'text') {
            styles.desktop = {
                width: 'auto', marginTop: '0px', marginBottom: '8px',
                color: '#333333', fontSize: '18px', fontWeight: '400', textAlign: 'left'
            };
        } else if (type === 'image') {
            styles.desktop = { width: '100%', borderWidth: '0px', borderColor: '#dddddd', borderRadius: '0px' };
        } else if (type === 'button') {
            styles.desktop = {
                display: 'inline-block', width: 'auto',
                paddingTop: '12px', paddingRight: '20px', paddingBottom: '12px', paddingLeft: '20px',
                backgroundColor: '#111111', color: '#ffffff', fontSize: '16px', fontWeight: '600',
                borderWidth: '0px', borderColor: '#111111', borderRadius: '4px', textAlign: 'center'
            };
        }
        return styles;
    }

    function newNode(type) {
        const id = nodeId();
        const common = {
            id,
            type,
            name: type.charAt(0).toUpperCase() + type.slice(1),
            settings: {},
            content: {},
            bindings: {},
            styles: baseStyles(type),
            children: []
        };

        if (type === 'section') common.name = 'Section';
        if (type === 'container') common.name = 'Container';
        if (type === 'heading') {
            common.name = 'Heading';
            common.settings.tag = 'h2';
            common.content.text = 'Your heading';
            common.bindings.text = { source: 'static', fieldType: 'text' };
        }
        if (type === 'text') {
            common.name = 'Text';
            common.content.text = 'Add your text here.';
            common.bindings.text = { source: 'static', fieldType: 'textarea' };
        }
        if (type === 'image') {
            common.name = 'Image';
            common.content.imageId = 0;
            common.content.imageUrl = '';
            common.bindings.image = { source: 'static', fieldType: 'image' };
        }
        if (type === 'button') {
            common.name = 'Button';
            common.content.label = 'Button';
            common.content.url = '#';
            common.bindings.label = { source: 'static', fieldType: 'text' };
            common.bindings.url = { source: 'static', fieldType: 'url' };
        }
        return common;
    }

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function findNode(nodes, id) {
        for (const node of nodes || []) {
            if (node.id === id) return node;
            const child = findNode(node.children || [], id);
            if (child) return child;
        }
        return null;
    }

    function findParentId(nodes, id, parentIdValue) {
        for (const node of nodes || []) {
            if (node.id === id) return parentIdValue || null;
            const found = findParentId(node.children || [], id, node.id);
            if (found !== undefined) return found;
        }
        return undefined;
    }

    function updateNode(nodes, id, updater) {
        return (nodes || []).map((node) => {
            if (node.id === id) return updater(clone(node));
            if (node.children && node.children.length) {
                return Object.assign({}, node, { children: updateNode(node.children, id, updater) });
            }
            return node;
        });
    }

    function removeNode(nodes, id) {
        let removed = null;
        const next = [];
        for (const node of nodes || []) {
            if (node.id === id) {
                removed = node;
                continue;
            }
            if (node.children && node.children.length) {
                const childResult = removeNode(node.children, id);
                if (childResult.removed) {
                    removed = childResult.removed;
                    next.push(Object.assign({}, node, { children: childResult.nodes }));
                    continue;
                }
            }
            next.push(node);
        }
        return { nodes: next, removed };
    }

    function insertChild(nodes, parentIdValue, child) {
        if (!parentIdValue) return [...nodes, child];
        return updateNode(nodes, parentIdValue, (node) => {
            node.children = [...(node.children || []), child];
            return node;
        });
    }

    function isDescendant(node, id) {
        for (const child of node.children || []) {
            if (child.id === id || isDescendant(child, id)) return true;
        }
        return false;
    }

    function canContain(parentType, childType) {
        if (!parentType) return childType === 'section';
        if (parentType === 'section') return childType === 'container';
        if (parentType === 'container') return childType === 'container' || CONTENT_TYPES.includes(childType);
        return false;
    }

    function moveSibling(nodes, id, delta) {
        const copy = clone(nodes);
        function walk(list) {
            const index = list.findIndex((n) => n.id === id);
            if (index >= 0) {
                const target = index + delta;
                if (target >= 0 && target < list.length) {
                    const temp = list[index];
                    list[index] = list[target];
                    list[target] = temp;
                }
                return true;
            }
            for (const node of list) {
                if (walk(node.children || [])) return true;
            }
            return false;
        }
        walk(copy);
        return copy;
    }

    function duplicateNodeTree(node) {
        const copy = clone(node);
        function remap(item) {
            item.id = nodeId();
            item.name = item.name + ' Copy';
            Object.keys(item.bindings || {}).forEach((key) => {
                const binding = item.bindings[key];
                if (binding.fieldKey) binding.fieldKey = fieldKey();
                if (binding.fieldName) binding.fieldName = binding.fieldName + '_copy_' + token().slice(0, 4);
            });
            (item.children || []).forEach(remap);
        }
        remap(copy);
        return copy;
    }

    function effectiveStyles(node, breakpoint) {
        const desktop = (node.styles && node.styles.desktop) || {};
        if (breakpoint === 'desktop') return Object.assign({}, desktop);
        const tablet = (node.styles && node.styles.tablet) || {};
        if (breakpoint === 'tablet') return Object.assign({}, desktop, tablet);
        return Object.assign({}, desktop, tablet, (node.styles && node.styles.mobile) || {});
    }

    function toReactStyle(styles) {
        const style = Object.assign({}, styles || {});
        if (style.borderWidth && style.borderWidth !== '0' && style.borderWidth !== '0px') {
            style.borderStyle = 'solid';
        }
        return style;
    }

    function useHistoryState(initialValue) {
        const [history, setHistory] = useState({ past: [], present: initialValue, future: [] });

        function reset(value) {
            setHistory({ past: [], present: value, future: [] });
        }

        function commit(valueOrFn) {
            setHistory((current) => {
                const next = typeof valueOrFn === 'function' ? valueOrFn(current.present) : valueOrFn;
                if (next === current.present) return current;
                return {
                    past: [...current.past, current.present].slice(-60),
                    present: next,
                    future: []
                };
            });
        }

        function undo() {
            setHistory((current) => {
                if (!current.past.length) return current;
                const previous = current.past[current.past.length - 1];
                return {
                    past: current.past.slice(0, -1),
                    present: previous,
                    future: [current.present, ...current.future]
                };
            });
        }

        function redo() {
            setHistory((current) => {
                if (!current.future.length) return current;
                const next = current.future[0];
                return {
                    past: [...current.past, current.present],
                    present: next,
                    future: current.future.slice(1)
                };
            });
        }

        return { history, reset, commit, undo, redo };
    }

    function LabeledInput(props) {
        return h('label', { className: 'scfvb-field' },
            h('span', null, props.label),
            h('input', {
                type: props.type || 'text',
                value: props.value == null ? '' : props.value,
                min: props.min,
                max: props.max,
                step: props.step,
                onChange: (event) => props.onChange(event.target.value)
            })
        );
    }

    function LabeledSelect(props) {
        return h('label', { className: 'scfvb-field' },
            h('span', null, props.label),
            h('select', { value: props.value, onChange: (event) => props.onChange(event.target.value) },
                props.options.map((option) => {
                    const value = typeof option === 'string' ? option : option.value;
                    const label = typeof option === 'string' ? option : option.label;
                    return h('option', { key: value, value }, label);
                })
            )
        );
    }

    function SectionTitle(props) {
        return h('h3', { className: 'scfvb-inspector-title' }, props.children);
    }

    function App() {
        const initial = { version: 1, nodes: [] };
        const { history, reset, commit, undo, redo } = useHistoryState(initial);
        const [selectedId, setSelectedId] = useState(null);
        const [breakpoint, setBreakpoint] = useState('desktop');
        const [loading, setLoading] = useState(true);
        const [saving, setSaving] = useState(false);
        const [notice, setNotice] = useState(null);
        const [savedSnapshot, setSavedSnapshot] = useState(JSON.stringify(initial));

        const layout = history.present;
        const selected = useMemo(() => selectedId ? findNode(layout.nodes, selectedId) : null, [layout, selectedId]);
        const dirty = JSON.stringify(layout) !== savedSnapshot;

        useEffect(() => {
            apiFetch({ path: config.restPath }).then((response) => {
                const loaded = response && response.layout ? response.layout : initial;
                reset(loaded);
                setSavedSnapshot(JSON.stringify(loaded));
                setLoading(false);
            }).catch((error) => {
                setNotice({ status: 'error', message: error.message || 'Could not load the layout.' });
                setLoading(false);
            });
        }, []);

        useEffect(() => {
            function keydown(event) {
                const activeTag = document.activeElement && document.activeElement.tagName;
                if (['INPUT', 'TEXTAREA', 'SELECT'].includes(activeTag)) return;
                const meta = event.ctrlKey || event.metaKey;
                if (meta && event.key.toLowerCase() === 'z') {
                    event.preventDefault();
                    if (event.shiftKey) redo(); else undo();
                }
            }
            window.addEventListener('keydown', keydown);
            return () => window.removeEventListener('keydown', keydown);
        });

        function showMessage(message, status) {
            setNotice({ message, status: status || 'info' });
        }

        function updateSelected(updater) {
            if (!selectedId) return;
            commit((current) => Object.assign({}, current, {
                nodes: updateNode(current.nodes, selectedId, updater)
            }));
        }

        function addElement(type) {
            const child = newNode(type);
            if (type === 'section') {
                commit((current) => Object.assign({}, current, { nodes: [...current.nodes, child] }));
                setSelectedId(child.id);
                return;
            }

            if (!selected) {
                showMessage(type === 'container' ? 'Select a Section or Container first.' : 'Select a Container first.', 'warning');
                return;
            }

            if (!canContain(selected.type, type)) {
                showMessage(type === 'container' ? 'Containers can be placed inside Sections or Containers.' : 'Content elements must be placed inside a Container.', 'warning');
                return;
            }

            commit((current) => Object.assign({}, current, { nodes: insertChild(current.nodes, selected.id, child) }));
            setSelectedId(child.id);
        }

        function deleteSelected() {
            if (!selected) return;
            commit((current) => Object.assign({}, current, { nodes: removeNode(current.nodes, selected.id).nodes }));
            setSelectedId(null);
        }

        function duplicateSelected() {
            if (!selected) return;
            const parentIdValue = findParentId(layout.nodes, selected.id);
            const copy = duplicateNodeTree(selected);
            commit((current) => Object.assign({}, current, { nodes: insertChild(current.nodes, parentIdValue, copy) }));
            setSelectedId(copy.id);
        }

        function moveSelected(delta) {
            if (!selected) return;
            commit((current) => Object.assign({}, current, { nodes: moveSibling(current.nodes, selected.id, delta) }));
        }

        function moveInto(draggedId, targetId) {
            if (!draggedId || !targetId || draggedId === targetId) return;
            const dragged = findNode(layout.nodes, draggedId);
            const target = findNode(layout.nodes, targetId);
            if (!dragged || !target || isDescendant(dragged, targetId) || !canContain(target.type, dragged.type)) {
                showMessage('That element cannot be nested there.', 'warning');
                return;
            }
            commit((current) => {
                const result = removeNode(current.nodes, draggedId);
                if (!result.removed) return current;
                return Object.assign({}, current, { nodes: insertChild(result.nodes, targetId, result.removed) });
            });
        }

        function save() {
            setSaving(true);
            setNotice(null);
            apiFetch({
                path: config.restPath,
                method: 'PUT',
                data: { layout }
            }).then((response) => {
                const saved = response && response.layout ? response.layout : layout;
                reset(saved);
                setSavedSnapshot(JSON.stringify(saved));
                setSaving(false);
                showMessage('Layout saved. SCF fields are registered on the next WordPress request.', 'success');
            }).catch((error) => {
                setSaving(false);
                showMessage(error.message || 'Could not save the layout.', 'error');
            });
        }

        if (loading) {
            return h('div', { className: 'scfvb-loading' }, h(Spinner), h('span', null, 'Loading builder…'));
        }

        return h('div', { className: 'scfvb-app' },
            h(Toolbar, {
                breakpoint, setBreakpoint, undo, redo,
                canUndo: history.past.length > 0,
                canRedo: history.future.length > 0,
                dirty, save, saving
            }),
            notice && h('div', { className: 'scfvb-notice-wrap' },
                h(Notice, { status: notice.status, isDismissible: true, onRemove: () => setNotice(null) }, notice.message)
            ),
            !config.scfAvailable && h('div', { className: 'scfvb-notice-wrap' },
                h(Notice, { status: 'warning', isDismissible: false }, 'Secure Custom Fields is not active. Static layouts work, but Editable bindings will not be available until SCF is active.')
            ),
            h('div', { className: 'scfvb-workspace' },
                h(ElementPanel, { addElement }),
                h('main', { className: 'scfvb-center' },
                    h(Canvas, { layout, selectedId, setSelectedId, breakpoint, moveInto }),
                    h(Navigator, {
                        nodes: layout.nodes, selectedId, setSelectedId, moveInto,
                        moveSelected, deleteSelected, duplicateSelected
                    })
                ),
                h(Inspector, {
                    node: selected,
                    breakpoint,
                    updateSelected,
                    scfAvailable: !!config.scfAvailable
                })
            )
        );
    }

    function Toolbar(props) {
        return h('header', { className: 'scfvb-toolbar' },
            h('div', { className: 'scfvb-toolbar-left' },
                h('a', { className: 'scfvb-link', href: config.pagesUrl }, '← Pages'),
                h('strong', null, config.postTitle || 'Page'),
                props.dirty && h('span', { className: 'scfvb-dirty' }, 'Unsaved')
            ),
            h('div', { className: 'scfvb-toolbar-center' },
                BREAKPOINTS.map((bp) => h(Button, {
                    key: bp,
                    variant: props.breakpoint === bp ? 'primary' : 'secondary',
                    size: 'compact',
                    onClick: () => props.setBreakpoint(bp)
                }, bp.charAt(0).toUpperCase() + bp.slice(1)))
            ),
            h('div', { className: 'scfvb-toolbar-right' },
                h(Button, { variant: 'secondary', disabled: !props.canUndo, onClick: props.undo }, 'Undo'),
                h(Button, { variant: 'secondary', disabled: !props.canRedo, onClick: props.redo }, 'Redo'),
                h('a', { className: 'button', href: config.editUrl }, 'Edit SCF Content'),
                h('a', { className: 'button', href: config.viewUrl, target: '_blank', rel: 'noreferrer' }, 'View'),
                h(Button, { variant: 'primary', disabled: props.saving || !props.dirty, onClick: props.save }, props.saving ? 'Saving…' : 'Save')
            )
        );
    }

    function ElementPanel(props) {
        return h('aside', { className: 'scfvb-sidebar scfvb-elements' },
            h('h2', null, 'Elements'),
            h('div', { className: 'scfvb-palette-group' },
                h('h3', null, 'Layout'),
                h('button', { type: 'button', onClick: () => props.addElement('section') }, 'Section'),
                h('button', { type: 'button', onClick: () => props.addElement('container') }, 'Container')
            ),
            h('div', { className: 'scfvb-palette-group' },
                h('h3', null, 'Content'),
                h('button', { type: 'button', onClick: () => props.addElement('heading') }, 'Heading'),
                h('button', { type: 'button', onClick: () => props.addElement('text') }, 'Text'),
                h('button', { type: 'button', onClick: () => props.addElement('image') }, 'Image'),
                h('button', { type: 'button', onClick: () => props.addElement('button') }, 'Button')
            ),
            h('p', { className: 'description' }, 'Build Section → Container → Content. Drag nodes onto compatible containers to re-parent them.')
        );
    }

    function Canvas(props) {
        const widthClass = 'scfvb-canvas-' + props.breakpoint;
        return h('section', { className: 'scfvb-canvas-shell' },
            h('div', { className: 'scfvb-canvas-header' },
                h('strong', null, 'Canvas'),
                h('span', null, props.breakpoint)
            ),
            h('div', { className: 'scfvb-canvas ' + widthClass },
                props.layout.nodes.length
                    ? props.layout.nodes.map((node) => h(PreviewNode, {
                        key: node.id,
                        node,
                        breakpoint: props.breakpoint,
                        selectedId: props.selectedId,
                        setSelectedId: props.setSelectedId,
                        moveInto: props.moveInto
                    }))
                    : h('div', { className: 'scfvb-empty-canvas' }, 'Add a Section to begin.')
            )
        );
    }

    function PreviewNode(props) {
        const node = props.node;
        const selected = props.selectedId === node.id;
        const styles = toReactStyle(effectiveStyles(node, props.breakpoint));
        const className = 'scfvb-preview-node scfvb-preview-' + node.type + (selected ? ' is-selected' : '');
        const canDrop = CONTAINER_TYPES.includes(node.type);

        const common = {
            className,
            style: styles,
            draggable: true,
            onClick: (event) => { event.stopPropagation(); props.setSelectedId(node.id); },
            onDragStart: (event) => {
                event.stopPropagation();
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('text/scfvb-node', node.id);
            },
            onDragOver: canDrop ? (event) => { event.preventDefault(); event.dataTransfer.dropEffect = 'move'; } : undefined,
            onDrop: canDrop ? (event) => {
                event.preventDefault();
                event.stopPropagation();
                props.moveInto(event.dataTransfer.getData('text/scfvb-node'), node.id);
            } : undefined,
            title: node.name + ' (' + node.type + ')'
        };

        if (node.type === 'section' || node.type === 'container') {
            return h(node.type === 'section' ? 'section' : 'div', common,
                h('span', { className: 'scfvb-node-label' }, node.name),
                (node.children || []).length
                    ? node.children.map((child) => h(PreviewNode, {
                        key: child.id,
                        node: child,
                        breakpoint: props.breakpoint,
                        selectedId: props.selectedId,
                        setSelectedId: props.setSelectedId,
                        moveInto: props.moveInto
                    }))
                    : h('div', { className: 'scfvb-empty-node' }, node.type === 'section' ? 'Add a Container' : 'Add content')
            );
        }

        if (node.type === 'heading') {
            const tag = (node.settings && node.settings.tag) || 'h2';
            return h(tag, common,
                node.content.text || 'Heading',
                isScf(node.bindings.text) && h('span', { className: 'scfvb-scf-badge' }, 'SCF')
            );
        }

        if (node.type === 'text') {
            return h('div', common,
                h('p', null, node.content.text || 'Text'),
                isScf(node.bindings.text) && h('span', { className: 'scfvb-scf-badge' }, 'SCF')
            );
        }

        if (node.type === 'image') {
            if (node.content.imageUrl) {
                return h('div', Object.assign({}, common, { style: {} }),
                    h('img', { src: node.content.imageUrl, alt: '', style: styles }),
                    isScf(node.bindings.image) && h('span', { className: 'scfvb-scf-badge' }, 'SCF')
                );
            }
            return h('div', common,
                h('div', { className: 'scfvb-image-placeholder' }, 'Image'),
                isScf(node.bindings.image) && h('span', { className: 'scfvb-scf-badge' }, 'SCF')
            );
        }

        if (node.type === 'button') {
            return h('span', common,
                node.content.label || 'Button',
                (isScf(node.bindings.label) || isScf(node.bindings.url)) && h('span', { className: 'scfvb-scf-badge' }, 'SCF')
            );
        }

        return null;
    }

    function isScf(binding) {
        return binding && binding.source === 'scf';
    }

    function Navigator(props) {
        return h('section', { className: 'scfvb-navigator' },
            h('div', { className: 'scfvb-navigator-header' },
                h('strong', null, 'Navigator'),
                h('div', null,
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.moveSelected(-1) }, '↑'),
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.moveSelected(1) }, '↓'),
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: props.duplicateSelected }, 'Duplicate'),
                    h(Button, { size: 'compact', isDestructive: true, disabled: !props.selectedId, onClick: props.deleteSelected }, 'Delete')
                )
            ),
            h('div', { className: 'scfvb-tree' },
                props.nodes.length ? props.nodes.map((node) => h(NavigatorNode, {
                    key: node.id,
                    node,
                    depth: 0,
                    selectedId: props.selectedId,
                    setSelectedId: props.setSelectedId,
                    moveInto: props.moveInto
                })) : h('span', { className: 'description' }, 'No nodes yet.')
            )
        );
    }

    function NavigatorNode(props) {
        const node = props.node;
        const canDrop = CONTAINER_TYPES.includes(node.type);
        return h(Fragment, null,
            h('div', {
                className: 'scfvb-tree-row' + (props.selectedId === node.id ? ' is-selected' : ''),
                style: { paddingLeft: (8 + props.depth * 16) + 'px' },
                draggable: true,
                onClick: () => props.setSelectedId(node.id),
                onDragStart: (event) => {
                    event.dataTransfer.effectAllowed = 'move';
                    event.dataTransfer.setData('text/scfvb-node', node.id);
                },
                onDragOver: canDrop ? (event) => event.preventDefault() : undefined,
                onDrop: canDrop ? (event) => {
                    event.preventDefault();
                    props.moveInto(event.dataTransfer.getData('text/scfvb-node'), node.id);
                } : undefined
            },
                h('span', { className: 'scfvb-tree-type' }, node.type),
                h('span', { className: 'scfvb-tree-name' }, node.name),
                Object.values(node.bindings || {}).some(isScf) && h('span', { className: 'scfvb-tree-scf' }, 'SCF')
            ),
            (node.children || []).map((child) => h(NavigatorNode, {
                key: child.id,
                node: child,
                depth: props.depth + 1,
                selectedId: props.selectedId,
                setSelectedId: props.setSelectedId,
                moveInto: props.moveInto
            }))
        );
    }

    function Inspector(props) {
        const node = props.node;
        if (!node) {
            return h('aside', { className: 'scfvb-sidebar scfvb-inspector' },
                h('h2', null, 'Properties'),
                h('p', { className: 'description' }, 'Select an element on the canvas or in the Navigator.')
            );
        }

        function patchNode(patch) {
            props.updateSelected((copy) => Object.assign(copy, patch));
        }

        function patchContent(key, value) {
            props.updateSelected((copy) => {
                copy.content = Object.assign({}, copy.content, { [key]: value });
                return copy;
            });
        }

        function patchSetting(key, value) {
            props.updateSelected((copy) => {
                copy.settings = Object.assign({}, copy.settings, { [key]: value });
                return copy;
            });
        }

        function patchStyle(key, value) {
            props.updateSelected((copy) => {
                copy.styles = Object.assign({}, copy.styles || emptyStyles());
                copy.styles[props.breakpoint] = Object.assign({}, copy.styles[props.breakpoint] || {}, { [key]: value });
                return copy;
            });
        }

        function patchBinding(key, patch) {
            props.updateSelected((copy) => {
                const current = Object.assign({ source: 'static' }, (copy.bindings && copy.bindings[key]) || {});
                copy.bindings = Object.assign({}, copy.bindings, { [key]: Object.assign(current, patch) });
                return copy;
            });
        }

        function toggleBinding(key, fieldType, labelSuffix) {
            const current = (node.bindings && node.bindings[key]) || { source: 'static' };
            if (current.source === 'scf') {
                patchBinding(key, { source: 'static' });
                return;
            }
            if (!props.scfAvailable) return;
            const suffix = token().slice(0, 4);
            const baseName = slugify(node.name + (labelSuffix ? '_' + labelSuffix : ''));
            patchBinding(key, {
                source: 'scf',
                fieldKey: current.fieldKey || fieldKey(),
                fieldName: current.fieldName || (baseName + '_' + suffix),
                fieldType: current.fieldType || fieldType,
                label: current.label || (node.name + (labelSuffix ? ' ' + labelSuffix : ''))
            });
        }

        return h('aside', { className: 'scfvb-sidebar scfvb-inspector' },
            h('h2', null, 'Properties'),
            h(LabeledInput, { label: 'Name', value: node.name, onChange: (value) => patchNode({ name: value }) }),
            CONTENT_TYPES.includes(node.type) && h(ContentInspector, {
                node,
                patchContent,
                patchSetting,
                patchBinding,
                toggleBinding,
                scfAvailable: props.scfAvailable
            }),
            h(StyleInspector, { node, breakpoint: props.breakpoint, patchStyle })
        );
    }

    function ContentInspector(props) {
        const node = props.node;
        const rows = [];
        rows.push(h(SectionTitle, { key: 'title' }, 'Content'));

        if (node.type === 'heading' || node.type === 'text') {
            rows.push(h('label', { className: 'scfvb-field', key: 'text' },
                h('span', null, node.type === 'heading' ? 'Text' : 'Text'),
                h('textarea', { value: node.content.text || '', rows: node.type === 'text' ? 5 : 2, onChange: (e) => props.patchContent('text', e.target.value) })
            ));
            if (node.type === 'heading') {
                rows.push(h(LabeledSelect, {
                    key: 'tag', label: 'HTML Tag', value: (node.settings && node.settings.tag) || 'h2',
                    options: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], onChange: (value) => props.patchSetting('tag', value)
                }));
            }
            rows.push(h(BindingEditor, {
                key: 'binding', bindingKey: 'text', binding: node.bindings.text || { source: 'static' },
                fieldTypes: node.type === 'text' ? ['text', 'textarea'] : ['text'],
                defaultType: node.type === 'text' ? 'textarea' : 'text',
                toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        if (node.type === 'image') {
            rows.push(h('div', { className: 'scfvb-media-row', key: 'media' },
                node.content.imageUrl ? h('img', { src: node.content.imageUrl, alt: '' }) : h('div', { className: 'scfvb-media-empty' }, 'No image'),
                h(Button, { variant: 'secondary', onClick: () => openMedia(props.patchContent) }, 'Choose Image')
            ));
            rows.push(h(BindingEditor, {
                key: 'binding', bindingKey: 'image', binding: node.bindings.image || { source: 'static' },
                fieldTypes: ['image'], defaultType: 'image', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        if (node.type === 'button') {
            rows.push(h(LabeledInput, { key: 'label', label: 'Label', value: node.content.label || '', onChange: (value) => props.patchContent('label', value) }));
            rows.push(h(BindingEditor, {
                key: 'label-binding', title: 'Label Binding', bindingKey: 'label', binding: node.bindings.label || { source: 'static' },
                fieldTypes: ['text'], defaultType: 'text', labelSuffix: 'Label', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
            rows.push(h(LabeledInput, { key: 'url', label: 'URL', value: node.content.url || '', onChange: (value) => props.patchContent('url', value) }));
            rows.push(h(BindingEditor, {
                key: 'url-binding', title: 'URL Binding', bindingKey: 'url', binding: node.bindings.url || { source: 'static' },
                fieldTypes: ['url'], defaultType: 'url', labelSuffix: 'URL', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        return h(Fragment, null, rows);
    }

    function BindingEditor(props) {
        const binding = props.binding || { source: 'static' };
        const editable = binding.source === 'scf';
        return h('div', { className: 'scfvb-binding-box' },
            props.title && h('strong', null, props.title),
            h('label', { className: 'scfvb-toggle-row' },
                h('input', {
                    type: 'checkbox',
                    checked: editable,
                    disabled: !props.scfAvailable,
                    onChange: () => props.toggle(props.bindingKey, props.defaultType, props.labelSuffix)
                }),
                h('span', null, 'Editable with SCF')
            ),
            editable && h(Fragment, null,
                h(LabeledInput, {
                    label: 'Field Label', value: binding.label || '',
                    onChange: (value) => props.patch(props.bindingKey, { label: value })
                }),
                h(LabeledInput, {
                    label: 'Field Name', value: binding.fieldName || '',
                    onChange: (value) => props.patch(props.bindingKey, { fieldName: slugify(value) })
                }),
                h(LabeledSelect, {
                    label: 'Field Type', value: binding.fieldType || props.defaultType,
                    options: props.fieldTypes, onChange: (value) => props.patch(props.bindingKey, { fieldType: value })
                }),
                h('code', { className: 'scfvb-field-key' }, binding.fieldKey || '')
            )
        );
    }

    function openMedia(patchContent) {
        if (!wp.media) return;
        const frame = wp.media({ title: 'Select image', library: { type: 'image' }, multiple: false });
        frame.on('select', function () {
            const item = frame.state().get('selection').first().toJSON();
            patchContent('imageId', item.id || 0);
            patchContent('imageUrl', item.url || '');
        });
        frame.open();
    }

    function StyleInspector(props) {
        const node = props.node;
        const current = (node.styles && node.styles[props.breakpoint]) || {};
        const effective = effectiveStyles(node, props.breakpoint);
        const value = (key, fallback) => current[key] !== undefined ? current[key] : (effective[key] !== undefined ? effective[key] : fallback);
        const rows = [
            h(SectionTitle, { key: 'title' }, 'Style — ' + props.breakpoint)
        ];

        if (CONTAINER_TYPES.includes(node.type)) {
            rows.push(h(LabeledSelect, { key: 'direction', label: 'Direction', value: value('flexDirection', 'column'), options: ['row', 'column', 'row-reverse', 'column-reverse'], onChange: (v) => props.patchStyle('flexDirection', v) }));
            rows.push(h(LabeledSelect, { key: 'justify', label: 'Justify', value: value('justifyContent', 'flex-start'), options: ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], onChange: (v) => props.patchStyle('justifyContent', v) }));
            rows.push(h(LabeledSelect, { key: 'align', label: 'Align', value: value('alignItems', 'stretch'), options: ['stretch', 'flex-start', 'center', 'flex-end', 'baseline'], onChange: (v) => props.patchStyle('alignItems', v) }));
            rows.push(h(LabeledInput, { key: 'gap', label: 'Gap', value: value('gap', '16px'), onChange: (v) => props.patchStyle('gap', v) }));
            rows.push(h(LabeledInput, { key: 'minheight', label: 'Min Height', value: value('minHeight', ''), onChange: (v) => props.patchStyle('minHeight', v) }));
        }

        rows.push(h(LabeledInput, { key: 'width', label: 'Width', value: value('width', 'auto'), onChange: (v) => props.patchStyle('width', v) }));
        rows.push(h(LabeledInput, { key: 'height', label: 'Height', value: value('height', ''), onChange: (v) => props.patchStyle('height', v) }));

        ['Top', 'Right', 'Bottom', 'Left'].forEach((side) => {
            const key = 'margin' + side;
            rows.push(h(LabeledInput, { key, label: 'Margin ' + side, value: value(key, '0px'), onChange: (v) => props.patchStyle(key, v) }));
        });

        if (CONTAINER_TYPES.includes(node.type) || node.type === 'button') {
            ['Top', 'Right', 'Bottom', 'Left'].forEach((side) => {
                const key = 'padding' + side;
                rows.push(h(LabeledInput, { key, label: 'Padding ' + side, value: value(key, '0px'), onChange: (v) => props.patchStyle(key, v) }));
            });
        }

        if (node.type === 'heading' || node.type === 'text') {
            rows.push(h(LabeledInput, { key: 'fontsize', label: 'Font Size', value: value('fontSize', '16px'), onChange: (v) => props.patchStyle('fontSize', v) }));
            rows.push(h(LabeledSelect, { key: 'weight', label: 'Font Weight', value: value('fontWeight', '400'), options: ['300', '400', '500', '600', '700', '800', '900'], onChange: (v) => props.patchStyle('fontWeight', v) }));
            rows.push(h(LabeledSelect, { key: 'aligntext', label: 'Text Align', value: value('textAlign', 'left'), options: ['left', 'center', 'right', 'justify'], onChange: (v) => props.patchStyle('textAlign', v) }));
        }

        if (node.type === 'button') {
            rows.push(h(LabeledInput, { key: 'fontsize', label: 'Font Size', value: value('fontSize', '16px'), onChange: (v) => props.patchStyle('fontSize', v) }));
            rows.push(h(LabeledSelect, { key: 'weight', label: 'Font Weight', value: value('fontWeight', '600'), options: ['300', '400', '500', '600', '700', '800', '900'], onChange: (v) => props.patchStyle('fontWeight', v) }));
        }

        if (node.type !== 'image') {
            rows.push(h(ColorField, { key: 'color', label: 'Text Color', value: value('color', '#111111'), onChange: (v) => props.patchStyle('color', v) }));
        }
        if (CONTAINER_TYPES.includes(node.type) || node.type === 'button') {
            rows.push(h(ColorField, { key: 'bg', label: 'Background', value: value('backgroundColor', '#ffffff'), onChange: (v) => props.patchStyle('backgroundColor', v) }));
        }

        if (node.type === 'image' || node.type === 'button' || CONTAINER_TYPES.includes(node.type)) {
            rows.push(h(LabeledInput, { key: 'radius', label: 'Border Radius', value: value('borderRadius', '0px'), onChange: (v) => props.patchStyle('borderRadius', v) }));
            rows.push(h(LabeledInput, { key: 'borderwidth', label: 'Border Width', value: value('borderWidth', '0px'), onChange: (v) => props.patchStyle('borderWidth', v) }));
            rows.push(h(ColorField, { key: 'bordercolor', label: 'Border Color', value: value('borderColor', '#dddddd'), onChange: (v) => props.patchStyle('borderColor', v) }));
        }

        return h(Fragment, null, rows);
    }

    function ColorField(props) {
        const safe = /^#[0-9a-fA-F]{6}$/.test(props.value || '') ? props.value : '#000000';
        return h('label', { className: 'scfvb-field scfvb-color-field' },
            h('span', null, props.label),
            h('div', null,
                h('input', { type: 'color', value: safe, onChange: (e) => props.onChange(e.target.value) }),
                h('input', { type: 'text', value: props.value || '', onChange: (e) => props.onChange(e.target.value) })
            )
        );
    }

    const root = document.getElementById('scfvb-editor-root');
    if (root) {
        if (wp.element.createRoot) {
            wp.element.createRoot(root).render(h(App));
        } else {
            wp.element.render(h(App), root);
        }
    }
}());
