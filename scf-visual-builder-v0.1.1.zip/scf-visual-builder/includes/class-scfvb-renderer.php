<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_Renderer {
    private const STYLE_MAP = array(
        'display' => 'display', 'width' => 'width', 'maxWidth' => 'max-width', 'height' => 'height', 'minHeight' => 'min-height',
        'paddingTop' => 'padding-top', 'paddingRight' => 'padding-right', 'paddingBottom' => 'padding-bottom', 'paddingLeft' => 'padding-left',
        'marginTop' => 'margin-top', 'marginRight' => 'margin-right', 'marginBottom' => 'margin-bottom', 'marginLeft' => 'margin-left',
        'flexDirection' => 'flex-direction', 'justifyContent' => 'justify-content', 'alignItems' => 'align-items', 'gap' => 'gap',
        'backgroundColor' => 'background-color', 'color' => 'color', 'fontSize' => 'font-size', 'fontWeight' => 'font-weight',
        'borderWidth' => 'border-width', 'borderColor' => 'border-color', 'borderRadius' => 'border-radius', 'textAlign' => 'text-align',
    );

    public function hooks(): void {
        add_filter( 'the_content', array( $this, 'filter_content' ), 20 );
    }

    public function filter_content( string $content ): string {
        if ( is_admin() || ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        $post_id = get_the_ID();
        if ( ! $post_id || ! get_post_meta( $post_id, '_scfvb_enabled', true ) ) {
            return $content;
        }

        $layout = $this->load_layout( $post_id );
        if ( empty( $layout['nodes'] ) ) {
            return $content;
        }

        $html = '';
        foreach ( $layout['nodes'] as $node ) {
            $html .= $this->render_node( $node, $post_id );
        }

        $css = $this->render_css( $layout );
        return '<div class="scfvb-page alignfull">' . $html . '</div>' . ( $css ? '<style id="scfvb-page-styles">' . $css . '</style>' : '' );
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, '_scfvb_layout', true );
        $decoded = is_string( $raw ) ? json_decode( $raw, true ) : null;
        return is_array( $decoded ) ? $decoded : array( 'version' => 1, 'nodes' => array() );
    }

    private function node_class( array $node ): string {
        return 'scfvb-node-' . sanitize_html_class( preg_replace( '/^node_/', '', $node['id'] ?? '' ) );
    }

    private function render_node( array $node, int $post_id ): string {
        $class = 'scfvb-node ' . $this->node_class( $node );
        $type = $node['type'] ?? '';

        if ( 'section' === $type || 'container' === $type ) {
            $tag = 'section' === $type ? 'section' : 'div';
            $children = '';
            foreach ( $node['children'] ?? array() as $child ) {
                $children .= $this->render_node( $child, $post_id );
            }
            return '<' . $tag . ' class="' . esc_attr( $class ) . '">' . $children . '</' . $tag . '>';
        }

        if ( 'heading' === $type ) {
            $tag = $node['settings']['tag'] ?? 'h2';
            if ( ! in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
                $tag = 'h2';
            }
            $value = $this->resolve_value( $node, 'text', $post_id, $node['content']['text'] ?? '' );
            return '<' . $tag . ' class="' . esc_attr( $class ) . '">' . esc_html( (string) $value ) . '</' . $tag . '>';
        }

        if ( 'text' === $type ) {
            $value = $this->resolve_value( $node, 'text', $post_id, $node['content']['text'] ?? '' );
            return '<div class="' . esc_attr( $class ) . '">' . wpautop( esc_html( (string) $value ) ) . '</div>';
        }

        if ( 'image' === $type ) {
            $fallback_image = $node['content']['imageId'] ?? ( $node['content']['imageUrl'] ?? '' );
            $value = $this->resolve_value( $node, 'image', $post_id, $fallback_image );
            $src = '';
            $alt = '';
            if ( is_array( $value ) ) {
                $src = $value['url'] ?? '';
                $alt = $value['alt'] ?? '';
            } elseif ( is_numeric( $value ) ) {
                $src = wp_get_attachment_image_url( (int) $value, 'full' ) ?: '';
                $alt = get_post_meta( (int) $value, '_wp_attachment_image_alt', true );
            } elseif ( is_string( $value ) ) {
                $src = $value;
            }
            if ( ! $src ) {
                return '';
            }
            return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '">';
        }

        if ( 'button' === $type ) {
            $label = $this->resolve_value( $node, 'label', $post_id, $node['content']['label'] ?? 'Button' );
            $url = $this->resolve_value( $node, 'url', $post_id, $node['content']['url'] ?? '#' );
            return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( (string) $url ) . '">' . esc_html( (string) $label ) . '</a>';
        }

        return '';
    }

    private function resolve_value( array $node, string $key, int $post_id, $fallback ) {
        $binding = $node['bindings'][ $key ] ?? array( 'source' => 'static' );
        if ( 'scf' !== ( $binding['source'] ?? 'static' ) || ! function_exists( 'get_field' ) ) {
            return $fallback;
        }

        $selector = $binding['fieldKey'] ?? $binding['fieldName'] ?? '';
        if ( ! $selector ) {
            return $fallback;
        }

        $value = get_field( $selector, $post_id );
        return ( null === $value || false === $value || '' === $value ) ? $fallback : $value;
    }

    private function render_css( array $layout ): string {
        $base = '';
        $tablet = '';
        $mobile = '';

        $walk = function ( array $nodes ) use ( &$walk, &$base, &$tablet, &$mobile ): void {
            foreach ( $nodes as $node ) {
                $selector = '.' . $this->node_class( $node );
                $styles = $node['styles'] ?? array();
                $base_rules = $this->style_declarations( $styles['desktop'] ?? array() );
                $tablet_rules = $this->style_declarations( $styles['tablet'] ?? array() );
                $mobile_rules = $this->style_declarations( $styles['mobile'] ?? array() );

                if ( $base_rules ) {
                    $base .= $selector . '{' . $base_rules . '}';
                }
                if ( $tablet_rules ) {
                    $tablet .= $selector . '{' . $tablet_rules . '}';
                }
                if ( $mobile_rules ) {
                    $mobile .= $selector . '{' . $mobile_rules . '}';
                }

                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };

        $walk( $layout['nodes'] ?? array() );
        $css = '.scfvb-page{width:auto;max-width:none!important}.scfvb-page,.scfvb-page *{box-sizing:border-box}.scfvb-page img{max-width:100%;height:auto}.scfvb-page a.scfvb-node{display:inline-block;text-decoration:none}';
        $css .= $base;
        if ( $tablet ) {
            $css .= '@media(max-width:1024px){' . $tablet . '}';
        }
        if ( $mobile ) {
            $css .= '@media(max-width:767px){' . $mobile . '}';
        }
        return $css;
    }

    private function style_declarations( array $styles ): string {
        $out = '';
        foreach ( self::STYLE_MAP as $key => $property ) {
            if ( ! isset( $styles[ $key ] ) || '' === $styles[ $key ] ) {
                continue;
            }
            $value = $this->sanitize_css_value( $key, (string) $styles[ $key ] );
            if ( null !== $value ) {
                $out .= $property . ':' . $value . ';';
                if ( 'borderWidth' === $key && '0' !== $value && '0px' !== $value ) {
                    $out .= 'border-style:solid;';
                }
            }
        }
        return $out;
    }

    private function sanitize_css_value( string $key, string $value ): ?string {
        $value = trim( $value );

        $dimension_keys = array( 'width', 'maxWidth', 'height', 'minHeight', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'gap', 'fontSize', 'borderWidth', 'borderRadius' );
        if ( in_array( $key, $dimension_keys, true ) ) {
            if ( in_array( $value, array( 'auto', '0' ), true ) || preg_match( '/^-?\d+(?:\.\d+)?(?:px|%|rem|em|vw)?$/', $value ) ) {
                return $value;
            }
            return null;
        }

        if ( in_array( $key, array( 'backgroundColor', 'color', 'borderColor' ), true ) ) {
            return preg_match( '/^#[0-9a-fA-F]{3,8}$/', $value ) || 'transparent' === $value ? $value : null;
        }

        $enums = array(
            'display'        => array( 'block', 'flex', 'inline-block', 'none' ),
            'flexDirection'  => array( 'row', 'column', 'row-reverse', 'column-reverse' ),
            'justifyContent' => array( 'flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly' ),
            'alignItems'     => array( 'stretch', 'flex-start', 'center', 'flex-end', 'baseline' ),
            'textAlign'      => array( 'left', 'center', 'right', 'justify' ),
        );
        if ( isset( $enums[ $key ] ) ) {
            return in_array( $value, $enums[ $key ], true ) ? $value : null;
        }

        if ( 'fontWeight' === $key ) {
            return preg_match( '/^[1-9]00$/', $value ) || in_array( $value, array( 'normal', 'bold' ), true ) ? $value : null;
        }

        return null;
    }
}
