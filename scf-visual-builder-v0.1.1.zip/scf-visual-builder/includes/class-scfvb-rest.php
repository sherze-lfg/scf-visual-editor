<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_REST {
    private const META_ENABLED = '_scfvb_enabled';
    private const META_LAYOUT  = '_scfvb_layout';
    private const META_VERSION = '_scfvb_layout_version';

    private const ALLOWED_TYPES = array( 'section', 'container', 'heading', 'text', 'image', 'button' );
    private const ALLOWED_BINDING_KEYS = array( 'text', 'image', 'label', 'url' );
    private const ALLOWED_FIELD_TYPES = array( 'text', 'textarea', 'image', 'url' );
    private const ALLOWED_STYLE_KEYS = array(
        'display', 'width', 'maxWidth', 'height', 'minHeight',
        'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
        'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
        'flexDirection', 'justifyContent', 'alignItems', 'gap',
        'backgroundColor', 'color', 'fontSize', 'fontWeight',
        'borderWidth', 'borderColor', 'borderRadius', 'textAlign',
    );

    public function hooks(): void {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route(
            'scfvb/v1',
            '/pages/(?P<id>\d+)/layout',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_layout' ),
                    'permission_callback' => array( $this, 'can_edit' ),
                ),
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'save_layout' ),
                    'permission_callback' => array( $this, 'can_edit' ),
                ),
            )
        );
    }

    public function can_edit( WP_REST_Request $request ): bool {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );
        return (bool) ( $post && 'page' === $post->post_type && current_user_can( 'edit_post', $post_id ) );
    }

    public function get_layout( WP_REST_Request $request ): WP_REST_Response {
        $post_id = absint( $request['id'] );
        return rest_ensure_response(
            array(
                'enabled' => (bool) get_post_meta( $post_id, self::META_ENABLED, true ),
                'layout'  => $this->load_layout( $post_id ),
            )
        );
    }

    public function save_layout( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $params = $request->get_json_params();

        if ( ! isset( $params['layout'] ) || ! is_array( $params['layout'] ) ) {
            return new WP_Error( 'scfvb_invalid_layout', 'A layout object is required.', array( 'status' => 400 ) );
        }

        $sanitized = $this->sanitize_layout( $params['layout'] );
        if ( is_wp_error( $sanitized ) ) {
            return $sanitized;
        }

        $duplicate = $this->find_duplicate_field_name( $sanitized );
        if ( $duplicate ) {
            return new WP_Error(
                'scfvb_duplicate_field_name',
                sprintf( 'SCF field name "%s" is used more than once. Field names must be unique on a page.', $duplicate ),
                array( 'status' => 400 )
            );
        }

        $old_layout = $this->load_layout( $post_id );
        $migration = $this->migrate_renamed_fields( $post_id, $old_layout, $sanitized );
        if ( is_wp_error( $migration ) ) {
            return $migration;
        }

        update_post_meta( $post_id, self::META_ENABLED, 1 );
        update_post_meta( $post_id, self::META_VERSION, 1 );
        update_post_meta( $post_id, self::META_LAYOUT, wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES ) );

        return rest_ensure_response(
            array(
                'saved'  => true,
                'layout' => $sanitized,
            )
        );
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, self::META_LAYOUT, true );
        if ( is_string( $raw ) && '' !== $raw ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                return $decoded;
            }
        }

        return array( 'version' => 1, 'nodes' => array() );
    }

    private function sanitize_layout( array $layout ) {
        $nodes = isset( $layout['nodes'] ) && is_array( $layout['nodes'] ) ? $layout['nodes'] : array();
        if ( count( $nodes ) > 200 ) {
            return new WP_Error( 'scfvb_too_many_nodes', 'The layout contains too many root nodes.', array( 'status' => 400 ) );
        }

        $count = 0;
        $sanitized_nodes = array();
        foreach ( $nodes as $node ) {
            $clean = $this->sanitize_node( $node, 0, $count );
            if ( is_wp_error( $clean ) ) {
                return $clean;
            }
            $sanitized_nodes[] = $clean;
        }

        return array(
            'version' => 1,
            'nodes'   => $sanitized_nodes,
        );
    }

    private function sanitize_node( $node, int $depth, int &$count ) {
        if ( ! is_array( $node ) || $depth > 20 || ++$count > 500 ) {
            return new WP_Error( 'scfvb_invalid_tree', 'The layout tree is invalid or too deeply nested.', array( 'status' => 400 ) );
        }

        $type = isset( $node['type'] ) ? sanitize_key( $node['type'] ) : '';
        if ( ! in_array( $type, self::ALLOWED_TYPES, true ) ) {
            return new WP_Error( 'scfvb_invalid_node_type', 'Unsupported node type.', array( 'status' => 400 ) );
        }

        $id = isset( $node['id'] ) ? sanitize_key( $node['id'] ) : '';
        if ( ! preg_match( '/^node_[a-z0-9_-]{4,64}$/', $id ) ) {
            return new WP_Error( 'scfvb_invalid_node_id', 'Every node must have a stable node_* ID.', array( 'status' => 400 ) );
        }

        $clean = array(
            'id'       => $id,
            'type'     => $type,
            'name'     => isset( $node['name'] ) ? sanitize_text_field( $node['name'] ) : ucfirst( $type ),
            'settings' => $this->sanitize_settings( isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : array() ),
            'content'  => $this->sanitize_content( isset( $node['content'] ) && is_array( $node['content'] ) ? $node['content'] : array() ),
            'bindings' => $this->sanitize_bindings( isset( $node['bindings'] ) && is_array( $node['bindings'] ) ? $node['bindings'] : array() ),
            'styles'   => $this->sanitize_styles( isset( $node['styles'] ) && is_array( $node['styles'] ) ? $node['styles'] : array() ),
            'children' => array(),
        );

        if ( isset( $node['children'] ) && is_array( $node['children'] ) ) {
            foreach ( $node['children'] as $child ) {
                $clean_child = $this->sanitize_node( $child, $depth + 1, $count );
                if ( is_wp_error( $clean_child ) ) {
                    return $clean_child;
                }
                $clean['children'][] = $clean_child;
            }
        }

        if ( in_array( $type, array( 'heading', 'text', 'image', 'button' ), true ) ) {
            $clean['children'] = array();
        }

        return $clean;
    }

    private function sanitize_settings( array $settings ): array {
        $clean = array();
        if ( isset( $settings['tag'] ) ) {
            $tag = strtolower( sanitize_key( $settings['tag'] ) );
            if ( in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div' ), true ) ) {
                $clean['tag'] = $tag;
            }
        }
        return $clean;
    }

    private function sanitize_content( array $content ): array {
        $clean = array();
        if ( isset( $content['text'] ) ) {
            $clean['text'] = sanitize_textarea_field( $content['text'] );
        }
        if ( isset( $content['label'] ) ) {
            $clean['label'] = sanitize_text_field( $content['label'] );
        }
        if ( isset( $content['url'] ) ) {
            $clean['url'] = esc_url_raw( $content['url'] );
        }
        if ( isset( $content['imageId'] ) ) {
            $clean['imageId'] = absint( $content['imageId'] );
        }
        if ( isset( $content['imageUrl'] ) ) {
            $clean['imageUrl'] = esc_url_raw( $content['imageUrl'] );
        }
        return $clean;
    }

    private function sanitize_bindings( array $bindings ): array {
        $clean = array();
        foreach ( self::ALLOWED_BINDING_KEYS as $key ) {
            if ( empty( $bindings[ $key ] ) || ! is_array( $bindings[ $key ] ) ) {
                continue;
            }
            $binding = $bindings[ $key ];
            $source = isset( $binding['source'] ) && 'scf' === $binding['source'] ? 'scf' : 'static';
            $item = array( 'source' => $source );
            $field_key = isset( $binding['fieldKey'] ) ? sanitize_key( $binding['fieldKey'] ) : '';
            $field_name = isset( $binding['fieldName'] ) ? sanitize_key( $binding['fieldName'] ) : '';
            $field_type = isset( $binding['fieldType'] ) ? sanitize_key( $binding['fieldType'] ) : 'text';
            $label = isset( $binding['label'] ) ? sanitize_text_field( $binding['label'] ) : ucwords( str_replace( '_', ' ', $field_name ) );

            if ( ! in_array( $field_type, self::ALLOWED_FIELD_TYPES, true ) ) {
                $field_type = 'text';
            }

            if ( $field_key && preg_match( '/^field_scfvb_[a-z0-9_-]{4,64}$/', $field_key ) ) {
                $item['fieldKey'] = $field_key;
            }
            if ( $field_name ) {
                $item['fieldName'] = $field_name;
            }
            $item['fieldType'] = $field_type;
            if ( $label ) {
                $item['label'] = $label;
            }

            if ( 'scf' === $source && ( empty( $item['fieldKey'] ) || empty( $item['fieldName'] ) ) ) {
                continue;
            }

            $clean[ $key ] = $item;
        }
        return $clean;
    }

    private function sanitize_styles( array $styles ): array {
        $clean = array( 'desktop' => array(), 'tablet' => array(), 'mobile' => array() );
        foreach ( $clean as $breakpoint => $_ ) {
            if ( empty( $styles[ $breakpoint ] ) || ! is_array( $styles[ $breakpoint ] ) ) {
                continue;
            }
            foreach ( self::ALLOWED_STYLE_KEYS as $key ) {
                if ( ! array_key_exists( $key, $styles[ $breakpoint ] ) ) {
                    continue;
                }
                $value = sanitize_text_field( (string) $styles[ $breakpoint ][ $key ] );
                if ( strlen( $value ) <= 60 ) {
                    $clean[ $breakpoint ][ $key ] = $value;
                }
            }
        }
        return $clean;
    }

    private function collect_field_bindings( array $layout, bool $only_scf = true ): array {
        $fields = array();
        $walk = function ( array $nodes ) use ( &$walk, &$fields, $only_scf ): void {
            foreach ( $nodes as $node ) {
                foreach ( $node['bindings'] ?? array() as $binding ) {
                    $has_identity = ! empty( $binding['fieldKey'] ) && ! empty( $binding['fieldName'] );
                    $active = 'scf' === ( $binding['source'] ?? 'static' );
                    if ( $has_identity && ( ! $only_scf || $active ) ) {
                        $fields[ $binding['fieldKey'] ] = $binding;
                    }
                }
                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };
        $walk( $layout['nodes'] ?? array() );
        return $fields;
    }

    private function find_duplicate_field_name( array $layout ): string {
        $seen = array();
        foreach ( $this->collect_field_bindings( $layout ) as $field ) {
            $name = $field['fieldName'];
            if ( isset( $seen[ $name ] ) ) {
                return $name;
            }
            $seen[ $name ] = true;
        }
        return '';
    }

    private function migrate_renamed_fields( int $post_id, array $old_layout, array $new_layout ) {
        $old_fields = $this->collect_field_bindings( $old_layout, false );
        $new_fields = $this->collect_field_bindings( $new_layout, false );

        foreach ( $new_fields as $field_key => $new_field ) {
            if ( empty( $old_fields[ $field_key ] ) ) {
                continue;
            }
            $old_name = $old_fields[ $field_key ]['fieldName'];
            $new_name = $new_field['fieldName'];
            if ( $old_name === $new_name ) {
                continue;
            }

            $has_old = metadata_exists( 'post', $post_id, $old_name );
            $has_new = metadata_exists( 'post', $post_id, $new_name );
            if ( $has_old && $has_new ) {
                return new WP_Error(
                    'scfvb_field_rename_conflict',
                    sprintf( 'Cannot rename "%s" to "%s" because the destination meta key already contains data.', $old_name, $new_name ),
                    array( 'status' => 409 )
                );
            }

            if ( $has_old ) {
                update_post_meta( $post_id, $new_name, get_post_meta( $post_id, $old_name, true ) );
                delete_post_meta( $post_id, $old_name );
            }

            update_post_meta( $post_id, '_' . $new_name, $field_key );
            delete_post_meta( $post_id, '_' . $old_name );
        }

        return true;
    }
}
