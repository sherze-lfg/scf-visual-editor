<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class SCFVB_Plugin {
    private static ?SCFVB_Plugin $instance = null;

    public static function instance(): SCFVB_Plugin {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function boot(): void {
        ( new SCFVB_Editor() )->hooks();
        ( new SCFVB_REST() )->hooks();
        ( new SCFVB_SCF() )->hooks();
        ( new SCFVB_Renderer() )->hooks();

        add_action( 'admin_notices', array( $this, 'dependency_notice' ) );
    }

    public function dependency_notice(): void {
        if ( function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }

        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>SCF Visual Builder:</strong> Secure Custom Fields is required for editable field bindings. Static layouts and content can still be designed, but SCF-bound fields will not be registered until SCF is active.</p></div>';
    }
}
