<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_SCF {
    public function hooks(): void {
        add_action( 'acf/init', array( $this, 'register_fields' ) );
    }

    public function register_fields(): void {
        if ( ! function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }

        $pages = get_posts(
            array(
                'post_type'      => 'page',
                'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_key'       => '_scfvb_enabled',
                'meta_value'     => '1',
                'no_found_rows'  => true,
            )
        );

        foreach ( $pages as $post_id ) {
            $layout = $this->load_layout( (int) $post_id );
            $fields = $this->collect_fields( $layout );
            if ( empty( $fields ) ) {
                continue;
            }

            acf_add_local_field_group(
                array(
                    'key'          => 'group_scfvb_page_' . $post_id,
                    'title'        => 'Visual Builder Content — ' . get_the_title( $post_id ),
                    'fields'       => array_values( $fields ),
                    'location'     => array(
                        array(
                            array(
                                'param'    => 'page',
                                'operator' => '==',
                                'value'    => (string) $post_id,
                            ),
                        ),
                    ),
                    'position'     => 'normal',
                    'style'        => 'default',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'active'       => true,
                    'show_in_rest' => 1,
                )
            );
        }
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, '_scfvb_layout', true );
        if ( is_string( $raw ) ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                return SCFVB_Layout::normalize( $decoded );
            }
        }
        return SCFVB_Layout::default_layout();
    }

    private function collect_fields( array $layout ): array {
        $fields = array();
        $walk = function ( array $nodes ) use ( &$walk, &$fields ): void {
            foreach ( $nodes as $node ) {
                foreach ( $node['bindings'] ?? array() as $binding ) {
                    if ( 'scf' !== ( $binding['source'] ?? 'static' ) || empty( $binding['fieldKey'] ) || empty( $binding['fieldName'] ) ) {
                        continue;
                    }

                    $field = array(
                        'key'          => $binding['fieldKey'],
                        'label'        => $binding['label'] ?? ucwords( str_replace( '_', ' ', $binding['fieldName'] ) ),
                        'name'         => $binding['fieldName'],
                        'type'         => $binding['fieldType'] ?? 'text',
                        'required'     => 0,
                        'wrapper'      => array( 'width' => '', 'class' => '', 'id' => '' ),
                    );

                    if ( 'image' === $field['type'] ) {
                        $field['return_format'] = 'array';
                        $field['preview_size']  = 'medium';
                        $field['library']       = 'all';
                    } elseif ( 'textarea' === $field['type'] ) {
                        $field['rows'] = 5;
                        $field['new_lines'] = ''; // Renderer owns paragraph formatting to avoid double-escaped <p> markup.
                    }

                    $fields[ $field['key'] ] = $field;
                }

                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };

        $walk( $layout['nodes'] ?? array() );
        return $fields;
    }
}
