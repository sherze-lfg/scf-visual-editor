<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$post_id = get_queried_object_id();
$renderer = new SCFVB_Renderer();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class( 'scfvb-builder-canvas' ); ?>>
<?php wp_body_open(); ?>
<main id="scfvb-builder-canvas" role="main">
    <?php echo $renderer->render_page_markup( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes by context. ?>
</main>
<?php wp_footer(); ?>
</body>
</html>
