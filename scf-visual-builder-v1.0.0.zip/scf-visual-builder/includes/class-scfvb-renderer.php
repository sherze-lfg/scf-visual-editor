<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_Renderer {
    private array $structured_value_cache = array();
    private array $design_tokens = array();
    private array $layout_cache = array();

    private const STYLE_MAP = array(
        'display' => 'display',
        'width' => 'width', 'minWidth' => 'min-width', 'maxWidth' => 'max-width',
        'height' => 'height', 'minHeight' => 'min-height', 'maxHeight' => 'max-height',
        'paddingTop' => 'padding-top', 'paddingRight' => 'padding-right', 'paddingBottom' => 'padding-bottom', 'paddingLeft' => 'padding-left',
        'marginTop' => 'margin-top', 'marginRight' => 'margin-right', 'marginBottom' => 'margin-bottom', 'marginLeft' => 'margin-left',
        'flexDirection' => 'flex-direction', 'justifyContent' => 'justify-content', 'alignItems' => 'align-items', 'gap' => 'gap',
        'gridTemplateColumns' => 'grid-template-columns', 'gridTemplateRows' => 'grid-template-rows',
        'columnGap' => 'column-gap', 'rowGap' => 'row-gap', 'gridAutoFlow' => 'grid-auto-flow',
        'position' => 'position', 'top' => 'top', 'right' => 'right', 'bottom' => 'bottom', 'left' => 'left', 'zIndex' => 'z-index',
        'overflow' => 'overflow',
        'backgroundColor' => 'background-color', 'backgroundSize' => 'background-size', 'backgroundPosition' => 'background-position',
        'backgroundRepeat' => 'background-repeat', 'backgroundAttachment' => 'background-attachment',
        'color' => 'color', 'fontFamily' => 'font-family', 'fontSize' => 'font-size', 'fontWeight' => 'font-weight', 'lineHeight' => 'line-height', 'letterSpacing' => 'letter-spacing',
        'borderWidth' => 'border-width', 'borderColor' => 'border-color', 'borderRadius' => 'border-radius', 'boxShadow' => 'box-shadow', 'textAlign' => 'text-align',
        'objectFit' => 'object-fit', 'objectPosition' => 'object-position', 'aspectRatio' => 'aspect-ratio',
    );

    public function hooks(): void {
        add_filter( 'the_content', array( $this, 'filter_content' ), 20 );
        add_filter( 'template_include', array( $this, 'template_include' ), 99 );
        add_filter( 'body_class', array( $this, 'body_classes' ) );
    }

    public function template_include( string $template ): string {
        if ( is_admin() || ! is_singular( 'page' ) ) {
            return $template;
        }
        $post_id = get_queried_object_id();
        if ( ! $this->is_builder_page( $post_id ) ) {
            return $template;
        }
        $layout = $this->load_layout( $post_id );
        if ( 'canvas' !== SCFVB_Layout::page_layout( $layout ) ) {
            return $template;
        }
        $canvas_template = SCFVB_DIR . 'templates/builder-canvas.php';
        return file_exists( $canvas_template ) ? $canvas_template : $template;
    }

    public function body_classes( array $classes ): array {
        if ( ! is_singular( 'page' ) ) {
            return $classes;
        }
        $post_id = get_queried_object_id();
        if ( ! $this->is_builder_page( $post_id ) ) {
            return $classes;
        }
        $mode = SCFVB_Layout::page_layout( $this->load_layout( $post_id ) );
        $classes[] = 'scfvb-enabled-page';
        $classes[] = 'scfvb-page-layout-' . sanitize_html_class( $mode );
        return $classes;
    }

    public function filter_content( string $content ): string {
        if ( is_admin() || ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }
        $post_id = get_the_ID();
        if ( ! $this->is_builder_page( $post_id ) ) {
            return $content;
        }
        $layout = $this->load_layout( $post_id );
        if ( 'canvas' === SCFVB_Layout::page_layout( $layout ) || empty( $layout['nodes'] ) ) {
            return $content;
        }
        return $this->render_page_markup( $post_id, $layout );
    }

    public function render_page_markup( int $post_id, ?array $layout = null ): string {
        $layout = $layout ?: $this->load_layout( $post_id );
        if ( empty( $layout['nodes'] ) ) {
            return '';
        }

        $this->structured_value_cache = array();
        $this->design_tokens = SCFVB_Design_System::token_map();
        $mode = SCFVB_Layout::page_layout( $layout );
        $html = '';
        foreach ( $layout['nodes'] as $node ) {
            $html .= $this->render_node( $node, $post_id, null, array() );
        }

        $classes = array( 'scfvb-page', 'scfvb-layout-' . $mode );
        if ( 'fullwidth' === $mode ) {
            $classes[] = 'alignfull';
        }
        $css = $this->render_css( $layout );
        return '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">' . $html . '</div>' . ( $css ? '<style id="scfvb-page-styles">' . $css . '</style>' : '' );
    }

    private function is_builder_page( int $post_id ): bool {
        return $post_id > 0 && (bool) get_post_meta( $post_id, '_scfvb_enabled', true );
    }

    private function load_layout( int $post_id ): array {
        if ( isset( $this->layout_cache[ $post_id ] ) ) {
            return $this->layout_cache[ $post_id ];
        }
        $raw = get_post_meta( $post_id, '_scfvb_layout', true );
        $decoded = is_string( $raw ) ? json_decode( $raw, true ) : null;
        $layout = is_array( $decoded ) ? SCFVB_Components::instance()->resolve_layout( SCFVB_Layout::normalize( $decoded ) ) : SCFVB_Layout::default_layout();
        $this->layout_cache[ $post_id ] = $layout;
        return $layout;
    }

    private function node_class( array $node ): string {
        return 'scfvb-node-' . sanitize_html_class( preg_replace( '/^node_/', '', $node['id'] ?? '' ) );
    }

    /**
     * Render a visual node. $data_context is the currently-resolved SCF Group or
     * Repeater row when SCF is active. $storage_prefix is used for raw post-meta
     * fallback and also makes nested Repeaters degrade safely if SCF is disabled.
     */
    private function render_node( array $node, int $post_id, ?array $data_context = null, array $storage_prefix = array() ): string {
        $class = 'scfvb-node ' . $this->node_class( $node );
        $type = $node['type'] ?? '';

        if ( 'section' === $type ) {
            if ( ! empty( $node['flexible']['enabled'] ) && ! empty( $node['flexible']['fieldName'] ) ) {
                return $this->render_flexible( $node, $post_id, $data_context, $storage_prefix, $class );
            }
            $children = $this->render_children( $node['children'] ?? array(), $post_id, $data_context, $storage_prefix );
            return '<section class="' . esc_attr( $class ) . '">' . $children . '</section>';
        }

        if ( 'container' === $type ) {
            if ( ! empty( $node['repeater']['enabled'] ) && ! empty( $node['repeater']['fieldName'] ) ) {
                return $this->render_repeater( $node, $post_id, $data_context, $storage_prefix, $class );
            }

            if ( ! empty( $node['group']['enabled'] ) && ! empty( $node['group']['fieldName'] ) ) {
                $group = $node['group'];
                $group_name = (string) $group['fieldName'];
                $group_prefix = array_merge( $storage_prefix, array( $group_name ) );
                $group_data = null;

                if ( function_exists( 'get_field' ) ) {
                    if ( null !== $data_context ) {
                        $candidate = $data_context[ $group_name ] ?? null;
                        $group_data = is_array( $candidate ) ? $candidate : array();
                    } else {
                        $candidate = $this->root_structured_value( $group, $post_id );
                        $group_data = is_array( $candidate ) ? $candidate : array();
                    }
                }

                $children = $this->render_children( $node['children'] ?? array(), $post_id, $group_data, $group_prefix );
                return '<div class="' . esc_attr( $class ) . '">' . $children . '</div>';
            }

            $children = $this->render_children( $node['children'] ?? array(), $post_id, $data_context, $storage_prefix );
            return '<div class="' . esc_attr( $class ) . '">' . $children . '</div>';
        }

        if ( 'heading' === $type ) {
            $tag = $node['settings']['tag'] ?? 'h2';
            if ( ! in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
                $tag = 'h2';
            }
            $value = $this->resolve_value( $node, 'text', $post_id, $node['content']['text'] ?? '', $data_context, $storage_prefix );
            $binding = $this->binding( $node, 'text' );
            return '<' . $tag . ' class="' . esc_attr( $class ) . '">' . esc_html( $this->plain_value( $value, $binding ) ) . '</' . $tag . '>';
        }

        if ( 'text' === $type ) {
            $value = $this->resolve_value( $node, 'text', $post_id, $node['content']['text'] ?? '', $data_context, $storage_prefix );
            $binding = $this->binding( $node, 'text' );
            return '<div class="' . esc_attr( $class ) . '">' . $this->text_value_html( $value, $binding ) . '</div>';
        }

        if ( 'image' === $type ) {
            $fallback_image = ! empty( $node['content']['imageId'] ) ? (int) $node['content']['imageId'] : ( $node['content']['imageUrl'] ?? '' );
            $value = $this->resolve_value( $node, 'image', $post_id, $fallback_image, $data_context, $storage_prefix );
            $binding = $this->binding( $node, 'image' );
            if ( 'gallery' === ( $binding['fieldType'] ?? '' ) ) {
                return $this->gallery_html( $value, $class );
            }
            return $this->single_image_html( $value, $class, (string) ( $node['content']['altText'] ?? '' ) );
        }

        if ( 'button' === $type ) {
            $label_value = $this->resolve_value( $node, 'label', $post_id, $node['content']['label'] ?? 'Button', $data_context, $storage_prefix );
            $url_value = $this->resolve_value( $node, 'url', $post_id, $node['content']['url'] ?? '#', $data_context, $storage_prefix );
            $label = $this->plain_value( $label_value, $this->binding( $node, 'label' ) );
            $link = $this->link_parts( $url_value );
            $url = $link['url'] ?: '#';
            $target = in_array( $link['target'], array( '_blank', '_self', '_parent', '_top' ), true ) ? $link['target'] : '';
            $target_attr = $target ? ' target="' . esc_attr( $target ) . '"' : '';
            $rel_attr = '_blank' === $target ? ' rel="noopener noreferrer"' : '';
            return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '"' . $target_attr . $rel_attr . '>' . esc_html( $label ) . '</a>';
        }

        return '';
    }

    private function binding( array $node, string $key ): array {
        $binding = isset( $node['bindings'][ $key ] ) && is_array( $node['bindings'][ $key ] )
            ? $node['bindings'][ $key ]
            : array( 'source' => 'static' );
        if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
            $type = (string) ( $node['type'] ?? '' );
            $defaults = array(
                'heading:text' => 'text',
                'text:text'    => 'textarea',
                'image:image'  => 'image',
                'button:label' => 'text',
                'button:url'   => 'url',
            );
            $binding['fieldType'] = $defaults[ $type . ':' . $key ] ?? 'text';
            $binding['options'] = array();
        }
        return $binding;
    }

    /** Convert supported SCF return formats to safe human-readable plain text. */
    private function plain_value( $value, array $binding = array() ): string {
        $type = (string) ( $binding['fieldType'] ?? 'text' );
        $options = isset( $binding['options'] ) && is_array( $binding['options'] ) ? $binding['options'] : array();

        if ( 'true_false' === $type ) {
            return $value ? (string) ( $options['trueLabel'] ?? 'Yes' ) : (string) ( $options['falseLabel'] ?? 'No' );
        }

        if ( in_array( $type, array( 'select', 'checkbox', 'radio' ), true ) ) {
            $choices = $this->binding_choices( (string) ( $options['choicesText'] ?? '' ) );
            if ( is_array( $value ) ) {
                $labels = array();
                foreach ( $value as $item ) {
                    $raw = is_scalar( $item ) ? (string) $item : $this->plain_value( $item, array( 'fieldType' => 'text' ) );
                    if ( '' !== $raw ) {
                        $labels[] = $choices[ $raw ] ?? $raw;
                    }
                }
                return implode( ', ', $labels );
            }
            if ( is_scalar( $value ) ) {
                $raw = (string) $value;
                return (string) ( $choices[ $raw ] ?? $raw );
            }
        }

        if ( 'post_object' === $type && is_numeric( $value ) && (int) $value > 0 ) {
            return get_the_title( (int) $value ) ?: (string) $value;
        }
        if ( 'taxonomy' === $type && is_numeric( $value ) && (int) $value > 0 ) {
            $term = get_term( (int) $value, (string) ( $options['taxonomy'] ?? 'category' ) );
            if ( $term instanceof WP_Term ) {
                return (string) $term->name;
            }
        }
        if ( 'date_picker' === $type && is_string( $value ) && preg_match( '/^\d{8}$/', $value ) ) {
            $date = DateTime::createFromFormat( '!Ymd', $value );
            if ( $date ) {
                return $date->format( (string) ( $options['displayFormat'] ?? 'F j, Y' ) );
            }
        }
        if ( 'date_time_picker' === $type && is_string( $value ) && preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value ) ) {
            $date = DateTime::createFromFormat( '!Y-m-d H:i:s', $value );
            if ( $date ) {
                return $date->format( (string) ( $options['displayFormat'] ?? 'F j, Y g:i a' ) );
            }
        }

        if ( $value instanceof WP_Post ) {
            return get_the_title( $value ) ?: (string) $value->post_name;
        }
        if ( $value instanceof WP_Term ) {
            return (string) $value->name;
        }
        if ( is_object( $value ) ) {
            if ( isset( $value->post_title ) ) {
                return (string) $value->post_title;
            }
            if ( isset( $value->name ) ) {
                return (string) $value->name;
            }
            return '';
        }

        if ( is_array( $value ) ) {
            // Link/File/Image arrays are associative return formats; list arrays
            // such as Checkbox/Relationship are flattened recursively.
            if ( isset( $value['title'] ) || isset( $value['url'] ) || isset( $value['filename'] ) ) {
                return (string) ( $value['title'] ?? $value['filename'] ?? $value['url'] ?? '' );
            }
            if ( isset( $value['label'] ) ) {
                return (string) $value['label'];
            }
            $parts = array();
            foreach ( $value as $item ) {
                $part = trim( $this->plain_value( $item, $binding ) );
                if ( '' !== $part ) {
                    $parts[] = $part;
                }
            }
            return implode( ', ', $parts );
        }

        return is_scalar( $value ) ? (string) $value : '';
    }

    private function binding_choices( string $text ): array {
        $choices = array();
        foreach ( preg_split( '/\r\n|\r|\n/', $text ) ?: array() as $line ) {
            $line = trim( wp_strip_all_tags( (string) $line ) );
            if ( '' === $line ) {
                continue;
            }
            $parts = preg_split( '/\s*(?::|\|)\s*/', $line, 2 );
            $value = trim( (string) ( $parts[0] ?? '' ) );
            $label = trim( (string) ( $parts[1] ?? $value ) );
            if ( '' !== $value ) {
                $choices[ $value ] = '' !== $label ? $label : $value;
            }
        }
        return $choices;
    }

    private function text_value_html( $value, array $binding ): string {
        $type = (string) ( $binding['fieldType'] ?? 'text' );
        $options = isset( $binding['options'] ) && is_array( $binding['options'] ) ? $binding['options'] : array();

        if ( 'wysiwyg' === $type ) {
            return wp_kses_post( (string) $value );
        }

        if ( 'email' === $type ) {
            $email = sanitize_email( (string) $value );
            return $email ? '<a href="' . esc_url( 'mailto:' . $email ) . '">' . esc_html( $email ) . '</a>' : '';
        }

        if ( in_array( $type, array( 'file', 'link', 'page_link', 'post_object' ), true ) ) {
            $link = $this->link_parts( $value );
            if ( $link['url'] ) {
                $target = in_array( $link['target'], array( '_blank', '_self', '_parent', '_top' ), true ) ? $link['target'] : '';
                $target_attr = $target ? ' target="' . esc_attr( $target ) . '"' : '';
                $rel_attr = '_blank' === $target ? ' rel="noopener noreferrer"' : '';
                $label = $link['title'] ?: $link['url'];
                return '<a href="' . esc_url( $link['url'] ) . '"' . $target_attr . $rel_attr . '>' . esc_html( $label ) . '</a>';
            }
        }

        if ( in_array( $type, array( 'post_object', 'relationship' ), true ) && is_array( $value ) ) {
            $items = array();
            foreach ( $value as $item ) {
                $link = $this->link_parts( $item );
                $label = $link['title'] ?: $this->plain_value( $item, $binding );
                if ( '' === $label ) {
                    continue;
                }
                $items[] = $link['url']
                    ? '<a href="' . esc_url( $link['url'] ) . '">' . esc_html( $label ) . '</a>'
                    : esc_html( $label );
            }
            return $items ? '<ul class="scfvb-dynamic-list"><li>' . implode( '</li><li>', $items ) . '</li></ul>' : '';
        }

        if ( 'taxonomy' === $type ) {
            $values = is_array( $value ) ? $value : array( $value );
            $items = array();
            $taxonomy = (string) ( $options['taxonomy'] ?? 'category' );
            foreach ( $values as $item ) {
                $term = null;
                if ( $item instanceof WP_Term ) {
                    $term = $item;
                } elseif ( is_numeric( $item ) && (int) $item > 0 ) {
                    $candidate = get_term( (int) $item, $taxonomy );
                    $term = is_wp_error( $candidate ) ? null : $candidate;
                }
                if ( $term instanceof WP_Term ) {
                    $url = get_term_link( $term );
                    $items[] = is_wp_error( $url )
                        ? esc_html( $term->name )
                        : '<a href="' . esc_url( $url ) . '">' . esc_html( $term->name ) . '</a>';
                } else {
                    $plain = $this->plain_value( $item, $binding );
                    if ( '' !== $plain ) {
                        $items[] = esc_html( $plain );
                    }
                }
            }
            return $items ? '<ul class="scfvb-dynamic-list"><li>' . implode( '</li><li>', $items ) . '</li></ul>' : '';
        }

        if ( 'color_picker' === $type ) {
            $color = trim( (string) $value );
            if ( preg_match( '/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $color ) ) {
                return '<span class="scfvb-color-value"><span class="scfvb-color-swatch" style="background-color:' . esc_attr( $color ) . '"></span>' . esc_html( $color ) . '</span>';
            }
        }

        // Date fields normally arrive already formatted by SCF. Raw-meta fallback
        // may expose the storage format, so normalize that case for graceful output.
        if ( 'date_picker' === $type && is_string( $value ) && preg_match( '/^\d{8}$/', $value ) ) {
            $date = DateTime::createFromFormat( '!Ymd', $value );
            if ( $date ) {
                return esc_html( $date->format( (string) ( $options['displayFormat'] ?? 'F j, Y' ) ) );
            }
        }
        if ( 'date_time_picker' === $type && is_string( $value ) && preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value ) ) {
            $date = DateTime::createFromFormat( '!Y-m-d H:i:s', $value );
            if ( $date ) {
                return esc_html( $date->format( (string) ( $options['displayFormat'] ?? 'F j, Y g:i a' ) ) );
            }
        }

        return wpautop( esc_html( $this->plain_value( $value, $binding ) ) );
    }

    /** Normalize Link/File/Page Link/Post Object/Term values into URL/title/target. */
    private function link_parts( $value ): array {
        $parts = array( 'url' => '', 'title' => '', 'target' => '' );
        if ( $value instanceof WP_Post ) {
            $parts['url'] = get_permalink( $value ) ?: '';
            $parts['title'] = get_the_title( $value ) ?: '';
            return $parts;
        }
        if ( $value instanceof WP_Term ) {
            $url = get_term_link( $value );
            $parts['url'] = is_wp_error( $url ) ? '' : (string) $url;
            $parts['title'] = (string) $value->name;
            return $parts;
        }
        if ( is_numeric( $value ) && (int) $value > 0 ) {
            $id = (int) $value;
            if ( 'attachment' === get_post_type( $id ) ) {
                $parts['url'] = wp_get_attachment_url( $id ) ?: '';
                $parts['title'] = get_the_title( $id ) ?: basename( (string) $parts['url'] );
            } else {
                $parts['url'] = get_permalink( $id ) ?: '';
                $parts['title'] = get_the_title( $id ) ?: '';
            }
            return $parts;
        }
        if ( is_array( $value ) ) {
            if ( isset( $value['url'] ) ) {
                $parts['url'] = (string) $value['url'];
                $parts['title'] = (string) ( $value['title'] ?? $value['filename'] ?? '' );
                $parts['target'] = (string) ( $value['target'] ?? '' );
                return $parts;
            }
            if ( isset( $value['ID'] ) || isset( $value['id'] ) ) {
                return $this->link_parts( (int) ( $value['ID'] ?? $value['id'] ) );
            }
        }
        if ( is_string( $value ) ) {
            $parts['url'] = $value;
            $post_id = url_to_postid( $value );
            $parts['title'] = $post_id ? ( get_the_title( $post_id ) ?: $value ) : $value;
        }
        return $parts;
    }

    private function single_image_html( $value, string $class, string $fallback_alt = '' ): string {
        $src = '';
        $alt = sanitize_text_field( $fallback_alt );
        $attachment_id = 0;
        if ( is_array( $value ) ) {
            $src = (string) ( $value['url'] ?? '' );
            $array_alt = (string) ( $value['alt'] ?? '' );
            if ( '' !== trim( $array_alt ) ) {
                $alt = $array_alt;
            }
            $attachment_id = absint( $value['ID'] ?? $value['id'] ?? 0 );
        } elseif ( is_numeric( $value ) && (int) $value > 0 ) {
            $attachment_id = (int) $value;
            $src = wp_get_attachment_image_url( $attachment_id, 'full' ) ?: '';
            $attachment_alt = (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
            if ( '' !== trim( $attachment_alt ) ) {
                $alt = $attachment_alt;
            }
        } elseif ( is_string( $value ) ) {
            $src = $value;
        }
        if ( ! $src ) {
            return '';
        }
        if ( $attachment_id ) {
            $image = wp_get_attachment_image( $attachment_id, 'full', false, array( 'class' => $class, 'alt' => $alt, 'loading' => 'lazy', 'decoding' => 'async' ) );
            if ( $image ) {
                return $image;
            }
        }
        return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">';
    }

    private function gallery_html( $value, string $class ): string {
        if ( ! is_array( $value ) || empty( $value ) ) {
            return '';
        }
        $items = '';
        foreach ( $value as $image ) {
            $image_html = $this->single_image_html( $image, 'scfvb-gallery-image' );
            if ( $image_html ) {
                $items .= '<div class="scfvb-gallery-item">' . $image_html . '</div>';
            }
        }
        return $items ? '<div class="' . esc_attr( $class . ' scfvb-gallery' ) . '"><div class="scfvb-gallery-items">' . $items . '</div></div>' : '';
    }

    private function render_children( array $children, int $post_id, ?array $data_context, array $storage_prefix ): string {
        $html = '';
        foreach ( $children as $child ) {
            if ( is_array( $child ) ) {
                $html .= $this->render_node( $child, $post_id, $data_context, $storage_prefix );
            }
        }
        return $html;
    }

    private function render_flexible( array $node, int $post_id, ?array $data_context, array $storage_prefix, string $class ): string {
        $flex = $node['flexible'];
        $name = (string) $flex['fieldName'];
        $prefix = array_merge( $storage_prefix, array( $name ) );
        $rows = array();

        if ( function_exists( 'get_field' ) ) {
            if ( null !== $data_context ) {
                $candidate = $data_context[ $name ] ?? array();
            } else {
                $candidate = $this->root_structured_value( $flex, $post_id );
            }
            if ( is_array( $candidate ) ) $rows = $candidate;
        } else {
            $count_key = implode( '_', $prefix );
            $count = max( 0, absint( get_post_meta( $post_id, $count_key, true ) ) );
            for ( $i = 0; $i < $count; $i++ ) {
                $layout_name = (string) get_post_meta( $post_id, $count_key . '_' . $i . '_acf_fc_layout', true );
                if ( '' !== $layout_name ) $rows[] = array( 'acf_fc_layout' => $layout_name, '__scfvb_row_index' => $i );
            }
        }

        $templates = array();
        foreach ( $node['children'] ?? array() as $template ) {
            if ( ! is_array( $template ) || empty( $template['flexLayout']['name'] ) ) continue;
            $templates[ (string) $template['flexLayout']['name'] ] = $template;
        }

        $html = '';
        foreach ( $rows as $index => $row ) {
            if ( ! is_array( $row ) ) continue;
            $layout_name = (string) ( $row['acf_fc_layout'] ?? '' );
            if ( '' === $layout_name || empty( $templates[ $layout_name ] ) ) continue;
            $template = $templates[ $layout_name ];
            $row_index = isset( $row['__scfvb_row_index'] ) ? absint( $row['__scfvb_row_index'] ) : $index;
            unset( $row['__scfvb_row_index'] );
            $row_prefix = array_merge( $prefix, array( (string) $row_index ) );
            $html .= $this->render_node( $template, $post_id, function_exists( 'get_field' ) ? $row : null, $row_prefix );
        }
        return '<section class="' . esc_attr( $class ) . '">' . $html . '</section>';
    }

    private function render_repeater( array $node, int $post_id, ?array $data_context, array $storage_prefix, string $class ): string {
        $repeater = $node['repeater'];
        $field_name = (string) $repeater['fieldName'];
        $base_prefix = array_merge( $storage_prefix, array( $field_name ) );
        $html = '';

        if ( function_exists( 'get_field' ) ) {
            if ( null !== $data_context ) {
                $rows = $data_context[ $field_name ] ?? array();
            } else {
                $rows = $this->root_structured_value( $repeater, $post_id );
            }
            if ( ! is_array( $rows ) ) {
                return '';
            }
            $index = 0;
            foreach ( $rows as $row ) {
                if ( ! is_array( $row ) ) {
                    $index++;
                    continue;
                }
                $children = $this->render_children( $node['children'] ?? array(), $post_id, $row, array_merge( $base_prefix, array( (string) $index ) ) );
                $html .= '<div class="' . esc_attr( $class . ' scfvb-repeater-item' ) . '" data-scfvb-row="' . esc_attr( (string) $index ) . '">' . $children . '</div>';
                $index++;
            }
            return $html;
        }

        // SCF unavailable: Repeater row count and descendants are stored as
        // repeater_0_child, repeater_1_child, etc. Reconstruct the visual rows
        // directly from post meta so published pages fail gracefully.
        $count_key = implode( '_', $base_prefix );
        $row_count = metadata_exists( 'post', $post_id, $count_key ) ? absint( get_post_meta( $post_id, $count_key, true ) ) : 0;
        for ( $index = 0; $index < $row_count; $index++ ) {
            $row_prefix = array_merge( $base_prefix, array( (string) $index ) );
            $children = $this->render_children( $node['children'] ?? array(), $post_id, null, $row_prefix );
            $html .= '<div class="' . esc_attr( $class . ' scfvb-repeater-item' ) . '" data-scfvb-row="' . esc_attr( (string) $index ) . '">' . $children . '</div>';
        }
        return $html;
    }

    private function root_structured_value( array $field, int $post_id ) {
        $selector = $field['fieldKey'] ?? $field['fieldName'] ?? '';
        if ( ! $selector || ! function_exists( 'get_field' ) ) {
            return null;
        }
        $cache_key = $post_id . ':' . $selector;
        if ( ! array_key_exists( $cache_key, $this->structured_value_cache ) ) {
            $this->structured_value_cache[ $cache_key ] = get_field( $selector, $post_id );
        }
        return $this->structured_value_cache[ $cache_key ];
    }

    /**
     * Once a binding is SCF-backed, SCF is the source of truth. Empty values stay
     * empty. Inside Groups/Repeaters, SCF returns an associative row/context array.
     */
    private function resolve_value( array $node, string $key, int $post_id, $fallback, ?array $data_context = null, array $storage_prefix = array() ) {
        $binding = $node['bindings'][ $key ] ?? array( 'source' => 'static' );
        if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
            return $fallback;
        }

        $field_name = $binding['fieldName'] ?? '';
        if ( null !== $data_context ) {
            return $field_name && array_key_exists( $field_name, $data_context ) ? $data_context[ $field_name ] : '';
        }

        $selector = $binding['fieldKey'] ?? $field_name;
        if ( function_exists( 'get_field' ) ) {
            return $selector ? get_field( $selector, $post_id ) : '';
        }

        if ( $field_name ) {
            $storage_name = implode( '_', array_merge( $storage_prefix, array( $field_name ) ) );
            if ( metadata_exists( 'post', $post_id, $storage_name ) ) {
                return get_post_meta( $post_id, $storage_name, true );
            }
        }
        return '';
    }

    private function render_css( array $layout ): string {
        $rules = array(
            'desktop' => '',
            'laptop'  => '',
            'tablet'  => '',
            'mobile'  => '',
        );

        $walk = function ( array $nodes ) use ( &$walk, &$rules ): void {
            foreach ( $nodes as $node ) {
                $selector = '.' . $this->node_class( $node );
                $styles = $node['styles'] ?? array();
                $style_tokens = $node['styleTokens'] ?? array();
                foreach ( array_keys( $rules ) as $breakpoint ) {
                    $declarations = $this->style_declarations( $styles[ $breakpoint ] ?? array(), $style_tokens[ $breakpoint ] ?? array() );
                    if ( $declarations ) {
                        $rules[ $breakpoint ] .= $selector . '{' . $declarations . '}';
                    }
                }

                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'] );
                }
            }
        };

        $walk( $layout['nodes'] ?? array() );

        $css = '.scfvb-page{box-sizing:border-box;width:100%;max-width:none}.scfvb-page,.scfvb-page *{box-sizing:border-box}.scfvb-page a.scfvb-node{text-decoration:none}.scfvb-page .scfvb-node>p{font:inherit;color:inherit;text-align:inherit}.scfvb-dynamic-list{margin:.5em 0;padding-left:1.25em}.scfvb-color-value{display:inline-flex;align-items:center;gap:.4em}.scfvb-color-swatch{display:inline-block;width:1em;height:1em;border:1px solid currentColor;border-radius:2px}.scfvb-gallery-items{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px}.scfvb-gallery-image{display:block;width:100%;height:auto;max-width:100%}';
        $css .= 'body.scfvb-page-layout-fullwidth{overflow-x:hidden;overflow-x:clip}.scfvb-layout-fullwidth{position:relative;width:100vw;max-width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important}';
        $css .= 'body.scfvb-page-layout-canvas{margin:0;overflow-x:hidden;overflow-x:clip}body.scfvb-page-layout-canvas .scfvb-page{width:100%;max-width:none;margin:0}';
        $css .= $rules['desktop'];

        // Max-width queries intentionally cascade downward. Laptop overrides are
        // inherited by Tablet/Mobile unless a smaller breakpoint overrides them.
        if ( $rules['laptop'] ) {
            $css .= '@media(max-width:1198px){' . $rules['laptop'] . '}';
        }
        if ( $rules['tablet'] ) {
            $css .= '@media(max-width:991px){' . $rules['tablet'] . '}';
        }
        if ( $rules['mobile'] ) {
            $css .= '@media(max-width:767px){' . $rules['mobile'] . '}';
        }
        return $css;
    }

    private function style_declarations( array $styles, array $token_refs = array() ): string {
        $skip = array();
        $out = $this->design_token_declarations( $token_refs, $skip );
        foreach ( self::STYLE_MAP as $key => $property ) {
            if ( isset( $skip[ $key ] ) || ! isset( $styles[ $key ] ) || '' === $styles[ $key ] ) {
                continue;
            }
            $value = $this->sanitize_css_value( $key, (string) $styles[ $key ] );
            if ( null !== $value ) {
                $out .= $property . ':' . $value . ';';
                if ( 'borderWidth' === $key && '0' !== $value && '0px' !== $value ) {
                    $out .= 'border-style:solid;';
                }
            }
        }

        // Background-image metadata is stored alongside responsive styles so a
        // Section/Container can use WordPress media without exposing raw CSS.
        $background_type = isset( $styles['backgroundType'] ) ? sanitize_key( (string) $styles['backgroundType'] ) : '';
        if ( 'none' === $background_type ) {
            $out .= 'background-image:none;background-color:transparent;';
        } elseif ( 'color' === $background_type ) {
            $out .= 'background-image:none;';
        } elseif ( 'image' === $background_type ) {
            // A responsive breakpoint may explicitly keep Image mode while
            // inheriting the actual media from a larger breakpoint. Only emit
            // background-image when this breakpoint contains a media reference;
            // otherwise let the earlier rule continue to apply.
            $has_background_reference = array_key_exists( 'backgroundImageId', $styles ) || array_key_exists( 'backgroundImageUrl', $styles );
            if ( $has_background_reference ) {
                $background_url = '';
                $background_id = isset( $styles['backgroundImageId'] ) ? absint( $styles['backgroundImageId'] ) : 0;
                if ( $background_id ) {
                    $background_url = wp_get_attachment_image_url( $background_id, 'full' ) ?: '';
                }
                if ( ! $background_url && isset( $styles['backgroundImageUrl'] ) ) {
                    $background_url = (string) $styles['backgroundImageUrl'];
                }
                if ( 'none' === $background_url || '' === $background_url ) {
                    $out .= 'background-image:none;';
                } else {
                    $background_url = esc_url_raw( $background_url );
                    if ( $background_url ) {
                        $out .= 'background-image:url(' . wp_json_encode( $background_url ) . ');';
                    }
                }
            }
        } elseif ( isset( $styles['backgroundImageUrl'] ) ) {
            // Backward/forward tolerant fallback if a stored layout has a URL but
            // predates the explicit backgroundType marker.
            $background_url = (string) $styles['backgroundImageUrl'];
            if ( 'none' === $background_url ) {
                $out .= 'background-image:none;';
            } elseif ( $background_url = esc_url_raw( $background_url ) ) {
                $out .= 'background-image:url(' . wp_json_encode( $background_url ) . ');';
            }
        }

        return $out;
    }

    private function design_token_declarations( array $refs, array &$skip ): string {
        if ( empty( $refs ) || empty( $this->design_tokens ) ) {
            return '';
        }

        $out = '';
        foreach ( $refs as $key => $token_id ) {
            $key = trim( (string) $key );
            $token_id = sanitize_key( (string) $token_id );
            if ( ! SCFVB_Design_System::reference_allowed( $key, $token_id ) || ! isset( $this->design_tokens[ $token_id ] ) ) {
                continue;
            }
            $token = $this->design_tokens[ $token_id ];

            if ( 'typography' === $key && 'typography' === ( $token['category'] ?? '' ) && is_array( $token['value'] ?? null ) ) {
                foreach ( array( 'fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'letterSpacing' ) as $type_key ) {
                    if ( ! array_key_exists( $type_key, $token['value'] ) || ! isset( self::STYLE_MAP[ $type_key ] ) ) {
                        continue;
                    }
                    $value = $this->sanitize_css_value( $type_key, (string) $token['value'][ $type_key ] );
                    if ( null !== $value ) {
                        $out .= self::STYLE_MAP[ $type_key ] . ':' . $value . ';';
                        $skip[ $type_key ] = true;
                    }
                }
                continue;
            }

            if ( ! isset( self::STYLE_MAP[ $key ] ) ) {
                continue;
            }
            $value = is_scalar( $token['value'] ?? null ) ? $this->sanitize_css_value( $key, (string) $token['value'] ) : null;
            if ( null !== $value ) {
                $out .= self::STYLE_MAP[ $key ] . ':' . $value . ';';
                $skip[ $key ] = true;
            }
        }
        return $out;
    }

    private function sanitize_css_value( string $key, string $value ): ?string {
        $value = trim( $value );

        $dimension_keys = array(
            'width', 'minWidth', 'maxWidth', 'height', 'minHeight', 'maxHeight',
            'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
            'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
            'gap', 'columnGap', 'rowGap', 'fontSize', 'borderWidth', 'borderRadius',
            'top', 'right', 'bottom', 'left'
        );
        if ( in_array( $key, $dimension_keys, true ) ) {
            $auto_keys = array( 'width', 'minWidth', 'maxWidth', 'height', 'minHeight', 'maxHeight', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'top', 'right', 'bottom', 'left' );
            if ( 'auto' === $value ) {
                return in_array( $key, $auto_keys, true ) ? $value : null;
            }

            if ( '0' === $value ) {
                return $value;
            }

            if ( ! preg_match( '/^-?\d+(?:\.\d+)?(?:px|%|rem|em|vw|vh|vmin|vmax)$/', $value ) ) {
                return null;
            }

            $allows_negative = in_array( $key, array( 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'top', 'right', 'bottom', 'left' ), true );
            if ( str_starts_with( $value, '-' ) && ! $allows_negative ) {
                return null;
            }

            return $value;
        }

        if ( in_array( $key, array( 'backgroundColor', 'color', 'borderColor' ), true ) ) {
            return preg_match( '/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value ) || 'transparent' === $value ? $value : null;
        }

        $enums = array(
            'display'              => array( 'block', 'flex', 'grid', 'inline-block', 'none' ),
            'flexDirection'        => array( 'row', 'column', 'row-reverse', 'column-reverse' ),
            'justifyContent'       => array( 'flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly', 'stretch' ),
            'alignItems'           => array( 'stretch', 'flex-start', 'center', 'flex-end', 'baseline' ),
            'textAlign'            => array( 'left', 'center', 'right', 'justify' ),
            'position'             => array( 'static', 'relative', 'absolute', 'fixed', 'sticky' ),
            'overflow'             => array( 'visible', 'hidden', 'auto', 'scroll', 'clip' ),
            'gridAutoFlow'         => array( 'row', 'column', 'dense', 'row dense', 'column dense' ),
            'backgroundSize'       => array( 'cover', 'contain', 'auto' ),
            'backgroundPosition'   => array( 'center center', 'center top', 'center bottom', 'left center', 'right center', 'left top', 'right top', 'left bottom', 'right bottom' ),
            'backgroundRepeat'     => array( 'no-repeat', 'repeat', 'repeat-x', 'repeat-y' ),
            'backgroundAttachment' => array( 'scroll', 'fixed', 'local' ),
            'objectFit'             => array( 'fill', 'contain', 'cover', 'none', 'scale-down' ),
            'objectPosition'        => array( 'center center', 'center top', 'center bottom', 'left center', 'right center', 'left top', 'right top', 'left bottom', 'right bottom' ),
        );
        if ( isset( $enums[ $key ] ) ) {
            return in_array( $value, $enums[ $key ], true ) ? $value : null;
        }

        if ( 'gridTemplateColumns' === $key ) {
            if ( preg_match( '/^repeat\((?:[1-9]|1[0-2]),minmax\(0,1fr\)\)$/', $value ) ) {
                return $value;
            }
            if ( preg_match( '/^repeat\((?:auto-fit|auto-fill),minmax\((?:\d+(?:\.\d+)?(?:px|rem|em|%|vw)),1fr\)\)$/', $value ) ) {
                return $value;
            }
            return null;
        }

        if ( 'gridTemplateRows' === $key ) {
            return 'none' === $value || preg_match( '/^repeat\((?:[1-9]|1[0-2]),auto\)$/', $value ) ? $value : null;
        }

        if ( 'aspectRatio' === $key ) {
            if ( 'auto' === $value ) {
                return $value;
            }
            if ( preg_match( '/^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/', $value, $matches ) ) {
                if ( (float) $matches[1] > 0 && (float) $matches[2] > 0 ) {
                    return $matches[1] . '/' . $matches[2];
                }
            }
            return null;
        }

        if ( 'zIndex' === $key ) {
            if ( preg_match( '/^-?\d{1,5}$/', $value ) ) {
                $number = (int) $value;
                return (string) max( -9999, min( 9999, $number ) );
            }
            return null;
        }

        if ( 'fontFamily' === $key ) {
            if ( 'inherit' === $value ) return 'inherit';
            return strlen( $value ) <= 100 && preg_match( '/^[a-zA-Z0-9 ,"\'\-]+$/', $value ) ? $value : null;
        }

        if ( 'lineHeight' === $key ) {
            return preg_match( '/^(?:\d+(?:\.\d+)?|\d+(?:\.\d+)?(?:px|rem|em|%))$/', $value ) ? $value : null;
        }

        if ( 'letterSpacing' === $key ) {
            if ( '0' === $value ) return '0';
            return preg_match( '/^-?\d+(?:\.\d+)?(?:px|rem|em)$/', $value ) ? $value : null;
        }

        if ( 'boxShadow' === $key ) {
            if ( 'none' === $value ) return 'none';
            if ( strlen( $value ) > 180 || preg_match( '/[;{}<>]/', $value ) || preg_match( '/\b(?:url|expression|javascript|var)\s*\(/i', $value ) ) return null;
            return preg_match( '/^[0-9a-zA-Z#().,%\s\-]+$/', $value ) ? $value : null;
        }

        if ( 'fontWeight' === $key ) {
            return preg_match( '/^[1-9]00$/', $value ) || in_array( $value, array( 'normal', 'bold' ), true ) ? $value : null;
        }

        return null;
    }
}
