<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Site-wide design tokens shared by every SCF Visual Builder page.
 *
 * Layouts only store stable token IDs. Values live in one WordPress option so
 * changing a token updates every page that references it without rewriting
 * page layout JSON or SCF content.
 */
final class SCFVB_Design_System {
    public const OPTION = 'scfvb_design_system';
    public const VERSION = 1;
    private const CATEGORIES = array( 'colors', 'spacing', 'radii', 'shadows', 'typography' );

    public static function defaults(): array {
        return array(
            'version' => self::VERSION,
            'colors' => array(
                array( 'id' => 'color_primary', 'name' => 'Primary', 'value' => '#2563eb' ),
                array( 'id' => 'color_secondary', 'name' => 'Secondary', 'value' => '#475569' ),
                array( 'id' => 'color_accent', 'name' => 'Accent', 'value' => '#7c3aed' ),
                array( 'id' => 'color_text', 'name' => 'Text', 'value' => '#111827' ),
                array( 'id' => 'color_muted', 'name' => 'Muted Text', 'value' => '#6b7280' ),
                array( 'id' => 'color_background', 'name' => 'Background', 'value' => '#ffffff' ),
                array( 'id' => 'color_surface', 'name' => 'Surface', 'value' => '#f8fafc' ),
                array( 'id' => 'color_border', 'name' => 'Border', 'value' => '#e5e7eb' ),
            ),
            'spacing' => array(
                array( 'id' => 'space_xs', 'name' => 'XS', 'value' => '4px' ),
                array( 'id' => 'space_sm', 'name' => 'SM', 'value' => '8px' ),
                array( 'id' => 'space_md', 'name' => 'MD', 'value' => '16px' ),
                array( 'id' => 'space_lg', 'name' => 'LG', 'value' => '24px' ),
                array( 'id' => 'space_xl', 'name' => 'XL', 'value' => '32px' ),
                array( 'id' => 'space_2xl', 'name' => '2XL', 'value' => '48px' ),
                array( 'id' => 'space_3xl', 'name' => '3XL', 'value' => '64px' ),
            ),
            'radii' => array(
                array( 'id' => 'radius_sm', 'name' => 'SM', 'value' => '4px' ),
                array( 'id' => 'radius_md', 'name' => 'MD', 'value' => '8px' ),
                array( 'id' => 'radius_lg', 'name' => 'LG', 'value' => '16px' ),
                array( 'id' => 'radius_xl', 'name' => 'XL', 'value' => '24px' ),
                array( 'id' => 'radius_pill', 'name' => 'Pill', 'value' => '9999px' ),
            ),
            'shadows' => array(
                array( 'id' => 'shadow_sm', 'name' => 'SM', 'value' => '0 1px 2px #00000014' ),
                array( 'id' => 'shadow_md', 'name' => 'MD', 'value' => '0 4px 12px #0000001f' ),
                array( 'id' => 'shadow_lg', 'name' => 'LG', 'value' => '0 12px 30px #00000029' ),
            ),
            'typography' => array(
                array(
                    'id' => 'type_heading', 'name' => 'Heading',
                    'value' => array( 'fontFamily' => 'inherit', 'fontSize' => '48px', 'fontWeight' => '700', 'lineHeight' => '1.1', 'letterSpacing' => '-0.02em' ),
                ),
                array(
                    'id' => 'type_subheading', 'name' => 'Subheading',
                    'value' => array( 'fontFamily' => 'inherit', 'fontSize' => '28px', 'fontWeight' => '600', 'lineHeight' => '1.2', 'letterSpacing' => '0' ),
                ),
                array(
                    'id' => 'type_body', 'name' => 'Body',
                    'value' => array( 'fontFamily' => 'inherit', 'fontSize' => '16px', 'fontWeight' => '400', 'lineHeight' => '1.6', 'letterSpacing' => '0' ),
                ),
                array(
                    'id' => 'type_button', 'name' => 'Button',
                    'value' => array( 'fontFamily' => 'inherit', 'fontSize' => '16px', 'fontWeight' => '600', 'lineHeight' => '1.2', 'letterSpacing' => '0' ),
                ),
            ),
        );
    }

    public static function get(): array {
        $stored = get_option( self::OPTION, null );
        if ( ! is_array( $stored ) ) {
            return self::defaults();
        }
        return self::sanitize( $stored );
    }

    public static function update( array $input ) {
        $clean = self::sanitize( $input );
        update_option( self::OPTION, $clean, false );
        $stored = get_option( self::OPTION, null );
        if ( ! is_array( $stored ) || self::sanitize( $stored ) !== $clean ) {
            return new WP_Error( 'scfvb_design_system_write_failed', 'The global design system could not be verified after storage.', array( 'status' => 500 ) );
        }
        return $clean;
    }

    public static function revision( ?array $system = null ): string {
        $system = self::sanitize( $system ?: self::get() );
        $json = wp_json_encode( $system, JSON_UNESCAPED_SLASHES );
        return hash( 'sha256', false === $json ? '' : $json );
    }

    public static function sanitize( array $input ): array {
        $defaults = self::defaults();
        $clean = array( 'version' => self::VERSION );
        $seen = array();

        foreach ( self::CATEGORIES as $category ) {
            $source = isset( $input[ $category ] ) && is_array( $input[ $category ] ) ? $input[ $category ] : $defaults[ $category ];
            $clean[ $category ] = array();
            foreach ( array_slice( $source, 0, 60 ) as $token ) {
                if ( ! is_array( $token ) ) {
                    continue;
                }
                $id = sanitize_key( $token['id'] ?? '' );
                $prefix = self::prefix_for_category( $category );
                if ( ! preg_match( '/^' . preg_quote( $prefix, '/' ) . '[a-z0-9_-]{1,48}$/', $id ) || isset( $seen[ $id ] ) ) {
                    continue;
                }
                $name = sanitize_text_field( $token['name'] ?? '' );
                if ( '' === $name ) {
                    $name = ucwords( str_replace( array( $prefix, '_', '-' ), array( '', ' ', ' ' ), $id ) );
                }
                $value = self::sanitize_value( $category, $token['value'] ?? null );
                if ( null === $value ) {
                    continue;
                }
                $seen[ $id ] = true;
                $clean[ $category ][] = array( 'id' => $id, 'name' => $name, 'value' => $value );
            }
        }

        return $clean;
    }

    public static function token_map( ?array $system = null ): array {
        $system = $system ?: self::get();
        $map = array();
        foreach ( self::CATEGORIES as $category ) {
            foreach ( $system[ $category ] ?? array() as $token ) {
                if ( ! empty( $token['id'] ) ) {
                    $map[ $token['id'] ] = array( 'category' => $category, 'value' => $token['value'], 'name' => $token['name'] ?? $token['id'] );
                }
            }
        }
        return $map;
    }

    public static function reference_allowed( string $property, string $token_id ): bool {
        if ( ! preg_match( '/^(?:color|space|radius|shadow|type)_[a-z0-9_-]{1,48}$/', $token_id ) ) {
            return false;
        }
        if ( 'typography' === $property ) {
            return str_starts_with( $token_id, 'type_' );
        }
        if ( in_array( $property, array( 'color', 'backgroundColor', 'borderColor' ), true ) ) {
            return str_starts_with( $token_id, 'color_' );
        }
        if ( in_array( $property, array(
            'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
            'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
            'gap', 'columnGap', 'rowGap'
        ), true ) ) {
            return str_starts_with( $token_id, 'space_' );
        }
        if ( 'borderRadius' === $property ) {
            return str_starts_with( $token_id, 'radius_' );
        }
        if ( 'boxShadow' === $property ) {
            return str_starts_with( $token_id, 'shadow_' );
        }
        return false;
    }

    private static function prefix_for_category( string $category ): string {
        return array(
            'colors' => 'color_', 'spacing' => 'space_', 'radii' => 'radius_',
            'shadows' => 'shadow_', 'typography' => 'type_',
        )[ $category ] ?? 'token_';
    }

    private static function sanitize_value( string $category, $value ) {
        if ( 'colors' === $category ) {
            $value = trim( (string) $value );
            return preg_match( '/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value ) || 'transparent' === $value ? $value : null;
        }
        if ( in_array( $category, array( 'spacing', 'radii' ), true ) ) {
            return self::sanitize_dimension( (string) $value, false );
        }
        if ( 'shadows' === $category ) {
            $value = trim( (string) $value );
            if ( 'none' === $value ) return 'none';
            if ( '' === $value || strlen( $value ) > 180 || preg_match( '/[;{}<>]/', $value ) ) return null;
            if ( preg_match( '/\b(?:url|expression|javascript|var)\s*\(/i', $value ) ) return null;
            return preg_match( '/^[0-9a-zA-Z#().,%\s\-]+$/', $value ) ? $value : null;
        }
        if ( 'typography' === $category ) {
            if ( ! is_array( $value ) ) return null;
            $font_family = trim( sanitize_text_field( (string) ( $value['fontFamily'] ?? 'inherit' ) ) );
            if ( 'inherit' !== $font_family && ( '' === $font_family || strlen( $font_family ) > 100 || ! preg_match( '/^[a-zA-Z0-9 ,"\'\-]+$/', $font_family ) ) ) {
                $font_family = 'inherit';
            }
            $font_size = self::sanitize_dimension( (string) ( $value['fontSize'] ?? '16px' ), false ) ?: '16px';
            $font_weight = trim( (string) ( $value['fontWeight'] ?? '400' ) );
            if ( ! preg_match( '/^[1-9]00$/', $font_weight ) && ! in_array( $font_weight, array( 'normal', 'bold' ), true ) ) $font_weight = '400';
            $line_height = trim( (string) ( $value['lineHeight'] ?? '1.5' ) );
            if ( ! preg_match( '/^(?:\d+(?:\.\d+)?|\d+(?:\.\d+)?(?:px|rem|em|%))$/', $line_height ) ) $line_height = '1.5';
            $letter_spacing = trim( (string) ( $value['letterSpacing'] ?? '0' ) );
            if ( '0' !== $letter_spacing && ! preg_match( '/^-?\d+(?:\.\d+)?(?:px|rem|em)$/', $letter_spacing ) ) $letter_spacing = '0';
            return array(
                'fontFamily' => $font_family,
                'fontSize' => $font_size,
                'fontWeight' => $font_weight,
                'lineHeight' => $line_height,
                'letterSpacing' => $letter_spacing,
            );
        }
        return null;
    }

    private static function sanitize_dimension( string $value, bool $negative ): ?string {
        $value = trim( $value );
        if ( '0' === $value ) return '0';
        if ( ! preg_match( '/^-?\d+(?:\.\d+)?(?:px|rem|em|%|vw|vh|vmin|vmax)$/', $value ) ) return null;
        if ( ! $negative && str_starts_with( $value, '-' ) ) return null;
        return $value;
    }
}
