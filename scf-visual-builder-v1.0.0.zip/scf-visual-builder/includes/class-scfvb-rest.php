<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_REST {
    private const META_ENABLED = '_scfvb_enabled';
    private const META_LAYOUT  = '_scfvb_layout';
    private const META_VERSION = '_scfvb_layout_version';
    private const META_LAYOUT_BACKUP = '_scfvb_layout_backup';
    private const META_LAYOUT_BACKUP_VERSION = '_scfvb_layout_backup_version';
    private const META_SAVED_AT = '_scfvb_saved_at';
    private const FIELD_NAME_MAX_LENGTH = 64;
    private const STORAGE_NAME_MAX_LENGTH = 240;

    private const ALLOWED_TYPES = array( 'section', 'container', 'heading', 'text', 'image', 'button' );
    private const ALLOWED_STYLE_KEYS = array(
        'display',
        'width', 'minWidth', 'maxWidth', 'height', 'minHeight', 'maxHeight',
        'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
        'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
        'flexDirection', 'justifyContent', 'alignItems', 'gap',
        'gridTemplateColumns', 'gridTemplateRows', 'columnGap', 'rowGap', 'gridAutoFlow',
        'position', 'top', 'right', 'bottom', 'left', 'zIndex', 'overflow',
        'backgroundType', 'backgroundColor', 'backgroundImageId', 'backgroundImageUrl',
        'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment',
        'color', 'fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'letterSpacing',
        'borderWidth', 'borderColor', 'borderRadius', 'boxShadow', 'textAlign',
        'objectFit', 'objectPosition', 'aspectRatio',
    );

    public function hooks(): void {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route(
            'scfvb/v1',
            '/pages/(?P<id>\d+)/layout',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_layout' ),
                    'permission_callback' => array( $this, 'can_edit' ),
                ),
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'save_layout' ),
                    'permission_callback' => array( $this, 'can_edit' ),
                ),
            )
        );


        register_rest_route(
            'scfvb/v1',
            '/design-system',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_design_system' ),
                    'permission_callback' => array( $this, 'can_manage_design_system' ),
                ),
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'save_design_system' ),
                    'permission_callback' => array( $this, 'can_manage_design_system' ),
                ),
            )
        );

        register_rest_route(
            'scfvb/v1',
            '/components',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_components' ),
                    'permission_callback' => array( $this, 'can_manage_components' ),
                ),
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'create_component' ),
                    'permission_callback' => array( $this, 'can_manage_components' ),
                ),
            )
        );

        register_rest_route(
            'scfvb/v1',
            '/components/(?P<component_id>component_[a-z0-9_-]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'update_component' ),
                    'permission_callback' => array( $this, 'can_manage_components' ),
                ),
                array(
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => array( $this, 'delete_component' ),
                    'permission_callback' => array( $this, 'can_manage_components' ),
                ),
            )
        );
    }

    public function can_manage_components(): bool {
        return current_user_can( 'edit_pages' );
    }

    public function can_manage_design_system(): bool {
        return current_user_can( 'edit_pages' );
    }

    public function get_design_system() {
        $system = SCFVB_Design_System::get();
        return rest_ensure_response( array(
            'designSystem' => $system,
            'revision'     => SCFVB_Design_System::revision( $system ),
        ) );
    }

    public function save_design_system( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        if ( ! isset( $params['designSystem'] ) || ! is_array( $params['designSystem'] ) ) {
            return new WP_Error( 'scfvb_design_system_required', 'A designSystem object is required.', array( 'status' => 400 ) );
        }
        $current = SCFVB_Design_System::get();
        $current_revision = SCFVB_Design_System::revision( $current );
        $base_revision = isset( $params['baseRevision'] ) ? strtolower( sanitize_text_field( (string) $params['baseRevision'] ) ) : '';
        if ( $base_revision && ! preg_match( '/^[a-f0-9]{64}$/', $base_revision ) ) {
            return new WP_Error( 'scfvb_invalid_design_revision', 'The submitted global-style revision is invalid.', array( 'status' => 400 ) );
        }
        if ( $base_revision && ! hash_equals( $current_revision, $base_revision ) ) {
            return new WP_Error( 'scfvb_design_system_conflict', 'Global styles were changed elsewhere. Reload them before saving to avoid overwriting newer changes.', array( 'status' => 409, 'serverRevision' => $current_revision ) );
        }
        $saved = SCFVB_Design_System::update( $params['designSystem'] );
        if ( is_wp_error( $saved ) ) {
            return $saved;
        }
        return rest_ensure_response( array(
            'designSystem' => $saved,
            'revision'     => SCFVB_Design_System::revision( $saved ),
        ) );
    }

    public function get_components() {
        return rest_ensure_response(
            array(
                'components' => array_values( SCFVB_Components::instance()->all() ),
            )
        );
    }

    public function create_component( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $node = isset( $params['node'] ) && is_array( $params['node'] ) ? $params['node'] : null;
        if ( ! $node ) {
            return new WP_Error( 'scfvb_component_node_required', 'A Section or Container is required.', array( 'status' => 400 ) );
        }
        $clean = $this->sanitize_component_root( $node );
        if ( is_wp_error( $clean ) ) {
            return $clean;
        }
        $name = isset( $params['name'] ) ? sanitize_text_field( $params['name'] ) : ( $clean['name'] ?? 'Component' );
        $component = SCFVB_Components::instance()->create( $name, $clean );
        if ( is_wp_error( $component ) ) {
            return $component;
        }
        return rest_ensure_response( array( 'component' => $component ) );
    }

    public function update_component( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $node = isset( $params['node'] ) && is_array( $params['node'] ) ? $params['node'] : null;
        if ( ! $node ) {
            return new WP_Error( 'scfvb_component_node_required', 'A Section or Container is required.', array( 'status' => 400 ) );
        }
        $clean = $this->sanitize_component_root( $node );
        if ( is_wp_error( $clean ) ) {
            return $clean;
        }
        $component_id = sanitize_key( $request['component_id'] );
        $existing = SCFVB_Components::instance()->get( $component_id );
        if ( ! $existing ) {
            return new WP_Error( 'scfvb_component_not_found', 'Component not found.', array( 'status' => 404 ) );
        }
        $base_revision = isset( $params['baseRevision'] ) ? absint( $params['baseRevision'] ) : 0;
        if ( $base_revision > 0 && $base_revision !== absint( $existing['revision'] ?? 0 ) ) {
            return new WP_Error( 'scfvb_component_conflict', 'This component was updated elsewhere. Refresh the component library before updating it again.', array( 'status' => 409, 'serverRevision' => absint( $existing['revision'] ?? 0 ) ) );
        }
        $name = isset( $params['name'] ) ? sanitize_text_field( $params['name'] ) : '';
        $component = SCFVB_Components::instance()->update( $component_id, $name, $clean );
        if ( is_wp_error( $component ) ) {
            return $component;
        }
        return rest_ensure_response( array( 'component' => $component ) );
    }

    public function delete_component( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $component_id = sanitize_key( $request['component_id'] );
        $existing = SCFVB_Components::instance()->get( $component_id );
        $base_revision = isset( $params['baseRevision'] ) ? absint( $params['baseRevision'] ) : 0;
        if ( $existing && $base_revision > 0 && $base_revision !== absint( $existing['revision'] ?? 0 ) ) {
            return new WP_Error( 'scfvb_component_conflict', 'This component changed elsewhere. Refresh the component library before deleting it.', array( 'status' => 409, 'serverRevision' => absint( $existing['revision'] ?? 0 ) ) );
        }
        $deleted = SCFVB_Components::instance()->delete( $component_id );
        if ( is_wp_error( $deleted ) ) {
            return $deleted;
        }
        if ( ! $deleted ) {
            return new WP_Error( 'scfvb_component_delete_failed', 'The component could not be deleted.', array( 'status' => 500 ) );
        }
        return rest_ensure_response( array( 'deleted' => true ) );
    }

    private function sanitize_component_root( array $node ) {
        $type = sanitize_key( $node['type'] ?? '' );
        if ( ! in_array( $type, array( 'section', 'container' ), true ) ) {
            return new WP_Error( 'scfvb_component_root', 'Only Sections and Containers can be saved as components.', array( 'status' => 400 ) );
        }
        $count = 0;
        $seen = array();
        // A Container is valid as a child of an imaginary Section. A Section is
        // valid at the root. Reuse the same page-node sanitizer for both cases.
        $clean = $this->sanitize_node( $node, 0, $count, 'container' === $type ? 'section' : null, $seen );
        if ( is_wp_error( $clean ) ) {
            return $clean;
        }
        // A component can be inserted on a page before that page has ever been
        // saved, so its master schema must already be internally unambiguous.
        $nodes = array( $clean );
        $renamed = array();
        $this->deduplicate_flexible_layout_names( $nodes, $renamed );
        $this->deduplicate_schema_field_names( $nodes, $renamed, 'component' );
        $component_layout = array(
            'version'  => SCFVB_Layout::VERSION,
            'settings' => array( 'pageLayout' => 'fullwidth' ),
            'nodes'    => $nodes,
        );
        $validation = $this->validate_unique_field_bindings( $component_layout );
        if ( is_wp_error( $validation ) ) {
            return $validation;
        }
        return $nodes[0];
    }

    public function can_edit( WP_REST_Request $request ): bool {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );
        return (bool) ( $post && 'page' === $post->post_type && current_user_can( 'edit_post', $post_id ) );
    }

    public function get_layout( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $raw = get_post_meta( $post_id, self::META_LAYOUT, true );
        $raw = is_string( $raw ) ? $raw : '';
        $layout = $this->decode_layout_raw( $raw );
        $recovery_mode = false;

        // v1.0 keeps the primary layout protected if it is corrupt, but can still
        // open the editor from the last verified backup. The user must explicitly
        // press Save before that backup replaces the corrupt primary metadata.
        if ( is_wp_error( $layout ) ) {
            $backup = $this->load_backup_layout( $post_id );
            if ( is_wp_error( $backup ) ) {
                return $layout;
            }
            $layout = $backup;
            $recovery_mode = true;
        }

        return rest_ensure_response(
            array(
                'enabled'         => (bool) get_post_meta( $post_id, self::META_ENABLED, true ),
                'layout'          => $layout,
                'revision'        => $this->layout_revision( $raw ),
                'lastSavedAt'     => absint( get_post_meta( $post_id, self::META_SAVED_AT, true ) ),
                'backupAvailable' => $this->has_valid_backup( $post_id ),
                'recoveryMode'    => $recovery_mode,
            )
        );
    }

    public function save_layout( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $params = $request->get_json_params();

        if ( ! isset( $params['layout'] ) || ! is_array( $params['layout'] ) ) {
            return new WP_Error( 'scfvb_invalid_layout', 'A layout object is required.', array( 'status' => 400 ) );
        }

        // Optimistic concurrency: a stale editor tab/user must not silently
        // overwrite a layout saved after it was loaded. Older clients that do not
        // send baseRevision remain compatible, but the bundled v1 editor always does.
        $current_raw = get_post_meta( $post_id, self::META_LAYOUT, true );
        $current_raw = is_string( $current_raw ) ? $current_raw : '';
        $current_revision = $this->layout_revision( $current_raw );
        $base_revision = isset( $params['baseRevision'] ) ? strtolower( sanitize_text_field( (string) $params['baseRevision'] ) ) : '';
        if ( '' !== $base_revision && ! preg_match( '/^[a-f0-9]{64}$/', $base_revision ) ) {
            return new WP_Error( 'scfvb_invalid_revision', 'The submitted layout revision is invalid.', array( 'status' => 400 ) );
        }
        if ( '' !== $base_revision && ! hash_equals( $current_revision, $base_revision ) ) {
            return new WP_Error(
                'scfvb_layout_conflict',
                'This page layout was saved elsewhere after you opened the builder. Reload the builder before saving so newer changes are not overwritten.',
                array( 'status' => 409, 'serverRevision' => $current_revision )
            );
        }

        $sanitized = $this->sanitize_layout( $params['layout'] );
        if ( is_wp_error( $sanitized ) ) {
            return $sanitized;
        }
        $sanitized = SCFVB_Components::instance()->resolve_layout( $sanitized );
        // Component resolution can introduce master nodes that were not present
        // in the submitted snapshot. Re-run the page sanitizer so those nodes
        // receive the same hierarchy/style/identity validation as native nodes.
        $sanitized = $this->sanitize_layout( $sanitized );
        if ( is_wp_error( $sanitized ) ) {
            return $sanitized;
        }

        // Resolve duplicate logical SCF names at save time instead of making the
        // user hunt through the tree manually. Names are only compared within the
        // same SCF schema scope (page, Group, or Repeater). The first occurrence
        // keeps its name; later duplicates receive _2, _3, etc. Stable field keys
        // are never changed, so existing values can be migrated safely below.
        $auto_renamed = array();
        $this->deduplicate_flexible_layout_names( $sanitized['nodes'], $auto_renamed );
        $this->deduplicate_schema_field_names( $sanitized['nodes'], $auto_renamed, 'page' );

        $identity_validation = $this->validate_unique_field_bindings( $sanitized );
        if ( is_wp_error( $identity_validation ) ) {
            return $identity_validation;
        }

        $recover_from_backup = ! empty( $params['recoverFromBackup'] );
        $old_layout = $this->decode_layout_raw( $current_raw );
        if ( is_wp_error( $old_layout ) ) {
            if ( ! $recover_from_backup ) {
                return $old_layout;
            }
            $old_layout = $this->load_backup_layout( $post_id );
            if ( is_wp_error( $old_layout ) ) {
                return new WP_Error( 'scfvb_recovery_unavailable', 'The primary layout is corrupt and no valid verified backup is available.', array( 'status' => 409 ) );
            }
        }

        $layout_json = wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES );
        if ( false === $layout_json ) {
            return new WP_Error( 'scfvb_layout_encode_failed', 'The layout could not be encoded for storage.', array( 'status' => 500 ) );
        }

        $meta_conflicts = $this->validate_new_field_meta_conflicts( $post_id, $old_layout, $sanitized );
        if ( is_wp_error( $meta_conflicts ) ) {
            return $meta_conflicts;
        }

        $boundary_validation = $this->validate_structured_boundary_changes( $post_id, $old_layout, $sanitized );
        if ( is_wp_error( $boundary_validation ) ) {
            return $boundary_validation;
        }

        // Keep one last-known-good primary layout only after every non-mutating
        // validation has passed and immediately before schema/meta staging begins.
        // Never replace a good backup with a corrupt primary during recovery mode.
        if ( ! $recover_from_backup && '' !== $current_raw && $current_raw !== $layout_json ) {
            $backup_result = $this->store_layout_backup( $post_id, $current_raw );
            if ( is_wp_error( $backup_result ) ) {
                return $backup_result;
            }
        }

        $migration = $this->migrate_renamed_fields( $post_id, $old_layout, $sanitized );
        if ( is_wp_error( $migration ) ) {
            return $migration;
        }

        $previous_meta = array(
            self::META_ENABLED => array( 'exists' => metadata_exists( 'post', $post_id, self::META_ENABLED ), 'value' => get_post_meta( $post_id, self::META_ENABLED, true ) ),
            self::META_VERSION => array( 'exists' => metadata_exists( 'post', $post_id, self::META_VERSION ), 'value' => get_post_meta( $post_id, self::META_VERSION, true ) ),
            self::META_SAVED_AT => array( 'exists' => metadata_exists( 'post', $post_id, self::META_SAVED_AT ), 'value' => get_post_meta( $post_id, self::META_SAVED_AT, true ) ),
        );
        $had_primary = metadata_exists( 'post', $post_id, self::META_LAYOUT );

        // update_post_meta() unslashes values internally. Slash JSON first so quotes,
        // backslashes and other escaped content survive the round-trip intact.
        update_post_meta( $post_id, self::META_LAYOUT, wp_slash( $layout_json ) );
        $stored_layout_json = get_post_meta( $post_id, self::META_LAYOUT, true );
        if ( ! is_string( $stored_layout_json ) || $stored_layout_json !== $layout_json ) {
            $this->restore_primary_layout( $post_id, $current_raw, $had_primary, $previous_meta );
            $this->rollback_staged_migrations( $post_id, $migration['created'] ?? array() );
            return new WP_Error( 'scfvb_layout_write_failed', 'The layout could not be verified after storage. Existing SCF values were left at their original keys.', array( 'status' => 500 ) );
        }

        $saved_at = time();
        update_post_meta( $post_id, self::META_ENABLED, 1 );
        update_post_meta( $post_id, self::META_VERSION, SCFVB_Layout::VERSION );
        update_post_meta( $post_id, self::META_SAVED_AT, $saved_at );
        $metadata_verified = '1' === (string) get_post_meta( $post_id, self::META_ENABLED, true )
            && SCFVB_Layout::VERSION === absint( get_post_meta( $post_id, self::META_VERSION, true ) )
            && $saved_at === absint( get_post_meta( $post_id, self::META_SAVED_AT, true ) );
        if ( ! $metadata_verified ) {
            $this->restore_primary_layout( $post_id, $current_raw, $had_primary, $previous_meta );
            $this->rollback_staged_migrations( $post_id, $migration['created'] ?? array() );
            return new WP_Error( 'scfvb_layout_metadata_write_failed', 'The layout metadata could not be verified. The previous layout and SCF values were restored.', array( 'status' => 500 ) );
        }

        $this->finalize_staged_migrations( $post_id, $migration['renames'] ?? array() );
        $new_revision = $this->layout_revision( $layout_json );

        return rest_ensure_response(
            array(
                'saved'       => true,
                'layout'      => $sanitized,
                'autoRenamed' => $auto_renamed,
                'revision'    => $new_revision,
                'lastSavedAt' => $saved_at,
                'backupAvailable' => $this->has_valid_backup( $post_id ),
            )
        );
    }

    private function load_layout( int $post_id ) {
        $raw = get_post_meta( $post_id, self::META_LAYOUT, true );
        return $this->decode_layout_raw( is_string( $raw ) ? $raw : '' );
    }

    private function decode_layout_raw( string $raw ) {
        if ( '' === $raw ) {
            return SCFVB_Layout::default_layout();
        }
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            return SCFVB_Components::instance()->resolve_layout( SCFVB_Layout::normalize( $decoded ) );
        }
        return new WP_Error(
            'scfvb_corrupt_layout',
            'The stored Visual Builder layout is not valid JSON. It was not overwritten.',
            array( 'status' => 409 )
        );
    }

    private function layout_revision( string $raw ): string {
        return hash( 'sha256', $raw );
    }

    private function has_valid_backup( int $post_id ): bool {
        $backup = get_post_meta( $post_id, self::META_LAYOUT_BACKUP, true );
        if ( ! is_string( $backup ) || '' === $backup ) {
            return false;
        }
        $decoded = json_decode( $backup, true );
        return is_array( $decoded );
    }

    private function load_backup_layout( int $post_id ) {
        $backup = get_post_meta( $post_id, self::META_LAYOUT_BACKUP, true );
        if ( ! is_string( $backup ) || '' === $backup ) {
            return new WP_Error( 'scfvb_backup_missing', 'No Visual Builder backup is available.', array( 'status' => 404 ) );
        }
        $decoded = json_decode( $backup, true );
        if ( ! is_array( $decoded ) ) {
            return new WP_Error( 'scfvb_backup_corrupt', 'The Visual Builder backup is not valid JSON.', array( 'status' => 409 ) );
        }
        return SCFVB_Components::instance()->resolve_layout( SCFVB_Layout::normalize( $decoded ) );
    }

    private function store_layout_backup( int $post_id, string $raw ) {
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            return new WP_Error( 'scfvb_backup_source_invalid', 'The current layout could not be verified, so it was not used as a backup.', array( 'status' => 409 ) );
        }
        $backup_version = max( 1, absint( $decoded['version'] ?? 1 ) );
        update_post_meta( $post_id, self::META_LAYOUT_BACKUP, wp_slash( $raw ) );
        update_post_meta( $post_id, self::META_LAYOUT_BACKUP_VERSION, $backup_version );
        $stored = get_post_meta( $post_id, self::META_LAYOUT_BACKUP, true );
        $stored_version = absint( get_post_meta( $post_id, self::META_LAYOUT_BACKUP_VERSION, true ) );
        if ( ! is_string( $stored ) || $stored !== $raw || $stored_version !== $backup_version ) {
            return new WP_Error( 'scfvb_backup_write_failed', 'The previous layout could not be backed up safely, so this save was cancelled.', array( 'status' => 500 ) );
        }
        return true;
    }

    private function restore_primary_layout( int $post_id, string $raw, bool $had_primary, array $previous_meta ): void {
        if ( $had_primary ) {
            update_post_meta( $post_id, self::META_LAYOUT, wp_slash( $raw ) );
        } else {
            delete_post_meta( $post_id, self::META_LAYOUT );
        }
        foreach ( $previous_meta as $key => $snapshot ) {
            if ( ! empty( $snapshot['exists'] ) ) {
                update_post_meta( $post_id, $key, wp_slash( $snapshot['value'] ) );
            } else {
                delete_post_meta( $post_id, $key );
            }
        }
    }

    private function sanitize_layout( array $layout ) {
        $nodes = isset( $layout['nodes'] ) && is_array( $layout['nodes'] ) ? $layout['nodes'] : array();
        if ( count( $nodes ) > 200 ) {
            return new WP_Error( 'scfvb_too_many_nodes', 'The layout contains too many root nodes.', array( 'status' => 400 ) );
        }

        $count = 0;
        $seen_node_ids = array();
        $sanitized_nodes = array();
        foreach ( $nodes as $node ) {
            $clean = $this->sanitize_node( $node, 0, $count, null, $seen_node_ids );
            if ( is_wp_error( $clean ) ) {
                return $clean;
            }
            $sanitized_nodes[] = $clean;
        }

        $page_layout = isset( $layout['settings']['pageLayout'] ) ? sanitize_key( $layout['settings']['pageLayout'] ) : 'fullwidth';
        if ( ! in_array( $page_layout, SCFVB_Layout::PAGE_LAYOUTS, true ) ) {
            return new WP_Error( 'scfvb_invalid_page_layout', 'Unsupported page layout mode.', array( 'status' => 400 ) );
        }

        return array(
            'version'  => SCFVB_Layout::VERSION,
            'settings' => array( 'pageLayout' => $page_layout ),
            'nodes'    => $sanitized_nodes,
        );
    }

    private function sanitize_node( $node, int $depth, int &$count, ?string $parent_type, array &$seen_node_ids ) {
        if ( ! is_array( $node ) || $depth > 20 || ++$count > 500 ) {
            return new WP_Error( 'scfvb_invalid_tree', 'The layout tree is invalid or too deeply nested.', array( 'status' => 400 ) );
        }

        $type = isset( $node['type'] ) ? sanitize_key( $node['type'] ) : '';
        if ( ! in_array( $type, self::ALLOWED_TYPES, true ) ) {
            return new WP_Error( 'scfvb_invalid_node_type', 'Unsupported node type.', array( 'status' => 400 ) );
        }

        if ( ! $this->can_contain( $parent_type, $type ) ) {
            return new WP_Error(
                'scfvb_invalid_hierarchy',
                sprintf( 'A %s element cannot be placed inside %s.', $type, null === $parent_type ? 'the page root' : $parent_type ),
                array( 'status' => 400 )
            );
        }

        $id = isset( $node['id'] ) ? sanitize_key( $node['id'] ) : '';
        if ( ! preg_match( '/^node_[a-z0-9_-]{4,64}$/', $id ) ) {
            return new WP_Error( 'scfvb_invalid_node_id', 'Every node must have a stable node_* ID.', array( 'status' => 400 ) );
        }
        if ( isset( $seen_node_ids[ $id ] ) ) {
            return new WP_Error( 'scfvb_duplicate_node_id', sprintf( 'Duplicate node ID "%s" detected.', $id ), array( 'status' => 400 ) );
        }
        $seen_node_ids[ $id ] = true;

        $bindings = $this->sanitize_bindings(
            isset( $node['bindings'] ) && is_array( $node['bindings'] ) ? $node['bindings'] : array(),
            $type
        );
        if ( is_wp_error( $bindings ) ) {
            return $bindings;
        }

        $clean = array(
            'id'       => $id,
            'type'     => $type,
            'name'     => isset( $node['name'] ) ? sanitize_text_field( $node['name'] ) : ucfirst( $type ),
            'settings' => $this->sanitize_settings( isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : array(), $type ),
            'content'  => $this->sanitize_content( isset( $node['content'] ) && is_array( $node['content'] ) ? $node['content'] : array() ),
            'bindings' => $bindings,
            'styles'   => $this->sanitize_styles( isset( $node['styles'] ) && is_array( $node['styles'] ) ? $node['styles'] : array(), $type ),
            'styleTokens' => $this->sanitize_style_tokens( isset( $node['styleTokens'] ) && is_array( $node['styleTokens'] ) ? $node['styleTokens'] : array() ),
            'children' => array(),
        );


        if ( isset( $node['templateKey'] ) ) {
            $template_key = sanitize_key( $node['templateKey'] );
            if ( preg_match( '/^tmpl_[a-z0-9_-]{6,64}$/', $template_key ) ) {
                $clean['templateKey'] = $template_key;
            }
        }
        if ( isset( $node['component'] ) && is_array( $node['component'] ) && ! empty( $node['component']['linked'] ) && in_array( $type, array( 'section', 'container' ), true ) ) {
            $component_id = sanitize_key( $node['component']['id'] ?? '' );
            $instance_id = sanitize_key( $node['component']['instanceId'] ?? '' );
            if ( preg_match( '/^component_[a-z0-9_-]{6,64}$/', $component_id ) && preg_match( '/^cmpinst_[a-z0-9_-]{6,64}$/', $instance_id ) ) {
                $clean['component'] = array(
                    'id'         => $component_id,
                    'linked'     => true,
                    'instanceId' => $instance_id,
                    'revision'   => max( 1, absint( $node['component']['revision'] ?? 1 ) ),
                );
            }
        }

        $flexible = $this->sanitize_flexible( isset( $node['flexible'] ) && is_array( $node['flexible'] ) ? $node['flexible'] : array(), $type );
        if ( is_wp_error( $flexible ) ) return $flexible;
        if ( $flexible ) $clean['flexible'] = $flexible;

        $flex_layout = $this->sanitize_flex_layout( isset( $node['flexLayout'] ) && is_array( $node['flexLayout'] ) ? $node['flexLayout'] : array(), $type );
        if ( is_wp_error( $flex_layout ) ) return $flex_layout;
        if ( $flex_layout ) $clean['flexLayout'] = $flex_layout;

        $group = $this->sanitize_group( isset( $node['group'] ) && is_array( $node['group'] ) ? $node['group'] : array(), $type );
        if ( is_wp_error( $group ) ) {
            return $group;
        }
        $repeater = $this->sanitize_repeater( isset( $node['repeater'] ) && is_array( $node['repeater'] ) ? $node['repeater'] : array(), $type );
        if ( is_wp_error( $repeater ) ) {
            return $repeater;
        }
        if ( $group && $repeater ) {
            return new WP_Error( 'scfvb_multiple_schema_boundaries', 'A Container cannot be both an SCF Group and an SCF Repeater.', array( 'status' => 400 ) );
        }
        if ( $group ) {
            $clean['group'] = $group;
        }
        if ( $repeater ) {
            $clean['repeater'] = $repeater;
        }

        $children = isset( $node['children'] ) && is_array( $node['children'] ) ? $node['children'] : array();
        if ( ! empty( $children ) && ! in_array( $type, array( 'section', 'container' ), true ) ) {
            return new WP_Error( 'scfvb_leaf_has_children', sprintf( 'The %s element cannot contain child elements.', $type ), array( 'status' => 400 ) );
        }

        foreach ( $children as $child ) {
            $clean_child = $this->sanitize_node( $child, $depth + 1, $count, $type, $seen_node_ids );
            if ( is_wp_error( $clean_child ) ) {
                return $clean_child;
            }
            $clean['children'][] = $clean_child;
        }

        if ( $flexible ) {
            if ( empty( $clean['children'] ) ) {
                return new WP_Error( 'scfvb_flexible_no_layouts', 'Flexible Content requires at least one Container layout.', array( 'status' => 400 ) );
            }
            $seen_layout_keys = array();
            $seen_layout_names = array();
            foreach ( $clean['children'] as $child ) {
                if ( 'container' !== ( $child['type'] ?? '' ) || empty( $child['flexLayout']['key'] ) || empty( $child['flexLayout']['name'] ) ) {
                    return new WP_Error( 'scfvb_invalid_flexible_layout', 'Every direct child of Flexible Content must be a Container with a Flexible layout identity.', array( 'status' => 400 ) );
                }
                $layout_key = $child['flexLayout']['key'];
                $layout_name = $child['flexLayout']['name'];
                if ( isset( $seen_layout_keys[ $layout_key ] ) ) {
                    return new WP_Error( 'scfvb_duplicate_flexible_layout_key', 'Flexible Content layout keys must be unique.', array( 'status' => 400 ) );
                }
                $seen_layout_keys[ $layout_key ] = true;
                $seen_layout_names[ $layout_name ] = true;
            }
        }

        return $clean;
    }

    private function can_contain( ?string $parent_type, string $child_type ): bool {
        if ( null === $parent_type ) {
            return 'section' === $child_type;
        }
        if ( 'section' === $parent_type ) {
            return 'container' === $child_type;
        }
        if ( 'container' === $parent_type ) {
            return in_array( $child_type, array( 'container', 'heading', 'text', 'image', 'button' ), true );
        }
        return false;
    }

    private function sanitize_flexible( array $flexible, string $node_type ) {
        if ( 'section' !== $node_type || empty( $flexible['enabled'] ) ) return null;
        $field_key = sanitize_key( $flexible['fieldKey'] ?? '' );
        $field_name = sanitize_key( $flexible['fieldName'] ?? '' );
        $label = sanitize_text_field( $flexible['label'] ?? '' );
        $button_label = sanitize_text_field( $flexible['buttonLabel'] ?? '' );
        $min = max( 0, min( 100, absint( $flexible['min'] ?? 0 ) ) );
        $max = max( 0, min( 100, absint( $flexible['max'] ?? 0 ) ) );
        if ( ! preg_match( '/^field_scfvb_flexible_[a-z0-9_-]{4,64}$/', $field_key ) || '' === $field_name || strlen( $field_name ) > self::FIELD_NAME_MAX_LENGTH ) {
            return new WP_Error( 'scfvb_invalid_flexible', 'Flexible Content is missing a valid stable field key/field name, or its field name is too long.', array( 'status' => 400 ) );
        }
        if ( $max > 0 && $min > $max ) return new WP_Error( 'scfvb_invalid_flexible_limits', 'Flexible Content minimum rows cannot be greater than maximum rows.', array( 'status' => 400 ) );
        return array(
            'enabled' => true, 'fieldKey' => $field_key, 'fieldName' => $field_name,
            'label' => $label ?: ucwords( str_replace( '_', ' ', $field_name ) ),
            'buttonLabel' => $button_label ?: 'Add Section', 'min' => $min, 'max' => $max,
        );
    }

    private function sanitize_flex_layout( array $layout, string $node_type ) {
        if ( 'container' !== $node_type || empty( $layout ) ) return null;
        $key = sanitize_key( $layout['key'] ?? '' );
        $name = sanitize_key( $layout['name'] ?? '' );
        $label = sanitize_text_field( $layout['label'] ?? '' );
        $display = sanitize_key( $layout['display'] ?? 'block' );
        if ( ! preg_match( '/^layout_scfvb_[a-z0-9_-]{4,64}$/', $key ) || '' === $name || strlen( $name ) > self::FIELD_NAME_MAX_LENGTH ) {
            return new WP_Error( 'scfvb_invalid_flex_layout', 'Flexible Content layout is missing a valid stable layout key/name.', array( 'status' => 400 ) );
        }
        if ( ! in_array( $display, array( 'block', 'row', 'table' ), true ) ) return new WP_Error( 'scfvb_invalid_flex_layout_display', 'Unsupported Flexible Content layout display mode.', array( 'status' => 400 ) );
        return array( 'key' => $key, 'name' => $name, 'label' => $label ?: ucwords( str_replace( '_', ' ', $name ) ), 'display' => $display );
    }

    private function sanitize_group( array $group, string $node_type ) {
        if ( 'container' !== $node_type || empty( $group['enabled'] ) ) {
            return null;
        }

        $field_key = isset( $group['fieldKey'] ) ? sanitize_key( $group['fieldKey'] ) : '';
        $field_name = isset( $group['fieldName'] ) ? sanitize_key( $group['fieldName'] ) : '';
        $label = isset( $group['label'] ) ? sanitize_text_field( $group['label'] ) : '';

        if ( ! preg_match( '/^field_scfvb_(?:group_)?[a-z0-9_-]{4,64}$/', $field_key ) || '' === $field_name || strlen( $field_name ) > self::FIELD_NAME_MAX_LENGTH ) {
            return new WP_Error(
                'scfvb_invalid_group',
                'An SCF Group container is missing a valid stable field key/field name, or its field name is too long.',
                array( 'status' => 400 )
            );
        }

        return array(
            'enabled'   => true,
            'fieldKey'  => $field_key,
            'fieldName' => $field_name,
            'label'     => $label ?: ucwords( str_replace( '_', ' ', $field_name ) ),
        );
    }

    private function sanitize_repeater( array $repeater, string $node_type ) {
        if ( 'container' !== $node_type || empty( $repeater['enabled'] ) ) {
            return null;
        }

        $field_key = isset( $repeater['fieldKey'] ) ? sanitize_key( $repeater['fieldKey'] ) : '';
        $field_name = isset( $repeater['fieldName'] ) ? sanitize_key( $repeater['fieldName'] ) : '';
        $label = isset( $repeater['label'] ) ? sanitize_text_field( $repeater['label'] ) : '';
        $button_label = isset( $repeater['buttonLabel'] ) ? sanitize_text_field( $repeater['buttonLabel'] ) : 'Add Row';
        $layout = isset( $repeater['layout'] ) ? sanitize_key( $repeater['layout'] ) : 'block';
        $min = isset( $repeater['min'] ) ? max( 0, min( 100, absint( $repeater['min'] ) ) ) : 0;
        $max = isset( $repeater['max'] ) ? max( 0, min( 100, absint( $repeater['max'] ) ) ) : 0;

        if ( ! preg_match( '/^field_scfvb_(?:repeater_)?[a-z0-9_-]{4,64}$/', $field_key ) || '' === $field_name || strlen( $field_name ) > self::FIELD_NAME_MAX_LENGTH ) {
            return new WP_Error(
                'scfvb_invalid_repeater',
                'An SCF Repeater container is missing a valid stable field key/field name, or its field name is too long.',
                array( 'status' => 400 )
            );
        }
        if ( ! in_array( $layout, array( 'block', 'row', 'table' ), true ) ) {
            return new WP_Error( 'scfvb_invalid_repeater_layout', 'Unsupported SCF Repeater layout.', array( 'status' => 400 ) );
        }
        if ( $max > 0 && $min > $max ) {
            return new WP_Error( 'scfvb_invalid_repeater_limits', 'Repeater minimum rows cannot be greater than maximum rows.', array( 'status' => 400 ) );
        }

        return array(
            'enabled'     => true,
            'fieldKey'    => $field_key,
            'fieldName'   => $field_name,
            'label'       => $label ?: ucwords( str_replace( '_', ' ', $field_name ) ),
            'layout'      => $layout,
            'buttonLabel' => $button_label ?: 'Add Row',
            'min'         => $min,
            'max'         => $max,
        );
    }

    private function sanitize_settings( array $settings, string $node_type ): array {
        $clean = array();
        if ( 'heading' === $node_type && isset( $settings['tag'] ) ) {
            $tag = strtolower( sanitize_key( $settings['tag'] ) );
            if ( in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
                $clean['tag'] = $tag;
            }
        }
        return $clean;
    }

    private function sanitize_content( array $content ): array {
        $clean = array();
        if ( isset( $content['text'] ) ) {
            $clean['text'] = sanitize_textarea_field( $content['text'] );
        }
        if ( isset( $content['label'] ) ) {
            $clean['label'] = sanitize_text_field( $content['label'] );
        }
        if ( isset( $content['url'] ) ) {
            $clean['url'] = esc_url_raw( $content['url'] );
        }
        if ( isset( $content['imageId'] ) ) {
            $clean['imageId'] = absint( $content['imageId'] );
        }
        if ( isset( $content['imageUrl'] ) ) {
            $clean['imageUrl'] = esc_url_raw( $content['imageUrl'] );
        }
        if ( isset( $content['altText'] ) ) {
            $clean['altText'] = substr( sanitize_text_field( (string) $content['altText'] ), 0, 500 );
        }
        return $clean;
    }

    private function binding_schema( string $node_type ): array {
        // v0.7 keeps the visual element vocabulary intentionally small while
        // allowing those elements to consume richer SCF values. Complex values
        // are normalized by the frontend renderer according to their field type.
        $schema = array(
            'heading' => array(
                'text' => array( 'text', 'number', 'email', 'select', 'radio', 'true_false', 'date_picker', 'date_time_picker', 'color_picker', 'post_object', 'taxonomy' ),
            ),
            'text'    => array(
                'text' => array( 'text', 'textarea', 'wysiwyg', 'number', 'email', 'select', 'checkbox', 'radio', 'true_false', 'date_picker', 'date_time_picker', 'color_picker', 'file', 'link', 'page_link', 'post_object', 'relationship', 'taxonomy' ),
            ),
            'image'   => array( 'image' => array( 'image', 'gallery' ) ),
            'button'  => array(
                'label' => array( 'text', 'select', 'radio' ),
                'url'   => array( 'url', 'link', 'file', 'page_link', 'post_object' ),
            ),
        );
        return $schema[ $node_type ] ?? array();
    }

    private function sanitize_bindings( array $bindings, string $node_type ) {
        $clean = array();
        foreach ( $this->binding_schema( $node_type ) as $key => $allowed_types ) {
            if ( empty( $bindings[ $key ] ) || ! is_array( $bindings[ $key ] ) ) {
                continue;
            }

            $binding = $bindings[ $key ];
            $source = isset( $binding['source'] ) && 'scf' === $binding['source'] ? 'scf' : 'static';
            $field_key = isset( $binding['fieldKey'] ) ? sanitize_key( $binding['fieldKey'] ) : '';
            $field_name = isset( $binding['fieldName'] ) ? sanitize_key( $binding['fieldName'] ) : '';
            $field_type = isset( $binding['fieldType'] ) ? sanitize_key( $binding['fieldType'] ) : $allowed_types[0];
            $label = isset( $binding['label'] ) ? sanitize_text_field( $binding['label'] ) : ucwords( str_replace( '_', ' ', $field_name ) );

            if ( ! in_array( $field_type, $allowed_types, true ) ) {
                if ( 'scf' === $source ) {
                    return new WP_Error(
                        'scfvb_invalid_field_type',
                        sprintf( 'Field type "%s" is not valid for the %s binding on a %s element.', $field_type, $key, $node_type ),
                        array( 'status' => 400 )
                    );
                }
                $field_type = $allowed_types[0];
            }

            $item = array(
                'source'    => $source,
                'fieldType' => $field_type,
            );

            if ( $field_key && preg_match( '/^field_scfvb_[a-z0-9_-]{4,64}$/', $field_key ) ) {
                $item['fieldKey'] = $field_key;
            }
            if ( $field_name ) {
                $item['fieldName'] = $field_name;
            }
            if ( $label ) {
                $item['label'] = $label;
            }

            $options = $this->sanitize_binding_options(
                isset( $binding['options'] ) && is_array( $binding['options'] ) ? $binding['options'] : array(),
                $field_type,
                $node_type,
                $key
            );
            if ( ! empty( $options ) ) {
                $item['options'] = $options;
            }

            if ( ! empty( $item['fieldName'] ) && strlen( $item['fieldName'] ) > self::FIELD_NAME_MAX_LENGTH ) {
                return new WP_Error(
                    'scfvb_field_name_too_long',
                    sprintf( 'Field name "%s" is too long. Use %d characters or fewer.', $item['fieldName'], self::FIELD_NAME_MAX_LENGTH ),
                    array( 'status' => 400 )
                );
            }

            if ( 'scf' === $source ) {
                if ( empty( $item['fieldKey'] ) || empty( $item['fieldName'] ) ) {
                    return new WP_Error(
                        'scfvb_invalid_scf_binding',
                        sprintf( 'The %s binding on %s is missing a valid stable field key or field name.', $key, $node_type ),
                        array( 'status' => 400 )
                    );
                }
            }

            $clean[ $key ] = $item;
        }
        return $clean;
    }

    /**
     * Sanitize optional SCF field configuration. Only settings used by the
     * selected field type survive a save, preventing stale options from one
     * field type from leaking into another after the user switches types.
     */
    private function sanitize_binding_options( array $options, string $field_type, string $node_type, string $binding_key ): array {
        $clean = array();

        if ( in_array( $field_type, array( 'select', 'checkbox', 'radio' ), true ) ) {
            $choices = isset( $options['choicesText'] ) ? sanitize_textarea_field( (string) $options['choicesText'] ) : '';
            if ( strlen( $choices ) > 4000 ) {
                $choices = substr( $choices, 0, 4000 );
            }
            if ( '' !== trim( $choices ) ) {
                $clean['choicesText'] = $choices;
            }
            if ( 'select' === $field_type ) {
                $clean['multiple'] = ! empty( $options['multiple'] );
            }
            if ( in_array( $field_type, array( 'select', 'radio' ), true ) ) {
                $clean['allowNull'] = ! empty( $options['allowNull'] );
            }
        }

        if ( 'number' === $field_type ) {
            foreach ( array( 'min', 'max', 'step' ) as $key ) {
                if ( isset( $options[ $key ] ) && '' !== trim( (string) $options[ $key ] ) && is_numeric( $options[ $key ] ) ) {
                    $clean[ $key ] = (string) ( 0 + $options[ $key ] );
                }
            }
        }

        if ( 'true_false' === $field_type ) {
            $clean['trueLabel'] = isset( $options['trueLabel'] ) ? substr( sanitize_text_field( (string) $options['trueLabel'] ), 0, 60 ) : 'Yes';
            $clean['falseLabel'] = isset( $options['falseLabel'] ) ? substr( sanitize_text_field( (string) $options['falseLabel'] ), 0, 60 ) : 'No';
        }

        if ( in_array( $field_type, array( 'post_object', 'relationship' ), true ) ) {
            $raw_post_types = $options['postTypes'] ?? array();
            if ( is_string( $raw_post_types ) ) {
                $raw_post_types = preg_split( '/[\s,]+/', $raw_post_types );
            }
            if ( is_array( $raw_post_types ) ) {
                $post_types = array_values( array_unique( array_filter( array_map( 'sanitize_key', array_slice( $raw_post_types, 0, 20 ) ) ) ) );
                if ( $post_types ) {
                    $clean['postTypes'] = $post_types;
                }
            }
            $clean['allowNull'] = ! empty( $options['allowNull'] );
            if ( 'post_object' === $field_type ) {
                // A Button URL must resolve to one destination. Other visual
                // contexts can deliberately display multiple selected posts.
                $clean['multiple'] = ! ( 'button' === $node_type && 'url' === $binding_key ) && ! empty( $options['multiple'] );
            }
            if ( 'relationship' === $field_type ) {
                $min = isset( $options['minItems'] ) ? min( 100, absint( $options['minItems'] ) ) : 0;
                $max = isset( $options['maxItems'] ) ? min( 100, absint( $options['maxItems'] ) ) : 0;
                if ( $max > 0 && $min > $max ) {
                    $min = $max;
                }
                $clean['minItems'] = $min;
                $clean['maxItems'] = $max;
            }
        }

        if ( 'taxonomy' === $field_type ) {
            $taxonomy = sanitize_key( (string) ( $options['taxonomy'] ?? 'category' ) );
            $clean['taxonomy'] = $taxonomy ?: 'category';
            $clean['multiple'] = ! empty( $options['multiple'] );
            $clean['allowNull'] = ! empty( $options['allowNull'] );
        }

        if ( in_array( $field_type, array( 'date_picker', 'date_time_picker' ), true ) ) {
            $default_format = 'date_picker' === $field_type ? 'F j, Y' : 'F j, Y g:i a';
            $format = isset( $options['displayFormat'] ) ? sanitize_text_field( (string) $options['displayFormat'] ) : $default_format;
            if ( '' === $format || strlen( $format ) > 60 || ! preg_match( '/^[A-Za-z0-9 _.,:\/\\-]+$/', $format ) ) {
                $format = $default_format;
            }
            $clean['displayFormat'] = $format;
        }

        if ( 'gallery' === $field_type ) {
            $min = isset( $options['minItems'] ) ? min( 100, absint( $options['minItems'] ) ) : 0;
            $max = isset( $options['maxItems'] ) ? min( 100, absint( $options['maxItems'] ) ) : 0;
            if ( $max > 0 && $min > $max ) {
                $min = $max;
            }
            $clean['minItems'] = $min;
            $clean['maxItems'] = $max;
        }

        if ( 'wysiwyg' === $field_type ) {
            $clean['mediaUpload'] = ! array_key_exists( 'mediaUpload', $options ) || ! empty( $options['mediaUpload'] );
        }

        if ( 'color_picker' === $field_type ) {
            $clean['enableOpacity'] = ! empty( $options['enableOpacity'] );
        }

        return $clean;
    }

    private function sanitize_style_tokens( array $tokens ): array {
        $clean = array( 'desktop' => array(), 'laptop' => array(), 'tablet' => array(), 'mobile' => array() );
        foreach ( $clean as $breakpoint => $_ ) {
            if ( empty( $tokens[ $breakpoint ] ) || ! is_array( $tokens[ $breakpoint ] ) ) {
                continue;
            }
            foreach ( $tokens[ $breakpoint ] as $property => $token_id ) {
                $property = trim( (string) $property );
                $token_id = sanitize_key( (string) $token_id );
                if ( SCFVB_Design_System::reference_allowed( $property, $token_id ) ) {
                    $clean[ $breakpoint ][ $property ] = $token_id;
                }
            }
        }
        return $clean;
    }

    private function sanitize_styles( array $styles, string $node_type ): array {
        $clean = array( 'desktop' => array(), 'laptop' => array(), 'tablet' => array(), 'mobile' => array() );
        foreach ( $clean as $breakpoint => $_ ) {
            if ( empty( $styles[ $breakpoint ] ) || ! is_array( $styles[ $breakpoint ] ) ) {
                continue;
            }
            foreach ( self::ALLOWED_STYLE_KEYS as $key ) {
                if ( ! array_key_exists( $key, $styles[ $breakpoint ] ) ) {
                    continue;
                }

                $container_only = array(
                    'flexDirection', 'justifyContent', 'alignItems', 'gap',
                    'gridTemplateColumns', 'gridTemplateRows', 'columnGap', 'rowGap', 'gridAutoFlow',
                    'overflow', 'backgroundType', 'backgroundImageId', 'backgroundImageUrl',
                    'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment',
                );
                if ( in_array( $key, $container_only, true ) && ! in_array( $node_type, array( 'section', 'container' ), true ) ) {
                    continue;
                }
                if ( in_array( $key, array( 'objectFit', 'objectPosition', 'aspectRatio' ), true ) && 'image' !== $node_type ) {
                    continue;
                }

                if ( 'backgroundImageId' === $key ) {
                    $clean[ $breakpoint ][ $key ] = absint( $styles[ $breakpoint ][ $key ] );
                    continue;
                }

                if ( 'backgroundImageUrl' === $key ) {
                    $raw_url = trim( (string) $styles[ $breakpoint ][ $key ] );
                    if ( 'none' === $raw_url ) {
                        $clean[ $breakpoint ][ $key ] = 'none';
                    } elseif ( '' !== $raw_url ) {
                        $url = esc_url_raw( $raw_url );
                        if ( $url ) {
                            $clean[ $breakpoint ][ $key ] = $url;
                        }
                    }
                    continue;
                }

                $value = sanitize_text_field( (string) $styles[ $breakpoint ][ $key ] );
                if ( '' === trim( $value ) || strlen( $value ) > 120 ) {
                    continue;
                }

                $value = $this->sanitize_style_value( $key, $value );
                if ( null !== $value ) {
                    $clean[ $breakpoint ][ $key ] = $value;
                }
            }
        }
        return $clean;
    }

    /**
     * Validate CSS-like scalar values before storing them. The renderer repeats
     * these checks as defense in depth, but invalid values should not survive a
     * save and then appear as phantom overrides in the editor.
     */
    private function sanitize_style_value( string $key, string $value ): ?string {
        $value = trim( $value );

        $dimension_keys = array(
            'width', 'minWidth', 'maxWidth', 'height', 'minHeight', 'maxHeight',
            'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
            'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
            'gap', 'columnGap', 'rowGap', 'fontSize', 'borderWidth', 'borderRadius',
            'top', 'right', 'bottom', 'left'
        );
        if ( in_array( $key, $dimension_keys, true ) ) {
            $auto_keys = array( 'width', 'minWidth', 'maxWidth', 'height', 'minHeight', 'maxHeight', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'top', 'right', 'bottom', 'left' );
            if ( 'auto' === $value ) {
                return in_array( $key, $auto_keys, true ) ? $value : null;
            }
            if ( '0' === $value ) {
                return '0';
            }
            if ( ! preg_match( '/^-?\d+(?:\.\d+)?(?:px|%|rem|em|vw|vh|vmin|vmax)$/', $value ) ) {
                return null;
            }
            $allows_negative = in_array( $key, array( 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'top', 'right', 'bottom', 'left' ), true );
            if ( str_starts_with( $value, '-' ) && ! $allows_negative ) {
                return null;
            }
            return $value;
        }

        if ( in_array( $key, array( 'backgroundColor', 'color', 'borderColor' ), true ) ) {
            return preg_match( '/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value ) || 'transparent' === $value ? $value : null;
        }

        $enums = array(
            'display'              => array( 'block', 'flex', 'grid', 'inline-block', 'none' ),
            'flexDirection'        => array( 'row', 'column', 'row-reverse', 'column-reverse' ),
            'justifyContent'       => array( 'flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly', 'stretch' ),
            'alignItems'           => array( 'stretch', 'flex-start', 'center', 'flex-end', 'baseline' ),
            'textAlign'            => array( 'left', 'center', 'right', 'justify' ),
            'position'             => array( 'static', 'relative', 'absolute', 'fixed', 'sticky' ),
            'overflow'             => array( 'visible', 'hidden', 'auto', 'scroll', 'clip' ),
            'gridAutoFlow'         => array( 'row', 'column', 'dense', 'row dense', 'column dense' ),
            'backgroundType'       => array( 'none', 'color', 'image' ),
            'backgroundSize'       => array( 'cover', 'contain', 'auto' ),
            'backgroundPosition'   => array( 'center center', 'center top', 'center bottom', 'left center', 'right center', 'left top', 'right top', 'left bottom', 'right bottom' ),
            'backgroundRepeat'     => array( 'no-repeat', 'repeat', 'repeat-x', 'repeat-y' ),
            'backgroundAttachment' => array( 'scroll', 'fixed', 'local' ),
            'objectFit'            => array( 'fill', 'contain', 'cover', 'none', 'scale-down' ),
            'objectPosition'       => array( 'center center', 'center top', 'center bottom', 'left center', 'right center', 'left top', 'right top', 'left bottom', 'right bottom' ),
        );
        if ( isset( $enums[ $key ] ) ) {
            return in_array( $value, $enums[ $key ], true ) ? $value : null;
        }

        if ( 'gridTemplateColumns' === $key ) {
            if ( preg_match( '/^repeat\((?:[1-9]|1[0-2]),minmax\(0,1fr\)\)$/', $value ) ) {
                return $value;
            }
            if ( preg_match( '/^repeat\((?:auto-fit|auto-fill),minmax\((?:\d+(?:\.\d+)?(?:px|rem|em|%|vw)),1fr\)\)$/', $value ) ) {
                return $value;
            }
            return null;
        }

        if ( 'gridTemplateRows' === $key ) {
            return 'none' === $value || preg_match( '/^repeat\((?:[1-9]|1[0-2]),auto\)$/', $value ) ? $value : null;
        }

        if ( 'aspectRatio' === $key ) {
            if ( 'auto' === $value ) {
                return $value;
            }
            if ( preg_match( '/^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/', $value, $matches ) ) {
                if ( (float) $matches[1] > 0 && (float) $matches[2] > 0 ) {
                    return $matches[1] . '/' . $matches[2];
                }
            }
            return null;
        }

        if ( 'zIndex' === $key ) {
            if ( preg_match( '/^-?\d{1,5}$/', $value ) ) {
                return (string) max( -9999, min( 9999, (int) $value ) );
            }
            return null;
        }

        if ( 'fontFamily' === $key ) {
            if ( 'inherit' === $value ) return 'inherit';
            return strlen( $value ) <= 100 && preg_match( '/^[a-zA-Z0-9 ,"\'\-]+$/', $value ) ? $value : null;
        }

        if ( 'lineHeight' === $key ) {
            return preg_match( '/^(?:\d+(?:\.\d+)?|\d+(?:\.\d+)?(?:px|rem|em|%))$/', $value ) ? $value : null;
        }

        if ( 'letterSpacing' === $key ) {
            if ( '0' === $value ) return '0';
            return preg_match( '/^-?\d+(?:\.\d+)?(?:px|rem|em)$/', $value ) ? $value : null;
        }

        if ( 'boxShadow' === $key ) {
            if ( 'none' === $value ) return 'none';
            if ( strlen( $value ) > 180 || preg_match( '/[;{}<>]/', $value ) || preg_match( '/\b(?:url|expression|javascript|var)\s*\(/i', $value ) ) return null;
            return preg_match( '/^[0-9a-zA-Z#().,%\s\-]+$/', $value ) ? $value : null;
        }

        if ( 'fontWeight' === $key ) {
            return preg_match( '/^[1-9]00$/', $value ) || in_array( $value, array( 'normal', 'bold' ), true ) ? $value : null;
        }

        return null;
    }

    private function deduplicate_flexible_layout_names( array &$nodes, array &$renamed ): void {
        foreach ( $nodes as &$node ) {
            if ( ! is_array( $node ) ) continue;
            if ( 'section' === ( $node['type'] ?? '' ) && ! empty( $node['flexible']['enabled'] ) ) {
                $reserved = array();
                foreach ( $node['children'] ?? array() as $child ) {
                    $name = (string) ( $child['flexLayout']['name'] ?? '' );
                    if ( '' !== $name ) $reserved[ $name ] = true;
                }
                $seen = array();
                foreach ( $node['children'] as &$child ) {
                    if ( empty( $child['flexLayout']['name'] ) ) continue;
                    $original = (string) $child['flexLayout']['name'];
                    if ( ! isset( $seen[ $original ] ) ) { $seen[ $original ] = true; continue; }
                    $number = 2;
                    do {
                        $suffix = '_' . $number++;
                        $base = rtrim( substr( $original, 0, max( 1, self::FIELD_NAME_MAX_LENGTH - strlen( $suffix ) ) ), '_' ) ?: 'layout';
                        $candidate = $base . $suffix;
                    } while ( isset( $seen[ $candidate ] ) || isset( $reserved[ $candidate ] ) );
                    $child['flexLayout']['name'] = $candidate;
                    $seen[ $candidate ] = true;
                    $renamed[] = array( 'fieldKey' => $child['flexLayout']['key'] ?? '', 'kind' => 'Flexible Layout', 'context' => $node['flexible']['fieldName'] ?? 'flexible', 'from' => $original, 'to' => $candidate );
                }
                unset( $child );
            }
            if ( ! empty( $node['children'] ) ) $this->deduplicate_flexible_layout_names( $node['children'], $renamed );
        }
        unset( $node );
    }

    /**
     * Ensure sibling SCF field names are unique before validation/migration.
     * Presentation-only Sections/Containers are transparent to schema scope,
     * while Groups and Repeaters create a fresh child scope.
     */
    private function deduplicate_schema_field_names( array &$nodes, array &$renamed, string $context ): void {
        $reserved = array();
        $this->collect_schema_names_for_scope( $nodes, $reserved );
        $seen = array();
        $this->deduplicate_schema_nodes_for_scope( $nodes, $seen, $reserved, $renamed, $context );
    }

    /** Collect the original names at one logical SCF level without entering boundaries. */
    private function collect_schema_names_for_scope( array $nodes, array &$reserved ): void {
        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }

            if ( 'section' === ( $node['type'] ?? '' ) && ! empty( $node['flexible']['enabled'] ) ) {
                $name = (string) ( $node['flexible']['fieldName'] ?? '' );
                if ( '' !== $name ) $reserved[ $name ] = true;
                continue;
            }

            if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['repeater']['enabled'] ) ) {
                $name = (string) ( $node['repeater']['fieldName'] ?? '' );
                if ( '' !== $name ) {
                    $reserved[ $name ] = true;
                }
                continue;
            }

            if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['group']['enabled'] ) ) {
                $name = (string) ( $node['group']['fieldName'] ?? '' );
                if ( '' !== $name ) {
                    $reserved[ $name ] = true;
                }
                continue;
            }

            foreach ( $node['bindings'] ?? array() as $binding ) {
                if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
                    continue;
                }
                $name = (string) ( $binding['fieldName'] ?? '' );
                if ( '' !== $name ) {
                    $reserved[ $name ] = true;
                }
            }

            if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
                $this->collect_schema_names_for_scope( $node['children'], $reserved );
            }
        }
    }

    /** Mutate names at one schema level, preserving all immutable field keys. */
    private function deduplicate_schema_nodes_for_scope( array &$nodes, array &$seen, array $reserved, array &$renamed, string $context ): void {
        foreach ( $nodes as &$node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }

            if ( 'section' === ( $node['type'] ?? '' ) && ! empty( $node['flexible']['enabled'] ) ) {
                $this->deduplicate_schema_identity( $node['flexible'], $seen, $reserved, $renamed, $context, 'Flexible Content' );
                if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
                    $child_context = $context . ' / ' . ( $node['flexible']['fieldName'] ?? 'flexible' );
                    // All layouts share the same row-level physical namespace; keep
                    // their subfield names unique for predictable raw-meta fallback.
                    $this->deduplicate_schema_field_names( $node['children'], $renamed, $child_context );
                }
                continue;
            }

            if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['repeater']['enabled'] ) ) {
                $this->deduplicate_schema_identity( $node['repeater'], $seen, $reserved, $renamed, $context, 'Repeater' );
                if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
                    $child_context = $context . ' / ' . ( $node['repeater']['fieldName'] ?? 'repeater' );
                    $this->deduplicate_schema_field_names( $node['children'], $renamed, $child_context );
                }
                continue;
            }

            if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['group']['enabled'] ) ) {
                $this->deduplicate_schema_identity( $node['group'], $seen, $reserved, $renamed, $context, 'Group' );
                if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
                    $child_context = $context . ' / ' . ( $node['group']['fieldName'] ?? 'group' );
                    $this->deduplicate_schema_field_names( $node['children'], $renamed, $child_context );
                }
                continue;
            }

            if ( ! empty( $node['bindings'] ) && is_array( $node['bindings'] ) ) {
                foreach ( $node['bindings'] as &$binding ) {
                    if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
                        continue;
                    }
                    $this->deduplicate_schema_identity( $binding, $seen, $reserved, $renamed, $context, 'Field' );
                }
                unset( $binding );
            }

            // Layout-only Sections and Containers do not establish an SCF scope.
            if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
                $this->deduplicate_schema_nodes_for_scope( $node['children'], $seen, $reserved, $renamed, $context );
            }
        }
        unset( $node );
    }

    private function deduplicate_schema_identity( array &$identity, array &$seen, array $reserved, array &$renamed, string $context, string $kind ): void {
        $original = (string) ( $identity['fieldName'] ?? '' );
        if ( '' === $original ) {
            return;
        }

        if ( ! isset( $seen[ $original ] ) ) {
            $seen[ $original ] = true;
            return;
        }

        $number = 2;
        do {
            $suffix = '_' . $number;
            $max_base_length = max( 1, self::FIELD_NAME_MAX_LENGTH - strlen( $suffix ) );
            $base = rtrim( substr( $original, 0, $max_base_length ), '_' );
            if ( '' === $base ) {
                $base = 'field';
            }
            $candidate = $base . $suffix;
            ++$number;
        } while ( isset( $seen[ $candidate ] ) || isset( $reserved[ $candidate ] ) );

        $identity['fieldName'] = $candidate;
        $seen[ $candidate ] = true;
        $renamed[] = array(
            'fieldKey' => (string) ( $identity['fieldKey'] ?? '' ),
            'kind'     => $kind,
            'context'  => $context,
            'from'     => $original,
            'to'       => $candidate,
        );
    }

    private function validate_unique_field_bindings( array $layout ) {
        // Stable identities remain unique even while a binding is temporarily static.
        // Migration code tracks fields by these keys, so duplicate inactive keys are
        // just as dangerous as duplicate active SCF keys.
        $all_keys = array();
        $all_key_validation = $this->validate_all_stable_field_keys( $layout['nodes'] ?? array(), $all_keys );
        if ( is_wp_error( $all_key_validation ) ) {
            return $all_key_validation;
        }

        $seen_keys = array();
        $schema_validation = $this->validate_schema_level( $layout['nodes'] ?? array(), $seen_keys, 'page' );
        if ( is_wp_error( $schema_validation ) ) {
            return $schema_validation;
        }

        return $this->validate_storage_names( $layout );
    }

    private function validate_all_stable_field_keys( array $nodes, array &$seen_keys ) {
        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }

            foreach ( array( 'group', 'repeater', 'flexible' ) as $boundary_type ) {
                $required_type = 'flexible' === $boundary_type ? 'section' : 'container';
                if ( $required_type !== ( $node['type'] ?? '' ) || empty( $node[ $boundary_type ]['enabled'] ) ) {
                    continue;
                }
                $field_key = $node[ $boundary_type ]['fieldKey'] ?? '';
                if ( $field_key ) {
                    if ( isset( $seen_keys[ $field_key ] ) ) {
                        return new WP_Error(
                            'scfvb_duplicate_field_key',
                            sprintf( 'SCF field key "%s" is used more than once. Each field/group/repeater must have a unique stable key.', $field_key ),
                            array( 'status' => 400 )
                        );
                    }
                    $seen_keys[ $field_key ] = true;
                }
            }

            if ( ! empty( $node['flexLayout']['key'] ) ) {
                $layout_key = (string) $node['flexLayout']['key'];
                if ( isset( $seen_keys[ $layout_key ] ) ) {
                    return new WP_Error( 'scfvb_duplicate_layout_key', sprintf( 'Flexible Content layout key "%s" is used more than once.', $layout_key ), array( 'status' => 400 ) );
                }
                $seen_keys[ $layout_key ] = true;
            }

            foreach ( $node['bindings'] ?? array() as $binding ) {
                $field_key = $binding['fieldKey'] ?? '';
                if ( ! $field_key ) {
                    continue;
                }
                if ( isset( $seen_keys[ $field_key ] ) ) {
                    return new WP_Error(
                        'scfvb_duplicate_field_key',
                        sprintf( 'SCF field key "%s" is used more than once. Each field/group must have a unique stable key.', $field_key ),
                        array( 'status' => 400 )
                    );
                }
                $seen_keys[ $field_key ] = true;
            }

            if ( ! empty( $node['children'] ) ) {
                $result = $this->validate_all_stable_field_keys( $node['children'], $seen_keys );
                if ( is_wp_error( $result ) ) {
                    return $result;
                }
            }
        }

        return true;
    }

    /**
     * SCF/ACF physically stores Group descendants as underscore-prefixed paths
     * (group_child, group_nested_child). Different logical schemas can therefore
     * collapse to the same post-meta key. Detect that before any data is moved.
     */
    private function validate_storage_names( array $layout ) {
        $fields = $this->collect_storage_fields( $layout, true );
        foreach ( $this->collect_repeater_fields( $layout ) as $field_key => $repeater ) {
            $fields[ 'repeater:' . $field_key ] = array(
                'storagePattern' => $repeater['storagePattern'] ?? '',
                'fieldName'      => $repeater['fieldName'] ?? '',
            );
        }
        foreach ( $this->collect_flexible_fields( $layout ) as $field_key => $flexible ) {
            $fields[ 'flexible:' . $field_key ] = array(
                'storagePattern' => $flexible['storagePattern'] ?? '',
                'fieldName'      => $flexible['fieldName'] ?? '',
            );
        }
        $seen_storage = array();
        $fixed_names = array();
        $patterns = array();

        foreach ( $fields as $field_key => $field ) {
            $storage = (string) ( $field['storagePattern'] ?? $field['storageName'] ?? '' );
            if ( '' === $storage ) {
                continue;
            }
            if ( strlen( $storage ) > self::STORAGE_NAME_MAX_LENGTH ) {
                return new WP_Error(
                    'scfvb_storage_name_too_long',
                    sprintf( 'The SCF storage path "%s" is too long. Shorten one or more Group/Repeater/field names.', $storage ),
                    array( 'status' => 400 )
                );
            }
            if ( isset( $seen_storage[ $storage ] ) && $seen_storage[ $storage ] !== $field_key ) {
                return new WP_Error(
                    'scfvb_storage_name_collision',
                    sprintf( 'Two SCF fields would use the same WordPress meta path "%s". Rename one field, Group, or Repeater.', $storage ),
                    array( 'status' => 409 )
                );
            }
            $seen_storage[ $storage ] = $field_key;
            if ( str_contains( $storage, '{row}' ) ) {
                $patterns[ $field_key ] = $storage;
            } else {
                $fixed_names[ $field_key ] = $storage;
            }
        }

        // A literal field such as team_0_name can collide with the first row of
        // repeater team -> name even though the logical schema looks different.
        foreach ( $patterns as $pattern_key => $pattern ) {
            $regex = '/^' . str_replace( '\\{row\\}', '\\d+', preg_quote( $pattern, '/' ) ) . '$/';
            foreach ( $fixed_names as $fixed_key => $fixed ) {
                if ( $pattern_key !== $fixed_key && preg_match( $regex, $fixed ) ) {
                    return new WP_Error(
                        'scfvb_repeater_storage_collision',
                        sprintf( 'SCF field "%s" can collide with Repeater storage path "%s". Rename the field or Repeater.', $fixed, $pattern ),
                        array( 'status' => 409 )
                    );
                }
            }
        }

        return true;
    }

    /**
     * Validate one logical SCF field level. Presentation-only containers are
     * transparent; Group containers establish a new sibling-name scope.
     */
    private function validate_schema_level( array $nodes, array &$seen_keys, string $context ) {
        $entries = $this->schema_entries_for_level( $nodes );
        $seen_names = array();

        foreach ( $entries as $entry ) {
            $identity = $entry['identity'];
            $field_key = $identity['fieldKey'] ?? '';
            $field_name = $identity['fieldName'] ?? '';

            if ( isset( $seen_keys[ $field_key ] ) ) {
                return new WP_Error(
                    'scfvb_duplicate_field_key',
                    sprintf( 'SCF field key "%s" is used more than once. Each field/group must have a unique stable key.', $field_key ),
                    array( 'status' => 400 )
                );
            }
            $seen_keys[ $field_key ] = true;

            if ( isset( $seen_names[ $field_name ] ) ) {
                return new WP_Error(
                    'scfvb_duplicate_field_name',
                    sprintf( 'SCF field name "%s" is used more than once inside %s. Sibling field names must be unique.', $field_name, $context ),
                    array( 'status' => 400 )
                );
            }
            $seen_names[ $field_name ] = true;

            if ( in_array( $entry['kind'], array( 'group', 'repeater', 'flexible' ), true ) ) {
                $result = $this->validate_schema_level( $entry['children'], $seen_keys, $context . ' / ' . $field_name );
                if ( is_wp_error( $result ) ) {
                    return $result;
                }
            }
        }

        return true;
    }

    /**
     * Return direct schema entries at a logical SCF level. Normal containers and
     * sections are flattened, but a Group container is emitted as one entry and
     * its descendants are reserved for that Group's subfield level.
     */
    private function schema_entries_for_level( array $nodes ): array {
        $entries = array();
        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }

            if ( 'section' === ( $node['type'] ?? '' ) && ! empty( $node['flexible']['enabled'] ) ) {
                $entries[] = array(
                    'kind' => 'flexible',
                    'identity' => $node['flexible'],
                    'children' => $node['children'] ?? array(),
                );
                continue;
            }

            if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['repeater']['enabled'] ) ) {
                $entries[] = array(
                    'kind'     => 'repeater',
                    'identity' => $node['repeater'],
                    'children' => $node['children'] ?? array(),
                );
                continue;
            }

            if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['group']['enabled'] ) ) {
                $entries[] = array(
                    'kind'     => 'group',
                    'identity' => $node['group'],
                    'children' => $node['children'] ?? array(),
                );
                continue;
            }

            foreach ( $node['bindings'] ?? array() as $binding ) {
                if ( 'scf' !== ( $binding['source'] ?? 'static' ) ) {
                    continue;
                }
                $entries[] = array(
                    'kind'     => 'field',
                    'identity' => $binding,
                    'children' => array(),
                );
            }

            if ( ! empty( $node['children'] ) ) {
                $entries = array_merge( $entries, $this->schema_entries_for_level( $node['children'] ) );
            }
        }
        return $entries;
    }

    /**
     * Collect leaf SCF bindings keyed by immutable field key, including the actual
     * post-meta storage name SCF/ACF uses for Group subfields (group_child...).
     */
    private function collect_storage_fields( array $layout, bool $only_scf = true ): array {
        $fields = array();
        $walk = function ( array $nodes, array $segments, array $repeaters ) use ( &$walk, &$fields, $only_scf ): void {
            foreach ( $nodes as $node ) {
                if ( ! is_array( $node ) ) {
                    continue;
                }

                $next_segments = $segments;
                $next_repeaters = $repeaters;
                if ( 'section' === ( $node['type'] ?? '' ) && ! empty( $node['flexible']['enabled'] ) && ! empty( $node['flexible']['fieldName'] ) ) {
                    $next_segments[] = $node['flexible']['fieldName'];
                    $next_segments[] = '{row}';
                    $next_repeaters[] = array( 'fieldKey' => $node['flexible']['fieldKey'] ?? '', 'fieldName' => $node['flexible']['fieldName'], 'kind' => 'flexible' );
                } elseif ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['repeater']['enabled'] ) && ! empty( $node['repeater']['fieldName'] ) ) {
                    $next_segments[] = $node['repeater']['fieldName'];
                    $next_segments[] = '{row}';
                    $next_repeaters[] = array(
                        'fieldKey'  => $node['repeater']['fieldKey'] ?? '',
                        'fieldName' => $node['repeater']['fieldName'],
                    );
                } elseif ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['group']['enabled'] ) && ! empty( $node['group']['fieldName'] ) ) {
                    $next_segments[] = $node['group']['fieldName'];
                }

                foreach ( $node['bindings'] ?? array() as $binding ) {
                    $has_identity = ! empty( $binding['fieldKey'] ) && ! empty( $binding['fieldName'] );
                    $active = 'scf' === ( $binding['source'] ?? 'static' );
                    if ( ! $has_identity || ( $only_scf && ! $active ) ) {
                        continue;
                    }
                    $parts = array_merge( $next_segments, array( $binding['fieldName'] ) );
                    $record = $binding;
                    $record['storageSegments'] = $parts;
                    $record['repeaterPath'] = $next_repeaters;
                    if ( empty( $next_repeaters ) ) {
                        $record['storageName'] = implode( '_', $parts );
                    } else {
                        $record['storagePattern'] = implode( '_', $parts );
                    }
                    $fields[ $binding['fieldKey'] ] = $record;
                }

                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'], $next_segments, $next_repeaters );
                }
            }
        };
        $walk( $layout['nodes'] ?? array(), array(), array() );
        return $fields;
    }

    private function collect_repeater_fields( array $layout ): array {
        $repeaters = array();
        $walk = function ( array $nodes, array $segments, array $parent_repeaters ) use ( &$walk, &$repeaters ): void {
            foreach ( $nodes as $node ) {
                if ( ! is_array( $node ) ) {
                    continue;
                }
                $next_segments = $segments;
                $next_parent_repeaters = $parent_repeaters;
                if ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['repeater']['enabled'] ) && ! empty( $node['repeater']['fieldKey'] ) && ! empty( $node['repeater']['fieldName'] ) ) {
                    $count_segments = array_merge( $segments, array( $node['repeater']['fieldName'] ) );
                    $record = $node['repeater'];
                    $record['storageSegments'] = $count_segments;
                    $record['parentRepeaters'] = $parent_repeaters;
                    $record['storagePattern'] = implode( '_', $count_segments );
                    $repeaters[ $record['fieldKey'] ] = $record;
                    $next_segments = array_merge( $count_segments, array( '{row}' ) );
                    $next_parent_repeaters = array_merge( $parent_repeaters, array( $record['fieldKey'] ) );
                } elseif ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['group']['enabled'] ) && ! empty( $node['group']['fieldName'] ) ) {
                    $next_segments[] = $node['group']['fieldName'];
                }
                if ( ! empty( $node['children'] ) ) {
                    $walk( $node['children'], $next_segments, $next_parent_repeaters );
                }
            }
        };
        $walk( $layout['nodes'] ?? array(), array(), array() );
        return $repeaters;
    }

    private function collect_flexible_fields( array $layout ): array {
        $fields = array();
        $walk = function ( array $nodes, array $segments, array $parents ) use ( &$walk, &$fields ): void {
            foreach ( $nodes as $node ) {
                if ( ! is_array( $node ) ) continue;
                $next_segments = $segments;
                $next_parents = $parents;
                if ( 'section' === ( $node['type'] ?? '' ) && ! empty( $node['flexible']['enabled'] ) && ! empty( $node['flexible']['fieldKey'] ) && ! empty( $node['flexible']['fieldName'] ) ) {
                    $count_segments = array_merge( $segments, array( $node['flexible']['fieldName'] ) );
                    $record = $node['flexible'];
                    $record['storageSegments'] = $count_segments;
                    $record['parentRepeaters'] = $parents;
                    $record['storagePattern'] = implode( '_', $count_segments );
                    $fields[ $record['fieldKey'] ] = $record;
                    $next_segments = array_merge( $count_segments, array( '{row}' ) );
                    $next_parents = array_merge( $parents, array( $record['fieldKey'] ) );
                } elseif ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['repeater']['enabled'] ) && ! empty( $node['repeater']['fieldName'] ) ) {
                    $next_segments = array_merge( $segments, array( $node['repeater']['fieldName'], '{row}' ) );
                    $next_parents = array_merge( $parents, array( $node['repeater']['fieldKey'] ?? '' ) );
                } elseif ( 'container' === ( $node['type'] ?? '' ) && ! empty( $node['group']['enabled'] ) && ! empty( $node['group']['fieldName'] ) ) {
                    $next_segments[] = $node['group']['fieldName'];
                }
                if ( ! empty( $node['children'] ) ) $walk( $node['children'], $next_segments, $next_parents );
            }
        };
        $walk( $layout['nodes'] ?? array(), array(), array() );
        return $fields;
    }

    /**
     * A newly-created stable field identity must not silently claim post meta that
     * belongs to an older/deleted field or to unrelated WordPress custom data.
     */
    private function validate_new_field_meta_conflicts( int $post_id, array $old_layout, array $new_layout ) {
        $old_fields = $this->collect_storage_fields( $old_layout, false );
        $old_active_fields = $this->collect_storage_fields( $old_layout, true );
        $new_fields = $this->collect_storage_fields( $new_layout, true );

        foreach ( $new_fields as $field_key => $binding ) {
            // A field that was already active is not a new identity; any path move
            // is preflighted by migrate_renamed_fields().
            if ( isset( $old_active_fields[ $field_key ] ) ) {
                continue;
            }

            $storage_name = $binding['storageName'] ?? '';
            if ( ! $storage_name ) {
                continue;
            }

            $reference_key = '_' . $storage_name;
            $has_value = metadata_exists( 'post', $post_id, $storage_name );
            $has_reference = metadata_exists( 'post', $post_id, $reference_key );
            $reference = $has_reference ? (string) get_post_meta( $post_id, $reference_key, true ) : '';

            // Reactivating a previously-static binding may reclaim its own stored
            // value, but never unrelated data that appeared while it was inactive.
            $was_known_identity = isset( $old_fields[ $field_key ] );
            $same_old_storage = $was_known_identity && ( $old_fields[ $field_key ]['storageName'] ?? '' ) === $storage_name;
            if ( $same_old_storage ) {
                if ( ! $has_value && ! $has_reference ) {
                    continue;
                }
                if ( $has_reference && $reference === $field_key ) {
                    continue;
                }
            }

            // A matching reference can also be left behind by an interrupted prior
            // migration and is safe to recover.
            if ( $has_reference && $reference === $field_key ) {
                continue;
            }

            if ( $has_value || $has_reference ) {
                return new WP_Error(
                    'scfvb_new_field_meta_conflict',
                    sprintf( 'Cannot create/reactivate SCF field "%s" because post meta "%s" already exists under another identity. Use another field name or clean the old field data first.', $binding['fieldName'] ?? $storage_name, $storage_name ),
                    array( 'status' => 409 )
                );
            }
        }

        $old_repeaters = $this->collect_repeater_fields( $old_layout );
        $new_repeaters = $this->collect_repeater_fields( $new_layout );
        foreach ( $new_repeaters as $field_key => $repeater ) {
            if ( isset( $old_repeaters[ $field_key ] ) || ! empty( $repeater['parentRepeaters'] ) ) {
                continue;
            }
            $storage_name = (string) ( $repeater['storagePattern'] ?? '' );
            if ( '' === $storage_name || str_contains( $storage_name, '{row}' ) ) {
                continue;
            }
            $has_value = metadata_exists( 'post', $post_id, $storage_name );
            $has_reference = metadata_exists( 'post', $post_id, '_' . $storage_name );
            $reference = $has_reference ? (string) get_post_meta( $post_id, '_' . $storage_name, true ) : '';
            if ( $has_reference && $reference === $field_key ) {
                continue;
            }
            if ( $has_value || $has_reference ) {
                return new WP_Error(
                    'scfvb_new_repeater_meta_conflict',
                    sprintf( 'Cannot create SCF Repeater "%s" because post meta "%s" already exists under another identity.', $repeater['fieldName'] ?? $storage_name, $storage_name ),
                    array( 'status' => 409 )
                );
            }
        }

        $old_flexible = $this->collect_flexible_fields( $old_layout );
        $new_flexible = $this->collect_flexible_fields( $new_layout );
        foreach ( $new_flexible as $field_key => $flexible ) {
            if ( isset( $old_flexible[ $field_key ] ) || ! empty( $flexible['parentRepeaters'] ) ) continue;
            $storage_name = (string) ( $flexible['storagePattern'] ?? '' );
            if ( '' === $storage_name || str_contains( $storage_name, '{row}' ) ) continue;
            $has_value = metadata_exists( 'post', $post_id, $storage_name );
            $has_reference = metadata_exists( 'post', $post_id, '_' . $storage_name );
            $reference = $has_reference ? (string) get_post_meta( $post_id, '_' . $storage_name, true ) : '';
            if ( $has_reference && $reference === $field_key ) continue;
            if ( $has_value || $has_reference ) {
                return new WP_Error( 'scfvb_new_flexible_meta_conflict', sprintf( 'Cannot create Flexible Content "%s" because post meta "%s" already exists under another identity.', $flexible['fieldName'] ?? $storage_name, $storage_name ), array( 'status' => 409 ) );
            }
        }

        return true;
    }

    private function collect_flexible_layout_map( array $layout ): array {
        $map = array();
        foreach ( $layout['nodes'] ?? array() as $node ) {
            if ( ! is_array( $node ) || 'section' !== ( $node['type'] ?? '' ) || empty( $node['flexible']['enabled'] ) ) continue;
            foreach ( $node['children'] ?? array() as $child ) {
                if ( ! is_array( $child ) || empty( $child['flexLayout']['key'] ) ) continue;
                $map[ $child['flexLayout']['key'] ] = array(
                    'name' => (string) ( $child['flexLayout']['name'] ?? '' ),
                    'fieldKey' => (string) ( $node['flexible']['fieldKey'] ?? '' ),
                    'fieldName' => (string) ( $node['flexible']['fieldName'] ?? '' ),
                );
            }
        }
        return $map;
    }

    private function validate_structured_boundary_changes( int $post_id, array $old_layout, array $new_layout ) {
        $old_layouts = $this->collect_flexible_layout_map( $old_layout );
        $new_layouts = $this->collect_flexible_layout_map( $new_layout );
        foreach ( $new_layouts as $layout_key => $current_layout ) {
            if ( empty( $old_layouts[ $layout_key ] ) || $old_layouts[ $layout_key ]['name'] === $current_layout['name'] ) continue;
            $old_parent = $old_layouts[ $layout_key ];
            if ( $old_parent['fieldKey'] !== $current_layout['fieldKey'] || $old_parent['fieldName'] !== $current_layout['fieldName'] ) continue;
            $count = get_post_meta( $post_id, $old_parent['fieldName'], true );
            if ( is_numeric( $count ) && (int) $count > 0 ) {
                return new WP_Error( 'scfvb_populated_flexible_layout_rename', sprintf( 'Cannot rename Flexible layout "%s" while it has stored rows. Change the layout label instead, or remove/migrate the existing rows first.', $old_parent['name'] ), array( 'status' => 409 ) );
            }
        }

        foreach ( array(
            array( 'old' => $this->collect_repeater_fields( $old_layout ), 'new' => $this->collect_repeater_fields( $new_layout ), 'kind' => 'Repeater' ),
            array( 'old' => $this->collect_flexible_fields( $old_layout ), 'new' => $this->collect_flexible_fields( $new_layout ), 'kind' => 'Flexible Content' ),
        ) as $set ) {
            foreach ( $set['new'] as $field_key => $current ) {
                if ( empty( $set['old'][ $field_key ] ) ) continue;
                $before = $set['old'][ $field_key ];
                $old_storage = (string) ( $before['storagePattern'] ?? '' );
                $new_storage = (string) ( $current['storagePattern'] ?? '' );
                if ( $old_storage === $new_storage ) continue;
                if ( '' !== $old_storage && ! str_contains( $old_storage, '{row}' ) ) {
                    $count = get_post_meta( $post_id, $old_storage, true );
                    if ( is_numeric( $count ) && (int) $count > 0 ) {
                        return new WP_Error(
                            'scfvb_populated_structured_boundary',
                            sprintf( 'Cannot move or rename populated %s "%s" automatically. Remove its rows first or migrate the structured content explicitly.', $set['kind'], $current['fieldName'] ?? $field_key ),
                            array( 'status' => 409 )
                        );
                    }
                }
            }
        }
        return true;
    }

    /**
     * Rename/move leaf metadata atomically. Moving a field into/out of a Group or
     * renaming any ancestor Group changes the leaf's physical storage name, so the
     * same migration path handles field renames and schema-aware drag/drop.
     */
    private function migrate_renamed_fields( int $post_id, array $old_layout, array $new_layout ) {
        $old_fields = $this->collect_storage_fields( $old_layout, false );
        $new_fields = $this->collect_storage_fields( $new_layout, false );
        $renames = array();

        foreach ( $new_fields as $field_key => $new_field ) {
            if ( empty( $old_fields[ $field_key ] ) ) {
                continue;
            }

            $old_pattern = $old_fields[ $field_key ]['storagePattern'] ?? '';
            $new_pattern = $new_field['storagePattern'] ?? '';
            $old_name = $old_fields[ $field_key ]['storageName'] ?? '';
            $new_name = $new_field['storageName'] ?? '';

            if ( $old_pattern || $new_pattern ) {
                $old_storage = $old_pattern ?: $old_name;
                $new_storage = $new_pattern ?: $new_name;
                if ( $old_storage === $new_storage ) {
                    continue;
                }
                if ( $this->field_has_stored_data( $post_id, $old_fields[ $field_key ] ) ) {
                    return new WP_Error(
                        'scfvb_populated_repeater_migration_required',
                        sprintf( 'Cannot move/rename populated SCF field "%s" across a Repeater/Flexible Content row boundary automatically. Preserve the current structure or migrate the structured content first.', $new_field['fieldName'] ?? $field_key ),
                        array( 'status' => 409 )
                    );
                }
                // No stored rows/value exist, so the schema can change without a
                // physical metadata migration.
                continue;
            }

            $old_name = $old_name ?: ( $old_fields[ $field_key ]['fieldName'] ?? '' );
            $new_name = $new_name ?: ( $new_field['fieldName'] ?? '' );
            if ( $old_name === $new_name ) {
                continue;
            }

            if ( strlen( $new_name ) > self::STORAGE_NAME_MAX_LENGTH ) {
                return new WP_Error(
                    'scfvb_storage_name_too_long',
                    sprintf( 'Cannot move/rename "%s" because destination meta key "%s" is too long.', $old_name, $new_name ),
                    array( 'status' => 400 )
                );
            }

            $has_old = metadata_exists( 'post', $post_id, $old_name );
            $has_new = metadata_exists( 'post', $post_id, $new_name );
            $old_reference_key = '_' . $old_name;
            $new_reference_key = '_' . $new_name;
            $has_old_reference = metadata_exists( 'post', $post_id, $old_reference_key );
            $has_new_reference = metadata_exists( 'post', $post_id, $new_reference_key );
            $old_reference = $has_old_reference ? (string) get_post_meta( $post_id, $old_reference_key, true ) : '';
            $new_reference = $has_new_reference ? (string) get_post_meta( $post_id, $new_reference_key, true ) : '';
            $old_value = $has_old ? get_post_meta( $post_id, $old_name, true ) : null;
            $new_value = $has_new ? get_post_meta( $post_id, $new_name, true ) : null;

            if ( $has_old_reference && $old_reference && $old_reference !== $field_key ) {
                return new WP_Error(
                    'scfvb_field_source_conflict',
                    sprintf( 'Cannot move/rename "%s" because its stored field reference belongs to another SCF field.', $old_name ),
                    array( 'status' => 409 )
                );
            }

            if ( $has_new && ( ! $has_new_reference || $new_reference !== $field_key ) ) {
                return new WP_Error(
                    'scfvb_field_rename_conflict',
                    sprintf( 'Cannot move/rename "%s" to "%s" because the destination meta key already contains unrelated data.', $old_name, $new_name ),
                    array( 'status' => 409 )
                );
            }

            if ( $has_new_reference && $new_reference && $new_reference !== $field_key ) {
                return new WP_Error(
                    'scfvb_field_reference_conflict',
                    sprintf( 'Cannot move/rename "%s" to "%s" because the destination field reference belongs to another SCF field.', $old_name, $new_name ),
                    array( 'status' => 409 )
                );
            }

            if ( $has_old && $has_new && $new_reference === $field_key && $old_value !== $new_value ) {
                return new WP_Error(
                    'scfvb_field_recovery_conflict',
                    sprintf( 'Cannot finish moving/renaming "%s" to "%s" because both keys contain different values.', $old_name, $new_name ),
                    array( 'status' => 409 )
                );
            }

            $renames[] = array(
                'field_key'        => $field_key,
                'old_name'         => $old_name,
                'new_name'         => $new_name,
                'has_old'          => $has_old,
                'has_new'          => $has_new,
                'old_value'        => $old_value,
                'has_old_reference'=> $has_old_reference,
                'has_new_reference'=> $has_new_reference,
            );
        }

        // Stage every destination before deleting any source. If one write fails,
        // roll back only metadata created by this attempt and leave the old schema
        // fully intact. wp_slash() is required because update_post_meta() unslashes.
        $created = array();
        foreach ( $renames as $rename ) {
            $created_value = false;
            $created_reference = false;

            if ( $rename['has_old'] && ! $rename['has_new'] ) {
                update_post_meta( $post_id, $rename['new_name'], wp_slash( $rename['old_value'] ) );
                $written = metadata_exists( 'post', $post_id, $rename['new_name'] )
                    && get_post_meta( $post_id, $rename['new_name'], true ) === $rename['old_value'];
                if ( ! $written ) {
                    $this->rollback_staged_migrations( $post_id, $created );
                    return new WP_Error( 'scfvb_field_migration_write_failed', sprintf( 'Could not safely copy SCF data to "%s". The original value was kept.', $rename['new_name'] ), array( 'status' => 500 ) );
                }
                $created_value = true;
            }

            $needs_reference = $rename['has_old'] || $rename['has_old_reference'];
            if ( $needs_reference && ! $rename['has_new_reference'] ) {
                update_post_meta( $post_id, '_' . $rename['new_name'], $rename['field_key'] );
                $written_reference = metadata_exists( 'post', $post_id, '_' . $rename['new_name'] )
                    && (string) get_post_meta( $post_id, '_' . $rename['new_name'], true ) === $rename['field_key'];
                if ( ! $written_reference ) {
                    if ( $created_value ) {
                        delete_post_meta( $post_id, $rename['new_name'] );
                    }
                    $this->rollback_staged_migrations( $post_id, $created );
                    return new WP_Error( 'scfvb_field_migration_reference_failed', sprintf( 'Could not safely write the SCF field reference for "%s". The original value was kept.', $rename['new_name'] ), array( 'status' => 500 ) );
                }
                $created_reference = true;
            }

            $created[] = array(
                'name'      => $rename['new_name'],
                'value'     => $created_value,
                'reference' => $created_reference,
            );
        }

        // Do not remove old keys yet. save_layout() first verifies that the new
        // layout JSON itself reached post meta, then finalizes source deletion.
        return array( 'renames' => $renames, 'created' => $created );
    }

    private function field_has_stored_data( int $post_id, array $field ): bool {
        $storage_name = (string) ( $field['storageName'] ?? '' );
        if ( $storage_name ) {
            return metadata_exists( 'post', $post_id, $storage_name ) || metadata_exists( 'post', $post_id, '_' . $storage_name );
        }

        $pattern = (string) ( $field['storagePattern'] ?? '' );
        if ( ! $pattern || ! str_contains( $pattern, '{row}' ) ) {
            return false;
        }
        $first_marker = strpos( $pattern, '_{row}' );
        if ( false === $first_marker ) {
            return false;
        }
        $count_key = substr( $pattern, 0, $first_marker );
        if ( ! $count_key || ! metadata_exists( 'post', $post_id, $count_key ) ) {
            return false;
        }
        return absint( get_post_meta( $post_id, $count_key, true ) ) > 0;
    }

    private function finalize_staged_migrations( int $post_id, array $renames ): void {
        foreach ( $renames as $rename ) {
            if ( ! empty( $rename['has_old'] ) ) {
                delete_post_meta( $post_id, $rename['old_name'] );
            }
            if ( ! empty( $rename['has_old_reference'] ) ) {
                delete_post_meta( $post_id, '_' . $rename['old_name'] );
            }
        }
    }

    private function rollback_staged_migrations( int $post_id, array $created ): void {
        foreach ( array_reverse( $created ) as $item ) {
            if ( ! empty( $item['reference'] ) ) {
                delete_post_meta( $post_id, '_' . $item['name'] );
            }
            if ( ! empty( $item['value'] ) ) {
                delete_post_meta( $post_id, $item['name'] );
            }
        }
    }

}
