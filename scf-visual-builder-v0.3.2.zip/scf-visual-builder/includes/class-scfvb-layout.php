<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class SCFVB_Layout {
    public const VERSION = 3;
    public const PAGE_LAYOUTS = array( 'theme', 'fullwidth', 'canvas' );
    public const BREAKPOINTS = array( 'desktop', 'laptop', 'tablet', 'mobile' );

    public static function default_layout(): array {
        return array(
            'version'  => self::VERSION,
            'settings' => array(
                // Preserve the full-width behavior introduced in 0.1.1 for existing/new pages.
                'pageLayout' => 'fullwidth',
            ),
            'nodes'    => array(),
        );
    }

    /**
     * Normalize layouts loaded from storage. This is intentionally non-destructive:
     * it upgrades the in-memory shape without rewriting post meta until the user saves.
     */
    public static function normalize( array $layout ): array {
        $source_version = isset( $layout['version'] ) ? absint( $layout['version'] ) : 1;
        $page_layout = isset( $layout['settings']['pageLayout'] ) ? sanitize_key( $layout['settings']['pageLayout'] ) : 'fullwidth';
        if ( ! in_array( $page_layout, self::PAGE_LAYOUTS, true ) ) {
            $page_layout = 'fullwidth';
        }

        $nodes = isset( $layout['nodes'] ) && is_array( $layout['nodes'] ) ? $layout['nodes'] : array();
        $nodes = array_values( array_filter( $nodes, 'is_array' ) );
        foreach ( $nodes as &$node ) {
            self::normalize_node( $node, $source_version );
        }
        unset( $node );

        return array(
            'version'  => self::VERSION,
            'settings' => array( 'pageLayout' => $page_layout ),
            'nodes'    => $nodes,
        );
    }

    public static function page_layout( array $layout ): string {
        $layout = self::normalize( $layout );
        return $layout['settings']['pageLayout'];
    }

    private static function normalize_node( &$node, int $source_version ): void {
        if ( ! is_array( $node ) ) {
            return;
        }

        $styles = isset( $node['styles'] ) && is_array( $node['styles'] ) ? $node['styles'] : array();
        $desktop = self::normalize_style_map( isset( $styles['desktop'] ) && is_array( $styles['desktop'] ) ? $styles['desktop'] : array() );
        $tablet  = self::normalize_style_map( isset( $styles['tablet'] ) && is_array( $styles['tablet'] ) ? $styles['tablet'] : array() );
        $mobile  = self::normalize_style_map( isset( $styles['mobile'] ) && is_array( $styles['mobile'] ) ? $styles['mobile'] : array() );

        // 0.1 had Desktop / Tablet / Mobile. Carry its Tablet overrides into the
        // new Laptop band as well so upgrading does not create an abrupt gap.
        if ( isset( $styles['laptop'] ) && is_array( $styles['laptop'] ) ) {
            $laptop = self::normalize_style_map( $styles['laptop'] );
        } elseif ( $source_version < 2 ) {
            $laptop = $tablet;
        } else {
            $laptop = array();
        }

        $node['styles'] = array(
            'desktop' => $desktop,
            'laptop'  => $laptop,
            'tablet'  => $tablet,
            'mobile'  => $mobile,
        );

        // v0.3.0 showed defaults for Grid and image backgrounds in the
        // Inspector even when those values had not yet been persisted. Hydrate
        // only breakpoints that explicitly enable those modes, using inherited
        // values first so responsive overrides stay sparse and predictable.
        $background_defaults = array(
            'backgroundSize'       => 'cover',
            'backgroundPosition'   => 'center center',
            'backgroundRepeat'     => 'no-repeat',
            'backgroundAttachment' => 'scroll',
        );
        $effective = array();
        foreach ( self::BREAKPOINTS as $breakpoint ) {
            $current = $node['styles'][ $breakpoint ];
            $before = $effective;

            if ( 'grid' === ( $current['display'] ?? '' ) ) {
                $current['gridTemplateColumns'] = $current['gridTemplateColumns'] ?? ( $before['gridTemplateColumns'] ?? 'repeat(2,minmax(0,1fr))' );
                $current['gridTemplateRows'] = $current['gridTemplateRows'] ?? ( $before['gridTemplateRows'] ?? 'none' );
                $current['columnGap'] = $current['columnGap'] ?? ( $before['columnGap'] ?? ( $current['gap'] ?? ( $before['gap'] ?? '16px' ) ) );
                $current['rowGap'] = $current['rowGap'] ?? ( $before['rowGap'] ?? ( $current['gap'] ?? ( $before['gap'] ?? '16px' ) ) );
                $current['gridAutoFlow'] = $current['gridAutoFlow'] ?? ( $before['gridAutoFlow'] ?? 'row' );
            }

            // An empty media ID alone is not a meaningful responsive override.
            // Explicitly clearing a background uses backgroundType=none / URL=none.
            if ( 'image' === ( $current['backgroundType'] ?? '' )
                && isset( $current['backgroundImageId'] )
                && 0 === absint( $current['backgroundImageId'] )
                && ! isset( $current['backgroundImageUrl'] ) ) {
                unset( $current['backgroundImageId'] );
            }

            $explicit_image = 'image' === ( $current['backgroundType'] ?? '' );
            if ( ! $explicit_image && isset( $current['backgroundImageUrl'] ) ) {
                $url = (string) $current['backgroundImageUrl'];
                $explicit_image = '' !== $url && 'none' !== $url;
            }
            if ( $explicit_image ) {
                $current['backgroundType'] = 'image';
                foreach ( $background_defaults as $key => $fallback ) {
                    if ( ! array_key_exists( $key, $current ) ) {
                        $current[ $key ] = $before[ $key ] ?? $fallback;
                    }
                }
            }

            $node['styles'][ $breakpoint ] = $current;
            $effective = array_merge( $effective, $current );
        }

        // Preserve pre-0.3 Image rendering: the browser default was object-fit:
        // fill. New Image nodes already explicitly use cover.
        if ( 'image' === ( $node['type'] ?? '' ) ) {
            $node['styles']['desktop']['objectFit'] = $node['styles']['desktop']['objectFit'] ?? 'fill';
            $node['styles']['desktop']['objectPosition'] = $node['styles']['desktop']['objectPosition'] ?? 'center center';
            $node['styles']['desktop']['aspectRatio'] = $node['styles']['desktop']['aspectRatio'] ?? 'auto';
        }

        if ( ! isset( $node['children'] ) || ! is_array( $node['children'] ) ) {
            $node['children'] = array();
        }
        $node['children'] = array_values( array_filter( $node['children'], 'is_array' ) );

        foreach ( $node['children'] as &$child ) {
            self::normalize_node( $child, $source_version );
        }
        unset( $child );
    }

    /**
     * Empty CSS strings mean "inherit / no override" throughout the builder.
     * Strip them during normalization so editor inheritance and frontend CSS agree.
     */
    private static function normalize_style_map( array $styles ): array {
        foreach ( $styles as $key => $value ) {
            if ( is_string( $value ) && '' === trim( $value ) ) {
                unset( $styles[ $key ] );
            }
        }
        return $styles;
    }
}
