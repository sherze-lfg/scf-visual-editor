<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_Editor {
    public function hooks(): void {
        add_action( 'admin_menu', array( $this, 'register_page' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
        add_filter( 'page_row_actions', array( $this, 'row_action' ), 10, 2 );
        add_action( 'admin_bar_menu', array( $this, 'admin_bar_action' ), 81 );
    }

    public function register_page(): void {
        add_submenu_page(
            'edit.php?post_type=page',
            'SCF Visual Builder',
            'Visual Builder',
            'edit_pages',
            'scfvb-editor',
            array( $this, 'render_page' )
        );
    }

    public function row_action( array $actions, WP_Post $post ): array {
        if ( 'page' !== $post->post_type || ! current_user_can( 'edit_post', $post->ID ) ) {
            return $actions;
        }

        $actions['scfvb'] = '<a href="' . esc_url( $this->builder_url( $post->ID ) ) . '">Edit with Visual Builder</a>';
        return $actions;
    }

    public function admin_bar_action( WP_Admin_Bar $admin_bar ): void {
        if ( is_admin() || ! is_singular( 'page' ) ) {
            return;
        }

        $post_id = get_queried_object_id();
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $admin_bar->add_node(
            array(
                'id'    => 'scfvb-edit',
                'title' => esc_html__( 'Edit with Visual Builder', 'scf-visual-builder' ),
                'href'  => $this->builder_url( $post_id ),
                'meta'  => array(
                    'class' => 'scfvb-admin-bar-edit',
                    'title' => esc_attr__( 'Edit this page with SCF Visual Builder', 'scf-visual-builder' ),
                ),
            )
        );
    }

    private function builder_url( int $post_id ): string {
        return add_query_arg(
            array(
                'post_type' => 'page',
                'page'      => 'scfvb-editor',
                'post'      => $post_id,
            ),
            admin_url( 'edit.php' )
        );
    }

    public function enqueue( string $hook ): void {
        $is_builder = isset( $_GET['page'] ) && 'scfvb-editor' === sanitize_key( wp_unslash( $_GET['page'] ) );
        if ( ! $is_builder ) {
            return;
        }

        $post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $post = get_post( $post_id );
        if ( ! $post || 'page' !== $post->post_type ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style( 'wp-components' );
        wp_enqueue_style(
            'scfvb-editor',
            SCFVB_URL . 'assets/editor.css',
            array( 'wp-components' ),
            SCFVB_VERSION
        );

        wp_enqueue_script(
            'scfvb-editor',
            SCFVB_URL . 'assets/editor.js',
            array( 'wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n' ),
            SCFVB_VERSION,
            true
        );

        wp_localize_script(
            'scfvb-editor',
            'SCFVB_CONFIG',
            array(
                'postId'       => $post_id,
                'postTitle'    => get_the_title( $post_id ),
                'restPath'     => '/scfvb/v1/pages/' . $post_id . '/layout',
                'componentsRestPath' => '/scfvb/v1/components',
                'nonce'        => wp_create_nonce( 'wp_rest' ),
                'editUrl'      => get_edit_post_link( $post_id, 'raw' ),
                'viewUrl'      => get_permalink( $post_id ),
                'pagesUrl'     => admin_url( 'edit.php?post_type=page' ),
                'scfAvailable' => function_exists( 'acf_add_local_field_group' ),
                'layoutVersion' => SCFVB_Layout::VERSION,
                'breakpoints'   => array(
                    'desktop' => array( 'label' => 'Desktop', 'min' => 1199, 'max' => 2560, 'defaultWidth' => 1920 ),
                    'laptop'  => array( 'label' => 'Laptop', 'min' => 992, 'max' => 1198, 'defaultWidth' => 1198 ),
                    'tablet'  => array( 'label' => 'Tablet', 'min' => 768, 'max' => 991, 'defaultWidth' => 991 ),
                    'mobile'  => array( 'label' => 'Mobile', 'min' => 320, 'max' => 767, 'defaultWidth' => 390 ),
                ),
            )
        );
    }

    public function render_page(): void {
        $post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;

        if ( ! $post_id ) {
            $pages = get_pages( array( 'number' => 50, 'sort_column' => 'post_title' ) );
            echo '<div class="wrap"><h1>SCF Visual Builder</h1><p>Select a page to edit.</p><ul>';
            foreach ( $pages as $page ) {
                if ( ! current_user_can( 'edit_post', $page->ID ) ) {
                    continue;
                }
                $url = $this->builder_url( $page->ID );
                echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( get_the_title( $page ) ?: '(Untitled)' ) . '</a></li>';
            }
            echo '</ul></div>';
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            wp_die( esc_html__( 'You are not allowed to edit this page.', 'scf-visual-builder' ) );
        }

        $post = get_post( $post_id );
        if ( ! $post || 'page' !== $post->post_type ) {
            wp_die( esc_html__( 'Invalid page.', 'scf-visual-builder' ) );
        }

        echo '<div class="wrap scfvb-admin-wrap"><div id="scfvb-editor-root"><p>Loading visual builder…</p></div></div>';
    }
}
