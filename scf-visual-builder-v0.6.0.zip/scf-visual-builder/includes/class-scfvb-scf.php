<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SCFVB_SCF {
    public function hooks(): void {
        add_action( 'acf/init', array( $this, 'register_fields' ) );
    }

    public function register_fields(): void {
        if ( ! function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }

        $pages = get_posts(
            array(
                'post_type'      => 'page',
                'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_key'       => '_scfvb_enabled',
                'meta_value'     => '1',
                'no_found_rows'  => true,
            )
        );

        foreach ( $pages as $post_id ) {
            $layout = $this->load_layout( (int) $post_id );
            $fields = $this->collect_level_fields( $layout['nodes'] ?? array() );
            if ( empty( $fields ) ) {
                continue;
            }

            acf_add_local_field_group(
                array(
                    'key'          => 'group_scfvb_page_' . $post_id,
                    'title'        => 'Visual Builder Content — ' . get_the_title( $post_id ),
                    'fields'       => array_values( $fields ),
                    'location'     => array(
                        array(
                            array(
                                'param'    => 'page',
                                'operator' => '==',
                                'value'    => (string) $post_id,
                            ),
                        ),
                    ),
                    'position'     => 'normal',
                    'style'        => 'default',
                    'label_placement' => 'top',
                    'instruction_placement' => 'label',
                    'active'       => true,
                    'show_in_rest' => 1,
                )
            );
        }
    }

    private function load_layout( int $post_id ): array {
        $raw = get_post_meta( $post_id, '_scfvb_layout', true );
        if ( is_string( $raw ) ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                return SCFVB_Components::instance()->resolve_layout( SCFVB_Layout::normalize( $decoded ) );
            }
        }
        return SCFVB_Layout::default_layout();
    }

    /**
     * Build one logical SCF schema level. Presentation-only containers are
     * transparent. Group and Repeater containers establish real schema boundaries.
     */
    private function collect_level_fields( array $nodes ): array {
        $fields = array();

        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) {
                continue;
            }

            $repeater = $this->active_repeater( $node );
            if ( $repeater ) {
                $sub_fields = $this->collect_level_fields( $node['children'] ?? array() );
                if ( ! empty( $sub_fields ) ) {
                    $fields[ $repeater['fieldKey'] ] = array(
                        'key'          => $repeater['fieldKey'],
                        'label'        => $repeater['label'],
                        'name'         => $repeater['fieldName'],
                        'type'         => 'repeater',
                        'layout'       => $repeater['layout'],
                        'button_label' => $repeater['buttonLabel'],
                        'min'          => $repeater['min'],
                        'max'          => $repeater['max'],
                        'sub_fields'   => array_values( $sub_fields ),
                        'required'     => 0,
                        'wrapper'      => array( 'width' => '', 'class' => '', 'id' => '' ),
                    );
                }
                continue;
            }

            $group = $this->active_group( $node );
            if ( $group ) {
                $sub_fields = $this->collect_level_fields( $node['children'] ?? array() );
                if ( ! empty( $sub_fields ) ) {
                    $fields[ $group['fieldKey'] ] = array(
                        'key'        => $group['fieldKey'],
                        'label'      => $group['label'],
                        'name'       => $group['fieldName'],
                        'type'       => 'group',
                        'layout'     => 'block',
                        'sub_fields' => array_values( $sub_fields ),
                        'required'   => 0,
                        'wrapper'    => array( 'width' => '', 'class' => '', 'id' => '' ),
                    );
                }
                continue;
            }

            foreach ( $node['bindings'] ?? array() as $binding ) {
                if ( 'scf' !== ( $binding['source'] ?? 'static' ) || empty( $binding['fieldKey'] ) || empty( $binding['fieldName'] ) ) {
                    continue;
                }

                $field = $this->field_from_binding( $binding );
                $fields[ $field['key'] ] = $field;
            }

            if ( ! empty( $node['children'] ) ) {
                foreach ( $this->collect_level_fields( $node['children'] ) as $key => $field ) {
                    $fields[ $key ] = $field;
                }
            }
        }

        return $fields;
    }

    private function active_group( array $node ): ?array {
        if ( 'container' !== ( $node['type'] ?? '' ) || empty( $node['group']['enabled'] ) || ! empty( $node['repeater']['enabled'] ) ) {
            return null;
        }

        $group = $node['group'];
        if ( empty( $group['fieldKey'] ) || empty( $group['fieldName'] ) ) {
            return null;
        }

        return array(
            'fieldKey'  => (string) $group['fieldKey'],
            'fieldName' => (string) $group['fieldName'],
            'label'     => (string) ( $group['label'] ?? ucwords( str_replace( '_', ' ', $group['fieldName'] ) ) ),
        );
    }

    private function active_repeater( array $node ): ?array {
        if ( 'container' !== ( $node['type'] ?? '' ) || empty( $node['repeater']['enabled'] ) ) {
            return null;
        }

        $repeater = $node['repeater'];
        if ( empty( $repeater['fieldKey'] ) || empty( $repeater['fieldName'] ) ) {
            return null;
        }

        $layout = (string) ( $repeater['layout'] ?? 'block' );
        if ( ! in_array( $layout, array( 'block', 'row', 'table' ), true ) ) {
            $layout = 'block';
        }

        $min = max( 0, absint( $repeater['min'] ?? 0 ) );
        $max = max( 0, absint( $repeater['max'] ?? 0 ) );
        if ( $max > 0 && $min > $max ) {
            $min = $max;
        }

        return array(
            'fieldKey'    => (string) $repeater['fieldKey'],
            'fieldName'   => (string) $repeater['fieldName'],
            'label'       => (string) ( $repeater['label'] ?? ucwords( str_replace( '_', ' ', $repeater['fieldName'] ) ) ),
            'layout'      => $layout,
            'buttonLabel' => (string) ( $repeater['buttonLabel'] ?? 'Add Row' ),
            'min'         => $min,
            'max'         => $max,
        );
    }

    private function field_from_binding( array $binding ): array {
        $field = array(
            'key'      => $binding['fieldKey'],
            'label'    => $binding['label'] ?? ucwords( str_replace( '_', ' ', $binding['fieldName'] ) ),
            'name'     => $binding['fieldName'],
            'type'     => $binding['fieldType'] ?? 'text',
            'required' => 0,
            'wrapper'  => array( 'width' => '', 'class' => '', 'id' => '' ),
        );

        if ( 'image' === $field['type'] ) {
            $field['return_format'] = 'array';
            $field['preview_size']  = 'medium';
            $field['library']       = 'all';
        } elseif ( 'textarea' === $field['type'] ) {
            $field['rows'] = 5;
            $field['new_lines'] = '';
        }

        return $field;
    }
}
