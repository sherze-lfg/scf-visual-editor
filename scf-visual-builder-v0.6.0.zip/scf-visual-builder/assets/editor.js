(function () {
    'use strict';

    const config = window.SCFVB_CONFIG || {};
    const { createElement: h, Fragment, useEffect, useMemo, useRef, useState } = wp.element;
    const { Button, Spinner, Notice } = wp.components;
    const apiFetch = wp.apiFetch;

    if (apiFetch && apiFetch.createNonceMiddleware && config.nonce) {
        apiFetch.use(apiFetch.createNonceMiddleware(config.nonce));
    }

    const CONTENT_TYPES = ['heading', 'text', 'image', 'button'];
    const CONTAINER_TYPES = ['section', 'container'];
    const BREAKPOINT_ORDER = ['desktop', 'laptop', 'tablet', 'mobile'];
    const BREAKPOINTS = config.breakpoints || {
        desktop: { label: 'Desktop', min: 1199, max: 2560, defaultWidth: 1920 },
        laptop: { label: 'Laptop', min: 992, max: 1198, defaultWidth: 1198 },
        tablet: { label: 'Tablet', min: 768, max: 991, defaultWidth: 991 },
        mobile: { label: 'Mobile', min: 320, max: 767, defaultWidth: 390 }
    };
    const LAYOUT_VERSION = Number(config.layoutVersion || 6);
    const BACKGROUND_IMAGE_DEFAULTS = {
        backgroundSize: 'cover',
        backgroundPosition: 'center center',
        backgroundRepeat: 'no-repeat',
        backgroundAttachment: 'scroll'
    };
    const GRID_DEFAULTS = {
        gridTemplateColumns: 'repeat(2,minmax(0,1fr))',
        gridTemplateRows: 'none',
        gridAutoFlow: 'row'
    };

    function token() {
        if (window.crypto && window.crypto.randomUUID) {
            return window.crypto.randomUUID().replace(/-/g, '').slice(0, 10);
        }
        return (Date.now().toString(36) + Math.random().toString(36).slice(2)).slice(0, 10);
    }

    function nodeId() { return 'node_' + token(); }
    function fieldKey() { return 'field_scfvb_' + token(); }
    function groupFieldKey() { return 'field_scfvb_group_' + token(); }
    function repeaterFieldKey() { return 'field_scfvb_repeater_' + token(); }
    function templateKey() { return 'tmpl_' + token(); }
    function componentInstanceId() { return 'cmpinst_' + token(); }
    function isLinkedComponent(node) { return !!(node && node.component && node.component.linked && node.component.id && node.component.instanceId); }

    function attachTemplateKeys(instance, template) {
        const out = clone(instance);
        function walk(item, blueprint) {
            if (!item || !blueprint) return;
            if (blueprint.templateKey) item.templateKey = blueprint.templateKey;
            const children = Array.isArray(item.children) ? item.children : [];
            const templates = Array.isArray(blueprint.children) ? blueprint.children : [];
            children.forEach((child, index) => walk(child, templates[index]));
        }
        walk(out, template);
        return out;
    }

    function instantiateComponentTemplate(component, linked) {
        const root = clone(component.template || {});
        function instantiate(item) {
            item.id = nodeId();
            if (!linked) delete item.templateKey;
            Object.keys(item.bindings || {}).forEach((key) => {
                const binding = item.bindings[key];
                if (binding && binding.source === 'scf') binding.fieldKey = fieldKey();
            });
            if (item.group && item.group.enabled) item.group.fieldKey = groupFieldKey();
            if (item.repeater && item.repeater.enabled) item.repeater.fieldKey = repeaterFieldKey();
            delete item.component;
            (item.children || []).forEach(instantiate);
        }
        instantiate(root);
        if (linked) {
            root.component = {
                id: component.id,
                linked: true,
                instanceId: componentInstanceId(),
                revision: Number(component.revision || 1)
            };
        }
        return root;
    }

    function syncComponentInstance(instance, component) {
        const template = component && component.template ? component.template : null;
        if (!template || !instance) return instance;
        const rootMeta = instance.component || {};

        function syncNode(current, blueprint) {
            const same = current && current.templateKey && blueprint.templateKey && current.templateKey === blueprint.templateKey;
            const out = clone(blueprint);
            out.id = same && current.id ? current.id : nodeId();
            out.templateKey = blueprint.templateKey || templateKey();

            const currentBindings = same && current.bindings ? current.bindings : {};
            const nextBindings = {};
            Object.keys(out.bindings || {}).forEach((key) => {
                const masterBinding = out.bindings[key] || {};
                const existing = currentBindings[key];
                if (masterBinding.source === 'scf') {
                    if (existing && existing.source === 'scf' && existing.fieldKey) {
                        nextBindings[key] = Object.assign({}, masterBinding, {
                            source: 'scf',
                            fieldKey: existing.fieldKey,
                            fieldName: existing.fieldName || masterBinding.fieldName || key
                        });
                    } else {
                        nextBindings[key] = Object.assign({}, masterBinding, { fieldKey: fieldKey() });
                    }
                } else {
                    nextBindings[key] = masterBinding;
                }
            });
            out.bindings = nextBindings;

            if (same && current.content) {
                Object.keys(nextBindings).forEach((key) => {
                    if (nextBindings[key].source !== 'scf') return;
                    if (key === 'image') {
                        if (Object.prototype.hasOwnProperty.call(current.content, 'imageId')) out.content.imageId = current.content.imageId;
                        if (Object.prototype.hasOwnProperty.call(current.content, 'imageUrl')) out.content.imageUrl = current.content.imageUrl;
                    } else if (Object.prototype.hasOwnProperty.call(current.content, key)) {
                        out.content[key] = current.content[key];
                    }
                });
            }

            if (out.group && out.group.enabled) {
                if (same && current.group && current.group.enabled && current.group.fieldKey) {
                    out.group = Object.assign({}, out.group, {
                        enabled: true,
                        fieldKey: current.group.fieldKey,
                        fieldName: current.group.fieldName || out.group.fieldName
                    });
                } else out.group.fieldKey = groupFieldKey();
            } else delete out.group;
            if (out.repeater && out.repeater.enabled) {
                if (same && current.repeater && current.repeater.enabled && current.repeater.fieldKey) {
                    out.repeater = Object.assign({}, out.repeater, {
                        enabled: true,
                        fieldKey: current.repeater.fieldKey,
                        fieldName: current.repeater.fieldName || out.repeater.fieldName
                    });
                } else out.repeater.fieldKey = repeaterFieldKey();
            } else delete out.repeater;

            const currentByKey = {};
            if (same) (current.children || []).forEach((child) => { if (child.templateKey) currentByKey[child.templateKey] = child; });
            out.children = (blueprint.children || []).map((child) => syncNode(currentByKey[child.templateKey] || null, child));
            delete out.component;
            return out;
        }

        const synced = syncNode(instance, template);
        synced.component = {
            id: component.id,
            linked: true,
            instanceId: rootMeta.instanceId || componentInstanceId(),
            revision: Number(component.revision || 1)
        };
        return synced;
    }

    function syncLinkedInstances(nodes, component) {
        return (nodes || []).map((node) => {
            if (isLinkedComponent(node) && node.component.id === component.id) return syncComponentInstance(node, component);
            const copy = clone(node);
            copy.children = syncLinkedInstances(copy.children || [], component);
            return copy;
        });
    }

    function stripComponentLinkage(node) {
        const out = clone(node);
        function walk(item) {
            delete item.component;
            delete item.templateKey;
            (item.children || []).forEach(walk);
        }
        walk(out);
        return out;
    }


    function findLinkedComponentRoot(nodes, targetId, activeRoot) {
        for (const node of nodes || []) {
            const root = isLinkedComponent(node) ? node : activeRoot;
            if (node.id === targetId) return root || null;
            const found = findLinkedComponentRoot(node.children || [], targetId, root);
            if (found) return found;
        }
        return null;
    }

    function slugify(value) {
        const slug = String(value || '')
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '');
        const bounded = (slug || 'field').slice(0, 64).replace(/_+$/g, '');
        return bounded || 'field';
    }

    function fieldNameWithSuffix(value, suffix) {
        const cleanSuffix = String(suffix || '').replace(/[^a-z0-9_]+/g, '_');
        const base = slugify(value || 'field');
        const room = Math.max(1, 64 - cleanSuffix.length);
        return (base.slice(0, room).replace(/_+$/g, '') || 'field') + cleanSuffix;
    }

    function clone(value) { return JSON.parse(JSON.stringify(value)); }

    function emptyStyles() {
        return { desktop: {}, laptop: {}, tablet: {}, mobile: {} };
    }

    function normalizeStyleMap(input) {
        const out = Object.assign({}, input && typeof input === 'object' ? input : {});
        Object.keys(out).forEach((key) => {
            if (typeof out[key] === 'string' && out[key].trim() === '') delete out[key];
        });
        return out;
    }

    function baseStyles(type) {
        const styles = emptyStyles();
        if (type === 'section') {
            styles.desktop = {
                display: 'flex', width: '100%', minHeight: '300px',
                paddingTop: '48px', paddingRight: '24px', paddingBottom: '48px', paddingLeft: '24px',
                flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'stretch', gap: '16px',
                backgroundType: 'color', backgroundColor: '#ffffff',
                backgroundSize: 'cover', backgroundPosition: 'center center', backgroundRepeat: 'no-repeat', backgroundAttachment: 'scroll',
                overflow: 'visible', position: 'static'
            };
        } else if (type === 'container') {
            styles.desktop = {
                display: 'flex', width: '100%', flexDirection: 'column',
                justifyContent: 'flex-start', alignItems: 'stretch', gap: '16px',
                backgroundType: 'none',
                backgroundSize: 'cover', backgroundPosition: 'center center', backgroundRepeat: 'no-repeat', backgroundAttachment: 'scroll',
                overflow: 'visible', position: 'static'
            };
        } else if (type === 'heading') {
            styles.desktop = {
                width: 'auto', marginTop: '0px', marginBottom: '8px',
                color: '#111111', fontSize: '48px', fontWeight: '700', textAlign: 'left', position: 'static'
            };
        } else if (type === 'text') {
            styles.desktop = {
                width: 'auto', marginTop: '0px', marginBottom: '8px',
                color: '#333333', fontSize: '18px', fontWeight: '400', textAlign: 'left', position: 'static'
            };
        } else if (type === 'image') {
            styles.desktop = { width: '100%', borderWidth: '0px', borderColor: '#dddddd', borderRadius: '0px', objectFit: 'cover', objectPosition: 'center center', aspectRatio: 'auto', position: 'static' };
        } else if (type === 'button') {
            styles.desktop = {
                display: 'inline-block', width: 'auto',
                paddingTop: '12px', paddingRight: '20px', paddingBottom: '12px', paddingLeft: '20px',
                backgroundColor: '#111111', color: '#ffffff', fontSize: '16px', fontWeight: '600',
                borderWidth: '0px', borderColor: '#111111', borderRadius: '4px', textAlign: 'center', position: 'static'
            };
        }
        return styles;
    }

    function newNode(type) {
        const common = {
            id: nodeId(),
            type,
            name: type.charAt(0).toUpperCase() + type.slice(1),
            settings: {}, content: {}, bindings: {}, styles: baseStyles(type), children: []
        };

        if (type === 'heading') {
            common.settings.tag = 'h2';
            common.content.text = 'Your heading';
            common.bindings.text = { source: 'static', fieldType: 'text' };
        } else if (type === 'text') {
            common.content.text = 'Add your text here.';
            common.bindings.text = { source: 'static', fieldType: 'textarea' };
        } else if (type === 'image') {
            common.content.imageId = 0;
            common.content.imageUrl = '';
            common.bindings.image = { source: 'static', fieldType: 'image' };
        } else if (type === 'button') {
            common.content.label = 'Button';
            common.content.url = '#';
            common.bindings.label = { source: 'static', fieldType: 'text' };
            common.bindings.url = { source: 'static', fieldType: 'url' };
        }
        return common;
    }

    function normalizeLayout(raw) {
        const source = raw && typeof raw === 'object' ? clone(raw) : {};
        const sourceVersion = Number(source.version || 1);
        const layout = {
            version: LAYOUT_VERSION,
            settings: { pageLayout: (source.settings && source.settings.pageLayout) || 'fullwidth' },
            nodes: Array.isArray(source.nodes) ? source.nodes : []
        };
        if (!['theme', 'fullwidth', 'canvas'].includes(layout.settings.pageLayout)) {
            layout.settings.pageLayout = 'fullwidth';
        }

        function walk(node) {
            const styles = node.styles && typeof node.styles === 'object' ? node.styles : {};
            const oldTablet = styles.tablet && typeof styles.tablet === 'object' ? styles.tablet : {};
            node.styles = {
                desktop: normalizeStyleMap(styles.desktop),
                laptop: styles.laptop && typeof styles.laptop === 'object'
                    ? normalizeStyleMap(styles.laptop)
                    : (sourceVersion < 2 ? normalizeStyleMap(clone(oldTablet)) : {}),
                tablet: normalizeStyleMap(oldTablet),
                mobile: normalizeStyleMap(styles.mobile)
            };

            // v0.3.0 exposed friendly defaults in the Inspector without always
            // persisting them. Hydrate only breakpoints that explicitly turn on
            // Grid or an image background so canvas and frontend CSS agree.
            let inherited = {};
            BREAKPOINT_ORDER.forEach((name) => {
                const current = node.styles[name] || {};
                const before = Object.assign({}, inherited);

                if (current.display === 'grid') {
                    if (current.gridTemplateColumns === undefined) current.gridTemplateColumns = before.gridTemplateColumns || GRID_DEFAULTS.gridTemplateColumns;
                    if (current.gridTemplateRows === undefined) current.gridTemplateRows = before.gridTemplateRows || GRID_DEFAULTS.gridTemplateRows;
                    if (current.columnGap === undefined) current.columnGap = before.columnGap || current.gap || before.gap || '16px';
                    if (current.rowGap === undefined) current.rowGap = before.rowGap || current.gap || before.gap || '16px';
                    if (current.gridAutoFlow === undefined) current.gridAutoFlow = before.gridAutoFlow || GRID_DEFAULTS.gridAutoFlow;
                }

                if (current.backgroundType === 'image' && Number(current.backgroundImageId || 0) === 0 && current.backgroundImageUrl === undefined) {
                    delete current.backgroundImageId;
                }

                const explicitImage = current.backgroundType === 'image' ||
                    (typeof current.backgroundImageUrl === 'string' && current.backgroundImageUrl !== '' && current.backgroundImageUrl !== 'none');
                if (explicitImage) {
                    if (current.backgroundType === undefined) current.backgroundType = 'image';
                    Object.keys(BACKGROUND_IMAGE_DEFAULTS).forEach((key) => {
                        if (current[key] === undefined) current[key] = before[key] !== undefined ? before[key] : BACKGROUND_IMAGE_DEFAULTS[key];
                    });
                }

                inherited = Object.assign(inherited, current);
            });

            // Older Image nodes used the browser's default object-fit (fill).
            // Keep that rendering stable while all newly-created 0.3+ images
            // explicitly default to cover.
            if (node.type === 'image') {
                const desktop = node.styles.desktop;
                if (desktop.objectFit === undefined) desktop.objectFit = 'fill';
                if (desktop.objectPosition === undefined) desktop.objectPosition = 'center center';
                if (desktop.aspectRatio === undefined) desktop.aspectRatio = 'auto';
            }

            // Structured containers are opt-in and mutually exclusive.
            if (node.type === 'container' && node.repeater && node.repeater.enabled && node.repeater.fieldKey && node.repeater.fieldName) {
                const min = Math.max(0, Math.min(100, parseInt(node.repeater.min || 0, 10) || 0));
                const max = Math.max(0, Math.min(100, parseInt(node.repeater.max || 0, 10) || 0));
                node.repeater = {
                    enabled: true,
                    fieldKey: String(node.repeater.fieldKey),
                    fieldName: slugify(node.repeater.fieldName),
                    label: String(node.repeater.label || node.repeater.fieldName || node.name || 'Repeater'),
                    layout: ['block', 'row', 'table'].includes(node.repeater.layout) ? node.repeater.layout : 'block',
                    buttonLabel: String(node.repeater.buttonLabel || 'Add Row'),
                    min: max > 0 ? Math.min(min, max) : min,
                    max
                };
                delete node.group;
            } else {
                delete node.repeater;
                if (node.type === 'container' && node.group && node.group.enabled && node.group.fieldKey && node.group.fieldName) {
                    node.group = {
                        enabled: true,
                        fieldKey: String(node.group.fieldKey),
                        fieldName: slugify(node.group.fieldName),
                        label: String(node.group.label || node.group.fieldName || node.name || 'Group')
                    };
                } else {
                    delete node.group;
                }
            }

            node.children = Array.isArray(node.children) ? node.children : [];
            node.children.forEach(walk);
        }
        layout.nodes.forEach(walk);
        return layout;
    }

    function findNode(nodes, id) {
        for (const node of nodes || []) {
            if (node.id === id) return node;
            const child = findNode(node.children || [], id);
            if (child) return child;
        }
        return null;
    }

    function findLocation(nodes, id, parentIdValue) {
        for (let i = 0; i < (nodes || []).length; i++) {
            const node = nodes[i];
            if (node.id === id) return { parentId: parentIdValue || null, index: i };
            const child = findLocation(node.children || [], id, node.id);
            if (child) return child;
        }
        return null;
    }

    function updateNode(nodes, id, updater) {
        return (nodes || []).map((node) => {
            if (node.id === id) return updater(clone(node));
            if (node.children && node.children.length) {
                return Object.assign({}, node, { children: updateNode(node.children, id, updater) });
            }
            return node;
        });
    }

    function removeNode(nodes, id) {
        let removed = null;
        const next = [];
        for (const node of nodes || []) {
            if (node.id === id) {
                removed = node;
                continue;
            }
            if (node.children && node.children.length) {
                const result = removeNode(node.children, id);
                if (result.removed) {
                    removed = result.removed;
                    next.push(Object.assign({}, node, { children: result.nodes }));
                    continue;
                }
            }
            next.push(node);
        }
        return { nodes: next, removed };
    }

    function insertAt(nodes, parentIdValue, index, child) {
        if (!parentIdValue) {
            const copy = [...nodes];
            const safeIndex = Math.max(0, Math.min(Number(index), copy.length));
            copy.splice(safeIndex, 0, child);
            return copy;
        }
        return updateNode(nodes, parentIdValue, (node) => {
            const children = [...(node.children || [])];
            const safeIndex = Math.max(0, Math.min(Number(index), children.length));
            children.splice(safeIndex, 0, child);
            node.children = children;
            return node;
        });
    }

    function isDescendant(node, id) {
        for (const child of node.children || []) {
            if (child.id === id || isDescendant(child, id)) return true;
        }
        return false;
    }

    function canContain(parentType, childType) {
        if (!parentType) return childType === 'section';
        if (parentType === 'section') return childType === 'container';
        if (parentType === 'container') return childType === 'container' || CONTENT_TYPES.includes(childType);
        return false;
    }

    function moveSibling(nodes, id, delta) {
        const copy = clone(nodes);
        function walk(list) {
            const index = list.findIndex((n) => n.id === id);
            if (index >= 0) {
                const target = index + delta;
                if (target >= 0 && target < list.length) {
                    const temp = list[index];
                    list[index] = list[target];
                    list[target] = temp;
                }
                return true;
            }
            for (const node of list) {
                if (walk(node.children || [])) return true;
            }
            return false;
        }
        walk(copy);
        return copy;
    }

    function duplicateNodeTree(node) {
        const copy = clone(node);
        const linkedRoot = isLinkedComponent(copy);
        const newInstanceId = linkedRoot ? componentInstanceId() : null;
        function remap(item) {
            item.id = nodeId();
            item.name = item.name + ' Copy';
            if (!linkedRoot) delete item.templateKey;
            Object.keys(item.bindings || {}).forEach((key) => {
                const binding = item.bindings[key];
                if (binding.fieldKey) binding.fieldKey = fieldKey();
                if (binding.fieldName) binding.fieldName = fieldNameWithSuffix(binding.fieldName, '_copy_' + token().slice(0, 4));
            });
            if (item.group && item.group.enabled) {
                item.group.fieldKey = groupFieldKey();
                item.group.fieldName = fieldNameWithSuffix(item.group.fieldName || item.name, '_copy_' + token().slice(0, 4));
                item.group.label = (item.group.label || item.name || 'Group') + ' Copy';
            }
            if (item.repeater && item.repeater.enabled) {
                item.repeater.fieldKey = repeaterFieldKey();
                item.repeater.fieldName = fieldNameWithSuffix(item.repeater.fieldName || item.name, '_copy_' + token().slice(0, 4));
                item.repeater.label = (item.repeater.label || item.name || 'Repeater') + ' Copy';
            }
            delete item.component;
            (item.children || []).forEach(remap);
        }
        remap(copy);
        if (linkedRoot) {
            copy.component = Object.assign({}, node.component, { instanceId: newInstanceId });
        }
        return copy;
    }

    function effectiveStyles(node, breakpoint) {
        const orderIndex = BREAKPOINT_ORDER.indexOf(breakpoint);
        const out = {};
        BREAKPOINT_ORDER.slice(0, Math.max(0, orderIndex) + 1).forEach((name) => {
            Object.assign(out, (node.styles && node.styles[name]) || {});
        });
        return out;
    }

    function toReactStyle(styles) {
        const style = Object.assign({}, styles || {});
        const backgroundType = style.backgroundType;
        const backgroundImageUrl = style.backgroundImageUrl;

        delete style.backgroundType;
        delete style.backgroundImageId;
        delete style.backgroundImageUrl;

        if (backgroundType === 'none') {
            style.backgroundImage = 'none';
            style.backgroundColor = 'transparent';
        } else if (backgroundType === 'color') {
            style.backgroundImage = 'none';
        } else if (backgroundType === 'image') {
            style.backgroundImage = backgroundImageUrl && backgroundImageUrl !== 'none'
                ? 'url(' + JSON.stringify(String(backgroundImageUrl)) + ')'
                : 'none';
            Object.keys(BACKGROUND_IMAGE_DEFAULTS).forEach((key) => {
                if (!style[key]) style[key] = BACKGROUND_IMAGE_DEFAULTS[key];
            });
        } else if (backgroundImageUrl) {
            style.backgroundImage = backgroundImageUrl === 'none'
                ? 'none'
                : 'url(' + JSON.stringify(String(backgroundImageUrl)) + ')';
        }

        if (style.borderWidth && style.borderWidth !== '0' && style.borderWidth !== '0px') {
            style.borderStyle = 'solid';
        }
        return style;
    }

    function pxNumber(value, fallback) {
        const match = String(value || '').trim().match(/^(-?\d+(?:\.\d+)?)px$/);
        return match ? Number(match[1]) : Number(fallback || 0);
    }

    function clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }

    function useHistoryState(initialValue) {
        const [history, setHistory] = useState({ past: [], present: initialValue, future: [] });

        function reset(value) { setHistory({ past: [], present: value, future: [] }); }
        function commit(valueOrFn) {
            setHistory((current) => {
                const next = typeof valueOrFn === 'function' ? valueOrFn(current.present) : valueOrFn;
                if (next === current.present || JSON.stringify(next) === JSON.stringify(current.present)) return current;
                return { past: [...current.past, current.present].slice(-60), present: next, future: [] };
            });
        }
        function replace(valueOrFn) {
            setHistory((current) => {
                const next = typeof valueOrFn === 'function' ? valueOrFn(current.present) : valueOrFn;
                return Object.assign({}, current, { present: next, future: [] });
            });
        }
        function checkpoint(base) {
            setHistory((current) => {
                if (!base || JSON.stringify(base) === JSON.stringify(current.present)) return current;
                return { past: [...current.past, base].slice(-60), present: current.present, future: [] };
            });
        }
        function undo() {
            setHistory((current) => {
                if (!current.past.length) return current;
                const previous = current.past[current.past.length - 1];
                return { past: current.past.slice(0, -1), present: previous, future: [current.present, ...current.future] };
            });
        }
        function redo() {
            setHistory((current) => {
                if (!current.future.length) return current;
                const next = current.future[0];
                return { past: [...current.past, current.present].slice(-60), present: next, future: current.future.slice(1) };
            });
        }
        return { history, reset, commit, replace, checkpoint, undo, redo };
    }

    function LabeledInput(props) {
        return h('label', { className: 'scfvb-field' },
            h('span', null, props.label),
            h('input', {
                type: props.type || 'text', value: props.value == null ? '' : props.value,
                min: props.min, max: props.max, step: props.step,
                placeholder: props.placeholder || '',
                onChange: (event) => props.onChange(event.target.value)
            })
        );
    }

    function LabeledSelect(props) {
        return h('label', { className: 'scfvb-field' },
            h('span', null, props.label),
            h('select', { value: props.value, onChange: (event) => props.onChange(event.target.value) },
                props.options.map((option) => {
                    const value = typeof option === 'string' ? option : option.value;
                    const label = typeof option === 'string' ? option : option.label;
                    return h('option', { key: value, value }, label);
                })
            )
        );
    }

    function SectionTitle(props) {
        return h('div', { className: 'scfvb-inspector-title-row' },
            h('h3', { className: 'scfvb-inspector-title' }, props.children),
            props.action || null
        );
    }

    function App() {
        const initial = normalizeLayout({ version: LAYOUT_VERSION, settings: { pageLayout: 'fullwidth' }, nodes: [] });
        const { history, reset, commit, replace, checkpoint, undo, redo } = useHistoryState(initial);
        const [selectedId, setSelectedId] = useState(null);
        const [breakpoint, setBreakpoint] = useState('desktop');
        const [previewWidths, setPreviewWidths] = useState(() => {
            const result = {};
            BREAKPOINT_ORDER.forEach((key) => { result[key] = Number(BREAKPOINTS[key].defaultWidth); });
            return result;
        });
        const [loading, setLoading] = useState(true);
        const [saving, setSaving] = useState(false);
        const [notice, setNotice] = useState(null);
        const [savedSnapshot, setSavedSnapshot] = useState(JSON.stringify(initial));
        const [dragging, setDragging] = useState(null);
        const [components, setComponents] = useState([]);
        const [componentsLoading, setComponentsLoading] = useState(false);
        const gestureBase = useRef(null);

        const layout = history.present;
        const latestLayoutRef = useRef(layout);
        const selected = useMemo(() => selectedId ? findNode(layout.nodes, selectedId) : null, [layout, selectedId]);
        const selectedComponentRoot = useMemo(() => selectedId ? findLinkedComponentRoot(layout.nodes, selectedId, null) : null, [layout, selectedId]);
        const dirty = JSON.stringify(layout) !== savedSnapshot;
        const previewWidth = previewWidths[breakpoint];

        useEffect(() => {
            latestLayoutRef.current = layout;
        }, [layout]);

        useEffect(() => {
            apiFetch({ path: config.restPath }).then((response) => {
                const loaded = normalizeLayout(response && response.layout ? response.layout : initial);
                reset(loaded);
                setSavedSnapshot(JSON.stringify(loaded));
                setLoading(false);
            }).catch((error) => {
                setNotice({ status: 'error', message: error.message || 'Could not load the layout.' });
                setLoading(false);
            });
        }, []);


        function refreshComponents() {
            if (!config.componentsRestPath) return Promise.resolve([]);
            setComponentsLoading(true);
            return apiFetch({ path: config.componentsRestPath }).then((response) => {
                const list = response && Array.isArray(response.components) ? response.components : [];
                setComponents(list);
                setComponentsLoading(false);
                return list;
            }).catch((error) => {
                setComponentsLoading(false);
                setNotice({ status: 'warning', message: error.message || 'Could not load the component library.' });
                return [];
            });
        }

        useEffect(() => { refreshComponents(); }, []);

        useEffect(() => {
            function keydown(event) {
                const activeTag = document.activeElement && document.activeElement.tagName;
                if (['INPUT', 'TEXTAREA', 'SELECT'].includes(activeTag)) return;
                const meta = event.ctrlKey || event.metaKey;
                const key = event.key.toLowerCase();
                if (meta && key === 'z') {
                    event.preventDefault();
                    if (event.shiftKey) redo(); else undo();
                } else if (meta && key === 'y') {
                    event.preventDefault();
                    redo();
                } else if ((event.key === 'Delete' || event.key === 'Backspace') && selectedId) {
                    event.preventDefault();
                    deleteNode(selectedId);
                }
            }
            window.addEventListener('keydown', keydown);
            return () => window.removeEventListener('keydown', keydown);
        });

        useEffect(() => {
            if (selectedId && !findNode(layout.nodes, selectedId)) setSelectedId(null);
        }, [layout, selectedId]);

        useEffect(() => {
            function beforeUnload(event) {
                if (!dirty) return;
                event.preventDefault();
                event.returnValue = '';
            }
            window.addEventListener('beforeunload', beforeUnload);
            return () => window.removeEventListener('beforeunload', beforeUnload);
        }, [dirty]);

        function showMessage(message, status) { setNotice({ message, status: status || 'info' }); }

        function updateNodeById(id, updater, transient) {
            const fn = transient ? replace : commit;
            fn((current) => Object.assign({}, current, { nodes: updateNode(current.nodes, id, updater) }));
        }

        function updateSelected(updater) {
            if (selectedId) updateNodeById(selectedId, updater, false);
        }

        function patchStyleById(id, key, value, transient) {
            updateNodeById(id, (copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                const next = Object.assign({}, copy.styles[breakpoint] || {});
                if (typeof value === 'string' && value.trim() === '') delete next[key];
                else next[key] = value;
                copy.styles[breakpoint] = next;
                return copy;
            }, transient);
        }

        function beginGesture() {
            if (!gestureBase.current) gestureBase.current = clone(history.present);
        }

        function endGesture() {
            const base = gestureBase.current;
            gestureBase.current = null;
            checkpoint(base);
        }

        function parentType(parentIdValue) {
            if (!parentIdValue) return null;
            const parent = findNode(layout.nodes, parentIdValue);
            return parent ? parent.type : null;
        }

        function addAt(type, parentIdValue, index) {
            if (!canContain(parentType(parentIdValue), type)) {
                showMessage('That element cannot be placed there.', 'warning');
                return;
            }
            const child = newNode(type);
            commit((current) => Object.assign({}, current, { nodes: insertAt(current.nodes, parentIdValue, index, child) }));
            setSelectedId(child.id);
        }

        function addElement(type) {
            if (type === 'section') {
                addAt(type, null, layout.nodes.length);
                return;
            }
            if (!selected) {
                showMessage(type === 'container' ? 'Select a Section or Container first.' : 'Select a Container first.', 'warning');
                return;
            }
            if (!canContain(selected.type, type)) {
                showMessage(type === 'container' ? 'Containers can be placed inside Sections or Containers.' : 'Content elements must be placed inside a Container.', 'warning');
                return;
            }
            addAt(type, selected.id, (selected.children || []).length);
        }

        function moveNodeTo(id, targetParentId, targetIndex) {
            const dragged = findNode(layout.nodes, id);
            if (!dragged) return;
            const targetParent = targetParentId ? findNode(layout.nodes, targetParentId) : null;
            if (targetParent && (targetParent.id === id || isDescendant(dragged, targetParent.id))) {
                showMessage('An element cannot be moved inside itself.', 'warning');
                return;
            }
            if (!canContain(targetParent ? targetParent.type : null, dragged.type)) {
                showMessage('That element cannot be placed there.', 'warning');
                return;
            }

            const oldLocation = findLocation(layout.nodes, id, null);
            let adjustedIndex = Number(targetIndex);
            if (oldLocation && oldLocation.parentId === targetParentId && oldLocation.index < adjustedIndex) adjustedIndex -= 1;

            commit((current) => {
                const result = removeNode(current.nodes, id);
                if (!result.removed) return current;
                return Object.assign({}, current, { nodes: insertAt(result.nodes, targetParentId, adjustedIndex, result.removed) });
            });
            setSelectedId(id);
        }

        function deleteNode(id) {
            if (!findNode(layout.nodes, id)) return;
            commit((current) => Object.assign({}, current, { nodes: removeNode(current.nodes, id).nodes }));
            if (selectedId === id) setSelectedId(null);
        }

        function duplicateNode(id) {
            const node = findNode(layout.nodes, id);
            const location = findLocation(layout.nodes, id, null);
            if (!node || !location) return;
            const copy = duplicateNodeTree(node);
            commit((current) => Object.assign({}, current, {
                nodes: insertAt(current.nodes, location.parentId, location.index + 1, copy)
            }));
            setSelectedId(copy.id);
        }

        function moveNodeSibling(id, delta) {
            if (!findNode(layout.nodes, id)) return;
            commit((current) => Object.assign({}, current, { nodes: moveSibling(current.nodes, id, delta) }));
        }

        function renameNode(id, name) {
            updateNodeById(id, (copy) => { copy.name = String(name || '').trim() || copy.type; return copy; }, false);
        }

        function toggleGroupById(id) {
            updateNodeById(id, (copy) => {
                if (copy.type !== 'container') return copy;
                if (copy.group && copy.group.enabled) {
                    delete copy.group;
                } else {
                    const label = String(copy.name || 'Group').trim() || 'Group';
                    delete copy.repeater;
                    copy.group = { enabled: true, fieldKey: groupFieldKey(), fieldName: slugify(label), label };
                }
                return copy;
            }, false);
        }

        function toggleRepeaterById(id) {
            updateNodeById(id, (copy) => {
                if (copy.type !== 'container') return copy;
                if (copy.repeater && copy.repeater.enabled) {
                    delete copy.repeater;
                } else {
                    const label = String(copy.name || 'Repeater').trim() || 'Repeater';
                    delete copy.group;
                    copy.repeater = { enabled: true, fieldKey: repeaterFieldKey(), fieldName: slugify(label), label, layout: 'block', buttonLabel: 'Add Row', min: 0, max: 0 };
                }
                return copy;
            }, false);
        }

        function handleDrop(event, targetParentId, targetIndex) {
            event.preventDefault();
            event.stopPropagation();
            let newType = event.dataTransfer.getData('application/x-scfvb-new') || '';
            let existingId = event.dataTransfer.getData('application/x-scfvb-node') || '';
            if (!newType && !existingId && dragging) {
                if (dragging.kind === 'new') newType = dragging.type;
                if (dragging.kind === 'node') existingId = dragging.id;
            }
            if (newType) addAt(newType, targetParentId, targetIndex);
            else if (existingId) moveNodeTo(existingId, targetParentId, targetIndex);
            setDragging(null);
        }

        function currentDragType() {
            if (!dragging) return '';
            if (dragging.kind === 'new') return dragging.type;
            const node = findNode(layout.nodes, dragging.id);
            return node ? node.type : '';
        }

        function canDropOn(parentIdValue) {
            if (!canContain(parentType(parentIdValue), currentDragType())) return false;
            if (dragging && dragging.kind === 'node') {
                const dragged = findNode(layout.nodes, dragging.id);
                const targetParent = parentIdValue ? findNode(layout.nodes, parentIdValue) : null;
                if (!dragged) return false;
                if (targetParent && (targetParent.id === dragged.id || isDescendant(dragged, targetParent.id))) return false;
            }
            return true;
        }

        function insertComponent(component, linked) {
            if (!component || !component.template) return;
            const root = instantiateComponentTemplate(component, !!linked);
            if (root.type === 'section') {
                commit((current) => Object.assign({}, current, { nodes: insertAt(current.nodes, null, current.nodes.length, root) }));
                setSelectedId(root.id);
                return;
            }
            if (root.type !== 'container') {
                showMessage('Only Section and Container components can be inserted.', 'warning');
                return;
            }
            if (!selected || !canContain(selected.type, 'container')) {
                showMessage('Select a Section or Container before inserting a Container component.', 'warning');
                return;
            }
            commit((current) => Object.assign({}, current, { nodes: insertAt(current.nodes, selected.id, (selected.children || []).length, root) }));
            setSelectedId(root.id);
        }

        function saveSelectedAsComponent() {
            if (!selected || !['section', 'container'].includes(selected.type)) {
                showMessage('Select a Section or Container to save as a component.', 'warning');
                return;
            }
            const name = window.prompt('Component name', selected.name || 'Component');
            if (name === null) return;
            apiFetch({ path: config.componentsRestPath, method: 'POST', data: { name, node: clone(selected) } }).then((response) => {
                const component = response && response.component;
                if (!component) throw new Error('The component was not returned by WordPress.');
                setComponents((current) => current.concat([component]).sort((a, b) => String(a.name).localeCompare(String(b.name))));
                const instanceId = componentInstanceId();
                updateNodeById(selected.id, (copy) => {
                    const linked = attachTemplateKeys(copy, component.template);
                    linked.component = { id: component.id, linked: true, instanceId, revision: Number(component.revision || 1) };
                    return linked;
                }, false);
                showMessage('Component saved and the selected element is now linked.', 'success');
            }).catch((error) => showMessage(error.message || 'Could not save the component.', 'error'));
        }

        function updateSelectedComponent() {
            const componentRoot = selectedComponentRoot;
            if (!componentRoot || !isLinkedComponent(componentRoot)) {
                showMessage('Select an element inside a linked component first.', 'warning');
                return;
            }
            const existing = components.find((item) => item.id === componentRoot.component.id);
            const name = window.prompt('Component name', existing ? existing.name : componentRoot.name || 'Component');
            if (name === null) return;
            apiFetch({ path: config.componentsRestPath + '/' + componentRoot.component.id, method: 'PUT', data: { name, node: clone(componentRoot) } }).then((response) => {
                const component = response && response.component;
                if (!component) throw new Error('The updated component was not returned by WordPress.');
                setComponents((current) => current.map((item) => item.id === component.id ? component : item).sort((a, b) => String(a.name).localeCompare(String(b.name))));
                commit((current) => {
                    let nodes = updateNode(current.nodes, componentRoot.id, (copy) => attachTemplateKeys(copy, component.template));
                    nodes = syncLinkedInstances(nodes, component);
                    return Object.assign({}, current, { nodes });
                });
                showMessage('Component updated. Linked instances on this page were synchronized.', 'success');
            }).catch((error) => showMessage(error.message || 'Could not update the component.', 'error'));
        }

        function detachSelectedComponent() {
            const componentRoot = selectedComponentRoot;
            if (!componentRoot || !isLinkedComponent(componentRoot)) return;
            updateNodeById(componentRoot.id, (copy) => stripComponentLinkage(copy), false);
            showMessage('Component detached. It will no longer follow library updates.', 'success');
        }

        function deleteLibraryComponent(component) {
            if (!component) return;
            if (!window.confirm('Delete "' + component.name + '" from the component library? Existing linked page instances keep their last saved snapshot.')) return;
            apiFetch({ path: config.componentsRestPath + '/' + component.id, method: 'DELETE' }).then(() => {
                setComponents((current) => current.filter((item) => item.id !== component.id));
                showMessage('Component removed from the library. Existing page instances were not deleted.', 'success');
            }).catch((error) => showMessage(error.message || 'Could not delete the component.', 'error'));
        }

        function save() {
            const submittedLayout = clone(layout);
            const submittedSnapshot = JSON.stringify(submittedLayout);
            setSaving(true);
            setNotice(null);
            apiFetch({ path: config.restPath, method: 'PUT', data: { layout: submittedLayout } }).then((response) => {
                const saved = normalizeLayout(response && response.layout ? response.layout : submittedLayout);
                const serverSnapshot = JSON.stringify(saved);
                const hasNewerLocalChanges = JSON.stringify(latestLayoutRef.current) !== submittedSnapshot;

                // Do not overwrite edits made while the request was in flight. The
                // server snapshot still becomes the dirty-state baseline.
                if (!hasNewerLocalChanges) reset(saved);
                setSavedSnapshot(serverSnapshot);
                setSaving(false);
                const autoRenamed = response && Array.isArray(response.autoRenamed) ? response.autoRenamed : [];
                let successMessage = hasNewerLocalChanges ? 'Saved. Newer local changes are still unsaved.' : 'Layout saved.';
                if (autoRenamed.length) {
                    const renameMessage = autoRenamed.length === 1
                        ? '1 duplicate SCF name was automatically renamed.'
                        : `${autoRenamed.length} duplicate SCF names were automatically renamed.`;
                    successMessage = hasNewerLocalChanges
                        ? `${renameMessage} Newer local changes are still unsaved.`
                        : `${successMessage} ${renameMessage}`;
                }
                setNotice({ status: 'success', message: successMessage });
            }).catch((error) => {
                setSaving(false);
                setNotice({ status: 'error', message: error.message || 'Could not save the layout.' });
            });
        }

        function setPageLayout(value) {
            commit((current) => Object.assign({}, current, {
                settings: Object.assign({}, current.settings || {}, { pageLayout: value })
            }));
        }

        function updatePreviewWidth(value) {
            const meta = BREAKPOINTS[breakpoint];
            const number = clamp(parseInt(value || meta.defaultWidth, 10), Number(meta.min), Number(meta.max));
            setPreviewWidths((current) => Object.assign({}, current, { [breakpoint]: number }));
        }

        if (loading) return h('div', { className: 'scfvb-loading' }, h(Spinner), 'Loading visual builder…');

        return h('div', { className: 'scfvb-app' },
            h(Toolbar, {
                breakpoint, setBreakpoint, previewWidth, updatePreviewWidth,
                pageLayout: (layout.settings && layout.settings.pageLayout) || 'fullwidth', setPageLayout,
                canUndo: history.past.length > 0, canRedo: history.future.length > 0, undo, redo,
                save, saving, dirty
            }),
            notice && h('div', { className: 'scfvb-notice-wrap' },
                h(Notice, { status: notice.status, isDismissible: true, onRemove: () => setNotice(null) }, notice.message)
            ),
            h('div', { className: 'scfvb-workspace' },
                h(ElementPanel, { addElement, setDragging, components, componentsLoading, selected, insertComponent, saveSelectedAsComponent, deleteLibraryComponent, refreshComponents }),
                h('main', { className: 'scfvb-center' },
                    h(Canvas, {
                        layout, breakpoint, previewWidth, updatePreviewWidth, selectedId, setSelectedId,
                        dragging, setDragging, canDropOn, handleDrop,
                        moveNodeSibling, duplicateNode, deleteNode, toggleGroupById, toggleRepeaterById,
                        saveSelectedAsComponent, updateSelectedComponent, detachSelectedComponent,
                        beginGesture, endGesture, patchStyleById
                    }),
                    h(Navigator, {
                        nodes: layout.nodes, selectedId, setSelectedId, dragging, setDragging,
                        canDropOn, handleDrop, moveNodeSibling, duplicateNode, deleteNode, renameNode
                    })
                ),
                h(Inspector, {
                    node: selected, breakpoint, updateSelected, scfAvailable: config.scfAvailable,
                    components, componentRoot: selectedComponentRoot, saveSelectedAsComponent, updateSelectedComponent, detachSelectedComponent,
                    pageLayout: (layout.settings && layout.settings.pageLayout) || 'fullwidth', setPageLayout
                })
            )
        );
    }

    function Toolbar(props) {
        const meta = BREAKPOINTS[props.breakpoint];
        return h('header', { className: 'scfvb-toolbar' },
            h('div', { className: 'scfvb-toolbar-left' },
                h('a', { href: config.pagesUrl, className: 'scfvb-link' }, '← Pages'),
                h('strong', null, config.postTitle || 'Page'),
                props.dirty && h('span', { className: 'scfvb-dirty' }, 'Unsaved'),
                h('label', { className: 'scfvb-toolbar-select' },
                    h('span', null, 'Layout'),
                    h('select', { value: props.pageLayout, onChange: (e) => props.setPageLayout(e.target.value) },
                        h('option', { value: 'theme' }, 'Theme'),
                        h('option', { value: 'fullwidth' }, 'Full Width'),
                        h('option', { value: 'canvas' }, 'Builder Canvas')
                    )
                )
            ),
            h('div', { className: 'scfvb-toolbar-center' },
                h('div', { className: 'scfvb-breakpoints' },
                    BREAKPOINT_ORDER.map((key) => h('button', {
                        key, type: 'button', className: props.breakpoint === key ? 'is-active' : '',
                        onClick: () => props.setBreakpoint(key),
                        title: breakpointRangeLabel(key)
                    }, BREAKPOINTS[key].label))
                ),
                h('label', { className: 'scfvb-preview-width' },
                    h('input', {
                        type: 'number', value: props.previewWidth, min: meta.min, max: meta.max,
                        onChange: (e) => props.updatePreviewWidth(e.target.value)
                    }),
                    h('span', null, 'px')
                ),
                h('span', { className: 'scfvb-range-label' }, breakpointRangeLabel(props.breakpoint))
            ),
            h('div', { className: 'scfvb-toolbar-right' },
                h(Button, { variant: 'secondary', disabled: !props.canUndo, onClick: props.undo }, 'Undo'),
                h(Button, { variant: 'secondary', disabled: !props.canRedo, onClick: props.redo }, 'Redo'),
                h(Button, { variant: 'secondary', href: config.editUrl }, 'Edit SCF Content'),
                h(Button, { variant: 'secondary', href: config.viewUrl, target: '_blank', rel: 'noopener noreferrer' }, 'View'),
                h(Button, { variant: 'primary', isBusy: props.saving, disabled: props.saving, onClick: props.save }, props.saving ? 'Saving…' : 'Save')
            )
        );
    }

    function breakpointRangeLabel(key) {
        const meta = BREAKPOINTS[key];
        if (key === 'desktop') return meta.min + 'px+';
        return meta.min + '–' + meta.max + 'px';
    }

    function ElementPanel(props) {
        function item(type, label) {
            return h('button', {
                type: 'button', draggable: true,
                onClick: () => props.addElement(type),
                onDragStart: (event) => {
                    event.dataTransfer.effectAllowed = 'copy';
                    event.dataTransfer.setData('application/x-scfvb-new', type);
                    event.dataTransfer.setData('text/plain', type);
                    props.setDragging({ kind: 'new', type });
                },
                onDragEnd: () => props.setDragging(null)
            }, h('span', { className: 'scfvb-element-icon' }, elementIcon(type)), h('span', null, label));
        }

        const canSaveComponent = !!(props.selected && ['section', 'container'].includes(props.selected.type));
        return h('aside', { className: 'scfvb-sidebar scfvb-elements' },
            h('h2', null, 'Elements'),
            h('div', { className: 'scfvb-palette-group' },
                h('h3', null, 'Layout'), item('section', 'Section'), item('container', 'Container')
            ),
            h('div', { className: 'scfvb-palette-group' },
                h('h3', null, 'Content'), item('heading', 'Heading'), item('text', 'Text'), item('image', 'Image'), item('button', 'Button')
            ),
            h('p', { className: 'description' }, 'Drag an element directly onto a valid Section or Container on the canvas, or click it to add to the selected container.'),
            h('div', { className: 'scfvb-component-library' },
                h('div', { className: 'scfvb-component-library-heading' },
                    h('h3', null, 'Components'),
                    h('button', { type: 'button', title: 'Refresh library', onClick: props.refreshComponents }, '↻')
                ),
                h(Button, { variant: 'secondary', disabled: !canSaveComponent, onClick: props.saveSelectedAsComponent }, 'Save Selected as Component'),
                props.componentsLoading && h('div', { className: 'scfvb-component-loading' }, h(Spinner)),
                !props.componentsLoading && !(props.components || []).length && h('p', { className: 'description' }, 'No reusable components yet.'),
                (props.components || []).map((component) => h('div', { className: 'scfvb-component-card', key: component.id },
                    h('div', { className: 'scfvb-component-card-title' },
                        h('strong', null, component.name),
                        h('span', null, component.rootType === 'section' ? 'Section' : 'Container')
                    ),
                    h('div', { className: 'scfvb-component-card-actions' },
                        h('button', { type: 'button', onClick: () => props.insertComponent(component, true) }, 'Linked'),
                        h('button', { type: 'button', onClick: () => props.insertComponent(component, false) }, 'Detached'),
                        h('button', { type: 'button', className: 'is-delete', title: 'Delete from library', onClick: () => props.deleteLibraryComponent(component) }, '×')
                    )
                ))
            )
        );
    }

    function elementIcon(type) {
        return { section: 'S', container: '□', heading: 'H', text: 'T', image: 'I', button: 'B' }[type] || '•';
    }

    function Canvas(props) {
        const hostRef = useRef(null);
        const stageRef = useRef(null);
        const [hostWidth, setHostWidth] = useState(900);
        const [stageHeight, setStageHeight] = useState(640);
        const [canvasDropTarget, setCanvasDropTarget] = useState(null);
        const canvasDropTargetRef = useRef(null);

        useEffect(() => {
            if (!hostRef.current || !window.ResizeObserver) return;
            const observer = new ResizeObserver((entries) => {
                const width = entries[0] && entries[0].contentRect ? entries[0].contentRect.width : hostRef.current.clientWidth;
                setHostWidth(width || 900);
            });
            observer.observe(hostRef.current);
            return () => observer.disconnect();
        }, []);

        useEffect(() => {
            if (!stageRef.current || !window.ResizeObserver) return;
            const observer = new ResizeObserver(() => setStageHeight(Math.max(640, stageRef.current.offsetHeight || 640)));
            observer.observe(stageRef.current);
            return () => observer.disconnect();
        }, []);

        useEffect(() => {
            if (!props.dragging) updateCanvasDropTarget(null);
        }, [props.dragging]);

        const available = Math.max(320, hostWidth - 48);
        const scale = Math.min(1, Math.max(0.45, available / props.previewWidth));
        const canRootDrop = props.dragging && props.canDropOn(null);

        function updateCanvasDropTarget(next) {
            canvasDropTargetRef.current = next;
            setCanvasDropTarget((current) => {
                if (!next) return current ? null : current;
                if (current && current.parentId === next.parentId && current.index === next.index && current.nodeId === next.nodeId && current.position === next.position && current.axis === next.axis) {
                    return current;
                }
                return next;
            });
        }

        function rootDragOver(event) {
            if (!canRootDrop) return;
            // With existing nodes, nested PreviewNode hit-testing owns the drop.
            // This prevents an invalid nested hover from silently becoming "append
            // Section to page root" when dragover bubbles to the stage.
            if (props.layout.nodes.length && event.target !== event.currentTarget) return;
            event.preventDefault();
            event.dataTransfer.dropEffect = props.dragging && props.dragging.kind === 'new' ? 'copy' : 'move';
            updateCanvasDropTarget({
                parentId: null,
                index: props.layout.nodes.length,
                nodeId: null,
                position: 'root',
                axis: 'column'
            });
        }

        function rootDragLeave(event) {
            if (!event.currentTarget.contains(event.relatedTarget)) updateCanvasDropTarget(null);
        }

        function performCanvasDrop(event) {
            const target = canvasDropTargetRef.current;
            if (!target) return;
            event.preventDefault();
            event.stopPropagation();
            props.handleDrop(event, target.parentId, target.index);
            updateCanvasDropTarget(null);
        }

        return h('section', { className: 'scfvb-canvas-shell' + (props.dragging ? ' is-dragging' : '') },
            h('div', { className: 'scfvb-canvas-header' },
                h('strong', null, 'Canvas'),
                h('span', null, BREAKPOINTS[props.breakpoint].label + ' · ' + props.previewWidth + 'px · ' + Math.round(scale * 100) + '%')
            ),
            h('div', { className: 'scfvb-canvas-host', ref: hostRef },
                h('div', { className: 'scfvb-canvas-scaled-wrap', style: { height: Math.ceil(stageHeight * scale) + 'px' } },
                    h('div', {
                        ref: stageRef,
                        className: 'scfvb-canvas-stage' + (canvasDropTarget && canvasDropTarget.position === 'root' ? ' is-drop-root' : ''),
                        style: { width: props.previewWidth + 'px', transform: 'translateX(-50%) scale(' + scale + ')' },
                        onClick: () => props.setSelectedId(null),
                        onDragOver: rootDragOver,
                        onDragLeave: rootDragLeave,
                        onDrop: performCanvasDrop
                    },
                        props.layout.nodes.length
                            ? props.layout.nodes.map((node, index) => h(PreviewNode, Object.assign({}, props, {
                                key: node.id,
                                node,
                                scale,
                                parentId: null,
                                index,
                                parentDirection: 'column',
                                canvasDropTarget,
                                setCanvasDropTarget: updateCanvasDropTarget,
                                performCanvasDrop
                            })))
                            : h('div', { className: 'scfvb-empty-canvas' }, canRootDrop ? 'Drop Section here' : (props.dragging ? 'A page starts with a Section' : 'Drag or add a Section to begin.')),
                        h(ViewportHandle, { breakpoint: props.breakpoint, previewWidth: props.previewWidth, scale, updatePreviewWidth: props.updatePreviewWidth })
                    )
                )
            )
        );
    }

    function ViewportHandle(props) {
        function start(event) {
            event.preventDefault(); event.stopPropagation();
            const startX = event.clientX;
            const startWidth = Number(props.previewWidth);
            const meta = BREAKPOINTS[props.breakpoint];
            function move(e) {
                const next = Math.round(clamp(startWidth + (e.clientX - startX) / props.scale, Number(meta.min), Number(meta.max)));
                props.updatePreviewWidth(next);
            }
            function up() {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
                window.removeEventListener('pointercancel', up);
            }
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up, { once: true });
            window.addEventListener('pointercancel', up, { once: true });
        }
        return h('button', {
            type: 'button', className: 'scfvb-viewport-handle', draggable: false,
            title: 'Drag to change preview width within this breakpoint',
            onPointerDown: start, onClick: (e) => { e.preventDefault(); e.stopPropagation(); }
        }, '↔');
    }

    function PreviewNode(props) {
        const node = props.node;
        const selected = props.selectedId === node.id;
        const styles = toReactStyle(effectiveStyles(node, props.breakpoint));
        const direction = styles.display === 'grid' ? 'column' : (styles.flexDirection || 'column');
        const children = node.children || [];
        const draggingSelf = props.dragging && props.dragging.kind === 'node' && props.dragging.id === node.id;
        const canAppend = !!(props.dragging && !draggingSelf && CONTAINER_TYPES.includes(node.type) && props.canDropOn(node.id));
        const canSibling = !!(props.dragging && !draggingSelf && props.canDropOn(props.parentId));
        const parentAxis = props.parentDirection && props.parentDirection.indexOf('row') === 0 ? 'row' : 'column';
        const target = props.canvasDropTarget;
        const isTargetNode = !!(target && target.nodeId === node.id);
        const dropClass = isTargetNode ? ' is-drop-' + target.position + (target.axis === 'row' ? ' is-drop-axis-row' : ' is-drop-axis-column') : '';

        function setTarget(next) {
            props.setCanvasDropTarget(next);
        }

        function handleCanvasDragOver(event) {
            if (!props.dragging || draggingSelf) return;

            const rect = event.currentTarget.getBoundingClientRect();
            const axis = parentAxis;
            const pointer = axis === 'row' ? event.clientX : event.clientY;
            const start = axis === 'row' ? rect.left : rect.top;
            const size = Math.max(1, axis === 'row' ? rect.width : rect.height);
            const ratio = (pointer - start) / size;

            let next = null;

            // Containers accept drops into their body. The outer 22% remains available
            // for sibling insertion when the parent can also accept the dragged node.
            if (canAppend && (!canSibling || (ratio >= 0.22 && ratio <= 0.78))) {
                next = {
                    parentId: node.id,
                    index: children.length,
                    nodeId: node.id,
                    position: 'inside',
                    axis: direction && direction.indexOf('row') === 0 ? 'row' : 'column'
                };
            } else if (canSibling) {
                const before = ratio < 0.5;
                next = {
                    parentId: props.parentId || null,
                    index: props.index + (before ? 0 : 1),
                    nodeId: node.id,
                    position: before ? 'before' : 'after',
                    axis
                };
            } else if (canAppend) {
                next = {
                    parentId: node.id,
                    index: children.length,
                    nodeId: node.id,
                    position: 'inside',
                    axis: direction && direction.indexOf('row') === 0 ? 'row' : 'column'
                };
            }

            if (!next) {
                setTarget(null);
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            event.dataTransfer.dropEffect = props.dragging.kind === 'new' ? 'copy' : 'move';
            setTarget(next);
        }

        function handleCanvasDrop(event) {
            if (!props.dragging) return;
            props.performCanvasDrop(event);
        }

        const common = {
            className: 'scfvb-preview-node scfvb-preview-' + node.type + (selected ? ' is-selected' : '') + (isRepeater(node) ? ' is-repeater' : '') + dropClass,
            style: styles,
            draggable: true,
            onClick: (event) => { event.stopPropagation(); props.setSelectedId(node.id); },
            onDragOver: handleCanvasDragOver,
            onDrop: handleCanvasDrop,
            onDragStart: (event) => {
                event.stopPropagation();
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('application/x-scfvb-node', node.id);
                event.dataTransfer.setData('text/plain', node.id);
                props.setDragging({ kind: 'node', id: node.id });
            },
            onDragEnd: () => props.setDragging(null),
            title: node.name + ' (' + node.type + ')'
        };

        let content;
        if (node.type === 'section' || node.type === 'container') {
            const childDirection = direction && direction.indexOf('row') === 0 ? direction : 'column';
            const items = children.map((child, index) => h(PreviewNode, Object.assign({}, props, {
                key: child.id,
                node: child,
                parentId: node.id,
                index,
                parentDirection: childDirection
            })));
            if (!children.length) items.push(h('div', { key: 'empty', className: 'scfvb-empty-node' }, node.type === 'section' ? 'Drop a Container here' : 'Drop content here'));
            content = items;
        } else if (node.type === 'heading') {
            const tag = (node.settings && node.settings.tag) || 'h2';
            content = h(tag, { className: 'scfvb-preview-content' }, node.content.text || 'Heading', isScf(node.bindings.text) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        } else if (node.type === 'text') {
            content = h('div', { className: 'scfvb-preview-content' }, h('p', null, node.content.text || 'Text'), isScf(node.bindings.text) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        } else if (node.type === 'image') {
            const imageStyle = {
                objectFit: styles.objectFit || 'cover',
                objectPosition: styles.objectPosition || 'center center',
                width: '100%',
                height: (styles.height && styles.height !== 'auto') || (styles.aspectRatio && styles.aspectRatio !== 'auto') ? '100%' : 'auto',
                borderRadius: 'inherit'
            };
            content = node.content.imageUrl
                ? h(Fragment, null, h('img', { className: 'scfvb-preview-content scfvb-preview-image-content', src: node.content.imageUrl, alt: '', draggable: false, style: imageStyle }), isScf(node.bindings.image) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'))
                : h(Fragment, null, h('div', { className: 'scfvb-image-placeholder', style: imageStyle }, 'Image'), isScf(node.bindings.image) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        } else if (node.type === 'button') {
            content = h('span', { className: 'scfvb-preview-content' }, node.content.label || 'Button', (isScf(node.bindings.label) || isScf(node.bindings.url)) && h('span', { className: 'scfvb-scf-badge' }, 'SCF'));
        }

        return h('div', common,
            h('span', { className: 'scfvb-node-label' }, node.name, isLinkedComponent(node) && h('b', { className: 'scfvb-component-mini-badge' }, 'COMPONENT'), isGroup(node) && h('b', { className: 'scfvb-group-mini-badge' }, 'GROUP'), isRepeater(node) && h('b', { className: 'scfvb-repeater-mini-badge' }, 'REPEATER')),
            content,
            selected && h(ContextToolbar, { node, move: props.moveNodeSibling, duplicate: props.duplicateNode, remove: props.deleteNode, toggleGroup: props.toggleGroupById, toggleRepeater: props.toggleRepeaterById, saveAsComponent: props.saveSelectedAsComponent, updateComponent: props.updateSelectedComponent, detachComponent: props.detachSelectedComponent }),
            selected && node.type !== 'section' && h(ResizeChrome, {
                node, scale: props.scale, breakpoint: props.breakpoint,
                beginGesture: props.beginGesture, endGesture: props.endGesture, patchStyle: props.patchStyleById
            }),
            selected && CONTAINER_TYPES.includes(node.type) && h(PaddingChrome, {
                node, scale: props.scale, breakpoint: props.breakpoint,
                beginGesture: props.beginGesture, endGesture: props.endGesture, patchStyle: props.patchStyleById
            })
        );
    }

    function ContextToolbar(props) {
        function button(label, onClick, destructive) {
            return h('button', {
                type: 'button', className: destructive ? 'is-destructive' : '', draggable: false,
                onPointerDown: (e) => e.stopPropagation(),
                onClick: (e) => { e.preventDefault(); e.stopPropagation(); onClick(); }
            }, label);
        }
        return h('div', { className: 'scfvb-node-toolbar', draggable: false, onDragStart: (e) => e.preventDefault() },
            h('strong', null, props.node.name),
            button('↑', () => props.move(props.node.id, -1)),
            button('↓', () => props.move(props.node.id, 1)),
            props.node.type === 'container' && props.toggleGroup && button(isGroup(props.node) ? 'Normal' : 'Group', () => props.toggleGroup(props.node.id)),
            props.node.type === 'container' && props.toggleRepeater && button(isRepeater(props.node) ? 'Normal' : 'Repeat', () => props.toggleRepeater(props.node.id)),
            ['section', 'container'].includes(props.node.type) && !isLinkedComponent(props.node) && props.saveAsComponent && button('Save Component', props.saveAsComponent),
            isLinkedComponent(props.node) && props.updateComponent && button('Update Master', props.updateComponent),
            isLinkedComponent(props.node) && props.detachComponent && button('Detach', props.detachComponent),
            button('Duplicate', () => props.duplicate(props.node.id)),
            button('Delete', () => props.remove(props.node.id), true)
        );
    }

    function ResizeChrome(props) {
        function start(event, axis) {
            event.preventDefault(); event.stopPropagation();
            const nodeElement = event.currentTarget.closest('.scfvb-preview-node');
            if (!nodeElement) return;
            const rect = nodeElement.getBoundingClientRect();
            const startX = event.clientX, startY = event.clientY;
            const startWidth = rect.width / props.scale;
            const startHeight = rect.height / props.scale;
            props.beginGesture();

            function move(e) {
                if (axis.indexOf('e') !== -1) {
                    const width = Math.round(clamp(startWidth + (e.clientX - startX) / props.scale, 40, 2400));
                    props.patchStyle(props.node.id, 'width', width + 'px', true);
                }
                if (axis.indexOf('s') !== -1) {
                    const height = Math.round(clamp(startHeight + (e.clientY - startY) / props.scale, 20, 2000));
                    props.patchStyle(props.node.id, 'height', height + 'px', true);
                }
            }
            function up() {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
                window.removeEventListener('pointercancel', up);
                props.endGesture();
            }
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up, { once: true });
            window.addEventListener('pointercancel', up, { once: true });
        }
        return h(Fragment, null,
            h('span', { className: 'scfvb-resize-handle is-east', draggable: false, onPointerDown: (e) => start(e, 'e'), title: 'Drag to resize width' }),
            h('span', { className: 'scfvb-resize-handle is-south', draggable: false, onPointerDown: (e) => start(e, 's'), title: 'Drag to resize height' }),
            h('span', { className: 'scfvb-resize-handle is-southeast', draggable: false, onPointerDown: (e) => start(e, 'es'), title: 'Drag to resize' })
        );
    }

    function PaddingChrome(props) {
        const effective = effectiveStyles(props.node, props.breakpoint);
        const sides = [
            ['Top', 'paddingTop', 'vertical'], ['Right', 'paddingRight', 'horizontal'],
            ['Bottom', 'paddingBottom', 'vertical'], ['Left', 'paddingLeft', 'horizontal']
        ];
        function start(event, key, axis) {
            event.preventDefault(); event.stopPropagation();
            const startX = event.clientX, startY = event.clientY;
            const startValue = pxNumber(effective[key], 0);
            props.beginGesture();
            function move(e) {
                let rawDelta = axis === 'horizontal' ? (e.clientX - startX) : (e.clientY - startY);
                if (key === 'paddingRight' || key === 'paddingBottom') rawDelta *= -1;
                const next = Math.round(clamp(startValue + rawDelta / props.scale, 0, 500));
                props.patchStyle(props.node.id, key, next + 'px', true);
            }
            function up() {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
                window.removeEventListener('pointercancel', up);
                props.endGesture();
            }
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up, { once: true });
            window.addEventListener('pointercancel', up, { once: true });
        }
        return h(Fragment, null, sides.map((side) => h('button', {
            key: side[1], type: 'button', draggable: false,
            className: 'scfvb-padding-handle is-' + side[0].toLowerCase(),
            title: 'Drag ' + side[0].toLowerCase() + ' padding',
            onPointerDown: (e) => start(e, side[1], side[2]),
            onClick: (e) => { e.preventDefault(); e.stopPropagation(); }
        }, pxNumber(effective[side[1]], 0))));
    }

    function isScf(binding) { return binding && binding.source === 'scf'; }
    function isGroup(node) { return !!(node && node.type === 'container' && node.group && node.group.enabled); }
    function isRepeater(node) { return !!(node && node.type === 'container' && node.repeater && node.repeater.enabled); }
    function countScfBindings(node) {
        let count = Object.values((node && node.bindings) || {}).filter(isScf).length;
        ((node && node.children) || []).forEach((child) => { count += countScfBindings(child); });
        return count;
    }

    function Navigator(props) {
        const [collapsed, setCollapsed] = useState({});
        const [editingId, setEditingId] = useState(null);

        function toggle(id) { setCollapsed((current) => Object.assign({}, current, { [id]: !current[id] })); }

        return h('section', { className: 'scfvb-navigator' },
            h('div', { className: 'scfvb-navigator-header' },
                h('div', null, h('strong', null, 'Navigator'), h('span', { className: 'description' }, 'Double-click a name to rename')),
                h('div', null,
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.moveNodeSibling(props.selectedId, -1) }, '↑'),
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.moveNodeSibling(props.selectedId, 1) }, '↓'),
                    h(Button, { size: 'compact', variant: 'secondary', disabled: !props.selectedId, onClick: () => props.duplicateNode(props.selectedId) }, 'Duplicate'),
                    h(Button, { size: 'compact', isDestructive: true, disabled: !props.selectedId, onClick: () => props.deleteNode(props.selectedId) }, 'Delete')
                )
            ),
            h('div', { className: 'scfvb-tree' },
                props.nodes.length
                    ? h(NavigatorChildren, Object.assign({}, props, { parentId: null, nodes: props.nodes, depth: 0, collapsed, toggle, editingId, setEditingId }))
                    : h('span', { className: 'description scfvb-tree-empty' }, 'No nodes yet.')
            )
        );
    }

    function NavigatorChildren(props) {
        const items = [];
        const canDrop = props.dragging && props.canDropOn(props.parentId);
        if (props.dragging) items.push(h(NavDropZone, { key: 'drop0', parentId: props.parentId, index: 0, active: canDrop, handleDrop: props.handleDrop, depth: props.depth }));
        props.nodes.forEach((node, index) => {
            items.push(h(NavigatorNode, Object.assign({}, props, { key: node.id, node, depth: props.depth })));
            if (props.dragging) items.push(h(NavDropZone, { key: 'drop' + (index + 1), parentId: props.parentId, index: index + 1, active: canDrop, handleDrop: props.handleDrop, depth: props.depth }));
        });
        return h(Fragment, null, items);
    }

    function NavDropZone(props) {
        return h('div', {
            className: 'scfvb-nav-drop' + (props.active ? ' is-active' : ''),
            style: { marginLeft: (12 + props.depth * 18) + 'px' },
            onDragOver: props.active ? (e) => e.preventDefault() : undefined,
            onDrop: props.active ? (e) => props.handleDrop(e, props.parentId, props.index) : undefined
        });
    }

    function NavigatorNode(props) {
        const node = props.node;
        const hasChildren = (node.children || []).length > 0;
        const collapsed = !!props.collapsed[node.id];
        const editing = props.editingId === node.id;
        return h(Fragment, null,
            h('div', {
                className: 'scfvb-tree-row' + (props.selectedId === node.id ? ' is-selected' : ''),
                style: { paddingLeft: (6 + props.depth * 18) + 'px' },
                draggable: !editing,
                onClick: () => props.setSelectedId(node.id),
                onDoubleClick: () => props.setEditingId(node.id),
                onDragStart: (event) => {
                    event.dataTransfer.effectAllowed = 'move';
                    event.dataTransfer.setData('application/x-scfvb-node', node.id);
                    event.dataTransfer.setData('text/plain', node.id);
                    props.setDragging({ kind: 'node', id: node.id });
                },
                onDragEnd: () => props.setDragging(null)
            },
                h('button', {
                    type: 'button', className: 'scfvb-tree-toggle', disabled: !hasChildren,
                    onClick: (e) => { e.stopPropagation(); if (hasChildren) props.toggle(node.id); }
                }, hasChildren ? (collapsed ? '›' : '⌄') : '·'),
                h('span', { className: 'scfvb-tree-type' }, elementIcon(node.type)),
                editing
                    ? h('input', {
                        className: 'scfvb-tree-rename', autoFocus: true, defaultValue: node.name,
                        onClick: (e) => e.stopPropagation(),
                        onKeyDown: (e) => {
                            if (e.key === 'Enter') { props.renameNode(node.id, e.currentTarget.value); props.setEditingId(null); }
                            if (e.key === 'Escape') props.setEditingId(null);
                        },
                        onBlur: (e) => { props.renameNode(node.id, e.currentTarget.value); props.setEditingId(null); }
                    })
                    : h('span', { className: 'scfvb-tree-name' }, node.name),
                isLinkedComponent(node) && h('span', { className: 'scfvb-tree-component' }, 'COMP'),
                isGroup(node) && h('span', { className: 'scfvb-tree-group' }, 'GROUP'),
                isRepeater(node) && h('span', { className: 'scfvb-tree-repeater' }, 'REPEATER'),
                !isLinkedComponent(node) && !isGroup(node) && !isRepeater(node) && Object.values(node.bindings || {}).some(isScf) && h('span', { className: 'scfvb-tree-scf' }, 'SCF')
            ),
            hasChildren && !collapsed && h(NavigatorChildren, Object.assign({}, props, { parentId: node.id, nodes: node.children, depth: props.depth + 1 }))
        );
    }

    function Inspector(props) {
        const node = props.node;
        if (!node) {
            return h('aside', { className: 'scfvb-sidebar scfvb-inspector' },
                h('h2', null, 'Page'),
                h(LabeledSelect, {
                    label: 'Page Layout', value: props.pageLayout,
                    options: [
                        { value: 'theme', label: 'Theme' },
                        { value: 'fullwidth', label: 'Full Width' },
                        { value: 'canvas', label: 'Builder Canvas' }
                    ],
                    onChange: props.setPageLayout
                }),
                h('p', { className: 'description' },
                    props.pageLayout === 'canvas'
                        ? 'Builder Canvas bypasses the theme template and renders only the visual-builder page, while keeping WordPress head/footer hooks and the admin bar.'
                        : props.pageLayout === 'fullwidth'
                            ? 'Full Width keeps the theme header/footer but breaks the builder content out of the theme content constraint.'
                            : 'Theme keeps the builder inside the theme content area.'
                )
            );
        }

        function patchContent(key, value) {
            props.updateSelected((copy) => { copy.content = Object.assign({}, copy.content, { [key]: value }); return copy; });
        }
        function patchContentValues(values) {
            props.updateSelected((copy) => { copy.content = Object.assign({}, copy.content, values || {}); return copy; });
        }
        function patchSetting(key, value) {
            props.updateSelected((copy) => { copy.settings = Object.assign({}, copy.settings, { [key]: value }); return copy; });
        }
        function patchStyle(key, value) {
            props.updateSelected((copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                const next = Object.assign({}, copy.styles[props.breakpoint] || {});
                if (typeof value === 'string' && value.trim() === '') delete next[key];
                else next[key] = value;
                copy.styles[props.breakpoint] = next;
                return copy;
            });
        }
        function patchStyles(values) {
            props.updateSelected((copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                const next = Object.assign({}, copy.styles[props.breakpoint] || {});
                Object.keys(values || {}).forEach((key) => {
                    const value = values[key];
                    if (typeof value === 'string' && value.trim() === '') delete next[key];
                    else next[key] = value;
                });
                copy.styles[props.breakpoint] = next;
                return copy;
            });
        }
        function resetBreakpoint() {
            if (props.breakpoint === 'desktop') return;
            props.updateSelected((copy) => {
                copy.styles = Object.assign(emptyStyles(), copy.styles || {});
                copy.styles[props.breakpoint] = {};
                return copy;
            });
        }
        function patchBinding(key, patch) {
            props.updateSelected((copy) => {
                const current = Object.assign({ source: 'static' }, (copy.bindings && copy.bindings[key]) || {});
                copy.bindings = Object.assign({}, copy.bindings, { [key]: Object.assign(current, patch) });
                return copy;
            });
        }
        function toggleBinding(key, defaultType, labelSuffix) {
            props.updateSelected((copy) => {
                const current = Object.assign({ source: 'static', fieldType: defaultType }, (copy.bindings && copy.bindings[key]) || {});
                if (current.source === 'scf') {
                    current.source = 'static';
                } else {
                    current.source = 'scf';
                    current.fieldType = current.fieldType || defaultType;
                    current.fieldKey = current.fieldKey || fieldKey();
                    const baseLabel = copy.name + (labelSuffix ? ' ' + labelSuffix : '');
                    current.label = current.label || baseLabel;
                    current.fieldName = current.fieldName || slugify(baseLabel);
                }
                copy.bindings = Object.assign({}, copy.bindings, { [key]: current });
                return copy;
            });
        }

        function setContainerMode(mode) {
            props.updateSelected((copy) => {
                if (copy.type !== 'container') return copy;
                if (mode === 'normal') {
                    delete copy.group;
                    delete copy.repeater;
                    return copy;
                }
                if (mode === 'group') {
                    delete copy.repeater;
                    if (!copy.group || !copy.group.enabled) {
                        const label = String(copy.name || 'Group').trim() || 'Group';
                        copy.group = { enabled: true, fieldKey: groupFieldKey(), fieldName: slugify(label), label };
                    }
                    return copy;
                }
                if (mode === 'repeater') {
                    delete copy.group;
                    if (!copy.repeater || !copy.repeater.enabled) {
                        const label = String(copy.name || 'Repeater').trim() || 'Repeater';
                        copy.repeater = { enabled: true, fieldKey: repeaterFieldKey(), fieldName: slugify(label), label, layout: 'block', buttonLabel: 'Add Row', min: 0, max: 0 };
                    }
                }
                return copy;
            });
        }
        function patchGroup(patch) {
            props.updateSelected((copy) => {
                if (copy.type !== 'container' || !copy.group || !copy.group.enabled) return copy;
                const next = Object.assign({}, copy.group, patch || {});
                if (Object.prototype.hasOwnProperty.call(next, 'fieldName')) next.fieldName = slugify(next.fieldName);
                copy.group = next;
                return copy;
            });
        }
        function patchRepeater(patch) {
            props.updateSelected((copy) => {
                if (copy.type !== 'container' || !copy.repeater || !copy.repeater.enabled) return copy;
                const next = Object.assign({}, copy.repeater, patch || {});
                if (Object.prototype.hasOwnProperty.call(next, 'fieldName')) next.fieldName = slugify(next.fieldName);
                if (Object.prototype.hasOwnProperty.call(next, 'min')) next.min = Math.max(0, Math.min(100, parseInt(next.min || 0, 10) || 0));
                if (Object.prototype.hasOwnProperty.call(next, 'max')) next.max = Math.max(0, Math.min(100, parseInt(next.max || 0, 10) || 0));
                if (next.max > 0 && next.min > next.max) next.min = next.max;
                copy.repeater = next;
                return copy;
            });
        }

        return h('aside', { className: 'scfvb-sidebar scfvb-inspector' },
            h('h2', null, 'Properties'),
            h(LabeledInput, { label: 'Name', value: node.name || '', onChange: (value) => props.updateSelected((copy) => { copy.name = value; return copy; }) }),
            props.componentRoot && h('div', { className: 'scfvb-component-inspector' },
                h('strong', null, 'Linked Component'),
                h('span', null, ((props.components || []).find((item) => item.id === props.componentRoot.component.id) || {}).name || props.componentRoot.component.id),
                h('p', { className: 'description' }, 'Edits inside this instance are draft master changes. Use Update Master to propagate them to every linked instance.'),
                h('div', null,
                    h(Button, { size: 'compact', variant: 'secondary', onClick: props.updateSelectedComponent }, 'Update Master'),
                    h(Button, { size: 'compact', variant: 'secondary', onClick: props.detachSelectedComponent }, 'Detach')
                )
            ),
            !props.componentRoot && ['section', 'container'].includes(node.type) && h('div', { className: 'scfvb-component-inspector' },
                h(Button, { size: 'compact', variant: 'secondary', onClick: props.saveSelectedAsComponent }, 'Save as Component')
            ),
            h(ContentInspector, {
                node, patchContent, patchContentValues, patchSetting, toggleBinding, patchBinding,
                setContainerMode, patchGroup, patchRepeater, scfAvailable: props.scfAvailable
            }),
            h(StyleInspector, { node, breakpoint: props.breakpoint, patchStyle, patchStyles, resetBreakpoint })
        );
    }

    function ContentInspector(props) {
        const node = props.node;
        const rows = [];

        if (node.type === 'container') {
            const containerMode = isRepeater(node) ? 'repeater' : (isGroup(node) ? 'group' : 'normal');
            rows.push(h(SectionTitle, { key: 'data-title' }, 'Data Structure'));
            rows.push(h(LabeledSelect, {
                key: 'container-mode', label: 'Container Type', value: containerMode,
                options: [
                    { value: 'normal', label: 'Normal Container' },
                    { value: 'group', label: 'SCF Group' },
                    { value: 'repeater', label: 'SCF Repeater' }
                ],
                onChange: props.setContainerMode
            }));
            if (!props.scfAvailable) {
                rows.push(h('p', { key: 'structured-unavailable', className: 'description' }, 'Secure Custom Fields must be active to register Group or Repeater fields.'));
            }
            if (isGroup(node)) {
                rows.push(h('div', { className: 'scfvb-group-box', key: 'group-box' },
                    h(LabeledInput, { label: 'Group Label', value: node.group.label || '', onChange: (value) => props.patchGroup({ label: value }) }),
                    h(LabeledInput, { label: 'Group Name', value: node.group.fieldName || '', onChange: (value) => props.patchGroup({ fieldName: value }) }),
                    h('code', { className: 'scfvb-field-key' }, node.group.fieldKey || ''),
                    h('p', { className: 'description' }, countScfBindings(node) + ' editable SCF field' + (countScfBindings(node) === 1 ? '' : 's') + ' inside this visual subtree.')
                ));
            }
            if (isRepeater(node)) {
                rows.push(h('div', { className: 'scfvb-repeater-box', key: 'repeater-box' },
                    h(LabeledInput, { label: 'Repeater Label', value: node.repeater.label || '', onChange: (value) => props.patchRepeater({ label: value }) }),
                    h(LabeledInput, { label: 'Repeater Name', value: node.repeater.fieldName || '', onChange: (value) => props.patchRepeater({ fieldName: value }) }),
                    h(LabeledSelect, { label: 'Editor Layout', value: node.repeater.layout || 'block', options: [
                        { value: 'block', label: 'Block' }, { value: 'row', label: 'Row' }, { value: 'table', label: 'Table' }
                    ], onChange: (value) => props.patchRepeater({ layout: value }) }),
                    h(LabeledInput, { label: 'Add Row Button', value: node.repeater.buttonLabel || 'Add Row', onChange: (value) => props.patchRepeater({ buttonLabel: value }) }),
                    h('div', { className: 'scfvb-repeater-limits' },
                        h(LabeledInput, { label: 'Minimum Rows', type: 'number', value: String(node.repeater.min || 0), onChange: (value) => props.patchRepeater({ min: value }) }),
                        h(LabeledInput, { label: 'Maximum Rows (0 = unlimited)', type: 'number', value: String(node.repeater.max || 0), onChange: (value) => props.patchRepeater({ max: value }) })
                    ),
                    h('code', { className: 'scfvb-field-key' }, node.repeater.fieldKey || ''),
                    h('p', { className: 'description' }, countScfBindings(node) + ' editable SCF subfield' + (countScfBindings(node) === 1 ? '' : 's') + ' in the row template.'),
                    h('p', { className: 'description' }, 'The canvas shows one template row. The frontend repeats this visual Container once for every SCF row.')
                ));
            }
        }

        if (node.type !== 'container') rows.push(h(SectionTitle, { key: 'title' }, 'Content'));

        if (node.type === 'heading' || node.type === 'text') {
            rows.push(h('label', { className: 'scfvb-field', key: 'text' },
                h('span', null, 'Text'),
                h('textarea', { rows: node.type === 'text' ? 5 : 3, value: node.content.text || '', onChange: (e) => props.patchContent('text', e.target.value) })
            ));
            if (node.type === 'heading') {
                rows.push(h(LabeledSelect, { key: 'tag', label: 'HTML Tag', value: node.settings.tag || 'h2', options: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], onChange: (value) => props.patchSetting('tag', value) }));
            }
            rows.push(h(BindingEditor, {
                key: 'binding', bindingKey: 'text', binding: node.bindings.text || { source: 'static' },
                fieldTypes: node.type === 'text' ? ['text', 'textarea'] : ['text'],
                defaultType: node.type === 'text' ? 'textarea' : 'text',
                toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        if (node.type === 'image') {
            rows.push(h('div', { className: 'scfvb-media-row', key: 'media' },
                node.content.imageUrl ? h('img', { src: node.content.imageUrl, alt: '' }) : h('div', { className: 'scfvb-media-empty' }, 'No image'),
                h(Button, { variant: 'secondary', onClick: () => openMedia(props.patchContentValues) }, 'Choose Image')
            ));
            rows.push(h(BindingEditor, {
                key: 'binding', bindingKey: 'image', binding: node.bindings.image || { source: 'static' },
                fieldTypes: ['image'], defaultType: 'image', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        if (node.type === 'button') {
            rows.push(h(LabeledInput, { key: 'label', label: 'Label', value: node.content.label || '', onChange: (value) => props.patchContent('label', value) }));
            rows.push(h(BindingEditor, {
                key: 'label-binding', title: 'Label Binding', bindingKey: 'label', binding: node.bindings.label || { source: 'static' },
                fieldTypes: ['text'], defaultType: 'text', labelSuffix: 'Label', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
            rows.push(h(LabeledInput, { key: 'url', label: 'URL', value: node.content.url || '', onChange: (value) => props.patchContent('url', value) }));
            rows.push(h(BindingEditor, {
                key: 'url-binding', title: 'URL Binding', bindingKey: 'url', binding: node.bindings.url || { source: 'static' },
                fieldTypes: ['url'], defaultType: 'url', labelSuffix: 'URL', toggle: props.toggleBinding, patch: props.patchBinding, scfAvailable: props.scfAvailable
            }));
        }

        return h(Fragment, null, rows);
    }

    function BindingEditor(props) {
        const binding = props.binding || { source: 'static' };
        const editable = binding.source === 'scf';
        return h('div', { className: 'scfvb-binding-box' },
            props.title && h('strong', null, props.title),
            h('label', { className: 'scfvb-toggle-row' },
                h('input', { type: 'checkbox', checked: editable, disabled: !props.scfAvailable, onChange: () => props.toggle(props.bindingKey, props.defaultType, props.labelSuffix) }),
                h('span', null, 'Editable with SCF')
            ),
            editable && h(Fragment, null,
                h(LabeledInput, { label: 'Field Label', value: binding.label || '', onChange: (value) => props.patch(props.bindingKey, { label: value }) }),
                h(LabeledInput, { label: 'Field Name', value: binding.fieldName || '', onChange: (value) => props.patch(props.bindingKey, { fieldName: slugify(value) }) }),
                h(LabeledSelect, { label: 'Field Type', value: binding.fieldType || props.defaultType, options: props.fieldTypes, onChange: (value) => props.patch(props.bindingKey, { fieldType: value }) }),
                h('code', { className: 'scfvb-field-key' }, binding.fieldKey || '')
            )
        );
    }

    function chooseMediaImage(title, onSelect) {
        if (!wp.media) return;
        const frame = wp.media({ title: title || 'Select image', library: { type: 'image' }, multiple: false });
        frame.on('select', function () {
            const item = frame.state().get('selection').first().toJSON();
            onSelect({ id: item.id || 0, url: item.url || '', alt: item.alt || '' });
        });
        frame.open();
    }

    function openMedia(patchContentValues) {
        chooseMediaImage('Select image', function (item) {
            patchContentValues({ imageId: item.id, imageUrl: item.url });
        });
    }

    function gridColumnMode(template) {
        const text = String(template || '');
        let match = text.match(/^repeat\((\d+),minmax\(0,1fr\)\)$/);
        if (match) return match[1];
        match = text.match(/^repeat\((auto-fit|auto-fill),minmax\(.+?,1fr\)\)$/);
        return match ? match[1] : '2';
    }

    function gridColumnMinWidth(template) {
        const match = String(template || '').match(/^repeat\((?:auto-fit|auto-fill),minmax\((.+?),1fr\)\)$/);
        return match ? match[1] : '240px';
    }

    function gridRowMode(template) {
        const match = String(template || '').match(/^repeat\((\d+),auto\)$/);
        return match ? match[1] : 'auto';
    }

    function StyleInspector(props) {
        const node = props.node;
        const current = (node.styles && node.styles[props.breakpoint]) || {};
        const effective = effectiveStyles(node, props.breakpoint);
        const value = (key, fallback) => current[key] !== undefined ? current[key] : (effective[key] !== undefined ? effective[key] : fallback);
        const inherited = (key) => props.breakpoint !== 'desktop' && current[key] === undefined;
        const titleAction = props.breakpoint === 'desktop' ? null : h('button', { type: 'button', className: 'scfvb-reset-overrides', onClick: props.resetBreakpoint }, 'Reset overrides');
        const rows = [h(SectionTitle, { key: 'title', action: titleAction }, 'Style — ' + BREAKPOINTS[props.breakpoint].label)];

        if (CONTAINER_TYPES.includes(node.type)) {
            const display = value('display', 'flex');
            rows.push(h(SectionTitle, { key: 'layout-title' }, 'Layout'));
            rows.push(h(LabeledSelect, {
                key: 'layout-mode', label: 'Layout Mode', value: display === 'grid' ? 'grid' : 'flex',
                options: [{ value: 'flex', label: 'Flexbox' }, { value: 'grid', label: 'CSS Grid' }],
                onChange: (v) => {
                    if (v === 'grid') {
                        props.patchStyles({
                            display: 'grid',
                            gridTemplateColumns: value('gridTemplateColumns', GRID_DEFAULTS.gridTemplateColumns),
                            gridTemplateRows: value('gridTemplateRows', GRID_DEFAULTS.gridTemplateRows),
                            columnGap: value('columnGap', value('gap', '16px')),
                            rowGap: value('rowGap', value('gap', '16px')),
                            gridAutoFlow: value('gridAutoFlow', GRID_DEFAULTS.gridAutoFlow)
                        });
                    } else {
                        props.patchStyle('display', 'flex');
                    }
                }
            }));

            if (display === 'grid') {
                const template = value('gridTemplateColumns', 'repeat(2,minmax(0,1fr))');
                const columnMode = gridColumnMode(template);
                rows.push(h(LabeledSelect, {
                    key: 'grid-columns', label: 'Columns', value: columnMode,
                    options: [
                        { value: '1', label: '1 column' }, { value: '2', label: '2 columns' }, { value: '3', label: '3 columns' },
                        { value: '4', label: '4 columns' }, { value: '5', label: '5 columns' }, { value: '6', label: '6 columns' },
                        { value: 'auto-fit', label: 'Auto Fit' }, { value: 'auto-fill', label: 'Auto Fill' }
                    ],
                    onChange: (v) => {
                        const next = /^\d+$/.test(v)
                            ? 'repeat(' + v + ',minmax(0,1fr))'
                            : 'repeat(' + v + ',minmax(' + gridColumnMinWidth(template) + ',1fr))';
                        props.patchStyle('gridTemplateColumns', next);
                    }
                }));
                if (columnMode === 'auto-fit' || columnMode === 'auto-fill') {
                    rows.push(h(ResponsiveInput, {
                        key: 'grid-min', label: 'Minimum Column Width', value: gridColumnMinWidth(template), inherited: inherited('gridTemplateColumns'),
                        onChange: (v) => props.patchStyle('gridTemplateColumns', 'repeat(' + columnMode + ',minmax(' + (v || '240px') + ',1fr))')
                    }));
                }
                const rowsMode = gridRowMode(value('gridTemplateRows', 'none'));
                rows.push(h(LabeledSelect, {
                    key: 'grid-rows', label: 'Explicit Rows', value: rowsMode,
                    options: [{ value: 'auto', label: 'Automatic' }, '1', '2', '3', '4', '5', '6'],
                    onChange: (v) => props.patchStyle('gridTemplateRows', v === 'auto' ? 'none' : 'repeat(' + v + ',auto)')
                }));
                rows.push(h(ResponsiveInput, { key: 'col-gap', label: 'Column Gap', value: value('columnGap', value('gap', '16px')), inherited: inherited('columnGap'), onChange: (v) => props.patchStyle('columnGap', v) }));
                rows.push(h(ResponsiveInput, { key: 'row-gap', label: 'Row Gap', value: value('rowGap', value('gap', '16px')), inherited: inherited('rowGap'), onChange: (v) => props.patchStyle('rowGap', v) }));
                rows.push(h(LabeledSelect, { key: 'grid-flow', label: 'Auto Flow', value: value('gridAutoFlow', 'row'), options: [{ value: 'row', label: 'Row' }, { value: 'column', label: 'Column' }, { value: 'row dense', label: 'Row Dense' }, { value: 'column dense', label: 'Column Dense' }], onChange: (v) => props.patchStyle('gridAutoFlow', v) }));
                rows.push(h(LabeledSelect, { key: 'grid-align', label: 'Align Items', value: value('alignItems', 'stretch'), options: ['stretch', 'flex-start', 'center', 'flex-end', 'baseline'], onChange: (v) => props.patchStyle('alignItems', v) }));
            } else {
                rows.push(h(LabeledSelect, { key: 'direction', label: 'Direction', value: value('flexDirection', 'column'), options: ['row', 'column', 'row-reverse', 'column-reverse'], onChange: (v) => props.patchStyle('flexDirection', v) }));
                rows.push(h(LabeledSelect, { key: 'justify', label: 'Justify', value: value('justifyContent', 'flex-start'), options: ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'], onChange: (v) => props.patchStyle('justifyContent', v) }));
                rows.push(h(LabeledSelect, { key: 'align', label: 'Align', value: value('alignItems', 'stretch'), options: ['stretch', 'flex-start', 'center', 'flex-end', 'baseline'], onChange: (v) => props.patchStyle('alignItems', v) }));
                rows.push(h(ResponsiveInput, { key: 'gap', label: 'Gap', value: value('gap', '16px'), inherited: inherited('gap'), onChange: (v) => props.patchStyle('gap', v) }));
            }
            rows.push(h(LabeledSelect, { key: 'overflow', label: 'Overflow', value: value('overflow', 'visible'), options: ['visible', 'hidden', 'auto', 'scroll', 'clip'], onChange: (v) => props.patchStyle('overflow', v) }));
        }

        rows.push(h(SectionTitle, { key: 'size-title' }, 'Sizing'));
        rows.push(h(ResponsiveInput, { key: 'width', label: 'Width', value: value('width', 'auto'), inherited: inherited('width'), onChange: (v) => props.patchStyle('width', v) }));
        rows.push(h(ResponsiveInput, { key: 'minwidth', label: 'Min Width', value: value('minWidth', ''), inherited: inherited('minWidth'), onChange: (v) => props.patchStyle('minWidth', v) }));
        rows.push(h(ResponsiveInput, { key: 'maxwidth', label: 'Max Width', value: value('maxWidth', ''), inherited: inherited('maxWidth'), onChange: (v) => props.patchStyle('maxWidth', v) }));
        rows.push(h(ResponsiveInput, { key: 'height', label: 'Height', value: value('height', ''), inherited: inherited('height'), onChange: (v) => props.patchStyle('height', v) }));
        rows.push(h(ResponsiveInput, { key: 'minheight', label: 'Min Height', value: value('minHeight', ''), inherited: inherited('minHeight'), onChange: (v) => props.patchStyle('minHeight', v) }));
        rows.push(h(ResponsiveInput, { key: 'maxheight', label: 'Max Height', value: value('maxHeight', ''), inherited: inherited('maxHeight'), onChange: (v) => props.patchStyle('maxHeight', v) }));

        rows.push(h(SpacingGrid, { key: 'margin', title: 'Margin', prefix: 'margin', value, inherited, patchStyle: props.patchStyle }));
        if (CONTAINER_TYPES.includes(node.type) || node.type === 'button') {
            rows.push(h(SpacingGrid, { key: 'padding', title: 'Padding', prefix: 'padding', value, inherited, patchStyle: props.patchStyle }));
        }

        rows.push(h(SectionTitle, { key: 'position-title' }, 'Position'));
        const position = value('position', 'static');
        rows.push(h(LabeledSelect, { key: 'position', label: 'Position', value: position, options: [{ value: 'static', label: 'Normal (Static)' }, 'relative', 'absolute', 'fixed', 'sticky'], onChange: (v) => props.patchStyle('position', v) }));
        if (position !== 'static') {
            rows.push(h(ResponsiveInput, { key: 'top', label: 'Top', value: value('top', 'auto'), inherited: inherited('top'), onChange: (v) => props.patchStyle('top', v) }));
            rows.push(h(ResponsiveInput, { key: 'right', label: 'Right', value: value('right', 'auto'), inherited: inherited('right'), onChange: (v) => props.patchStyle('right', v) }));
            rows.push(h(ResponsiveInput, { key: 'bottom', label: 'Bottom', value: value('bottom', 'auto'), inherited: inherited('bottom'), onChange: (v) => props.patchStyle('bottom', v) }));
            rows.push(h(ResponsiveInput, { key: 'left', label: 'Left', value: value('left', 'auto'), inherited: inherited('left'), onChange: (v) => props.patchStyle('left', v) }));
        }
        rows.push(h(ResponsiveInput, { key: 'zindex', label: 'Z-Index', value: value('zIndex', ''), inherited: inherited('zIndex'), onChange: (v) => props.patchStyle('zIndex', v) }));

        if (node.type === 'image') {
            rows.push(h(SectionTitle, { key: 'image-style-title' }, 'Image'));
            rows.push(h(LabeledSelect, { key: 'object-fit', label: 'Object Fit', value: value('objectFit', 'cover'), options: ['cover', 'contain', 'fill', 'none', 'scale-down'], onChange: (v) => props.patchStyle('objectFit', v) }));
            rows.push(h(LabeledSelect, { key: 'object-position', label: 'Object Position', value: value('objectPosition', 'center center'), options: [
                { value: 'center center', label: 'Center' }, { value: 'center top', label: 'Top' }, { value: 'center bottom', label: 'Bottom' },
                { value: 'left center', label: 'Left' }, { value: 'right center', label: 'Right' },
                { value: 'left top', label: 'Top Left' }, { value: 'right top', label: 'Top Right' },
                { value: 'left bottom', label: 'Bottom Left' }, { value: 'right bottom', label: 'Bottom Right' }
            ], onChange: (v) => props.patchStyle('objectPosition', v) }));
            rows.push(h(ResponsiveInput, { key: 'aspect-ratio', label: 'Aspect Ratio (e.g. 16 / 9 or auto)', value: value('aspectRatio', 'auto'), inherited: inherited('aspectRatio'), onChange: (v) => props.patchStyle('aspectRatio', v) }));
        }

        if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
            rows.push(h(SectionTitle, { key: 'type-title' }, 'Typography'));
            rows.push(h(ResponsiveInput, { key: 'fontsize', label: 'Font Size', value: value('fontSize', '16px'), inherited: inherited('fontSize'), onChange: (v) => props.patchStyle('fontSize', v) }));
            rows.push(h(LabeledSelect, { key: 'weight', label: 'Font Weight', value: value('fontWeight', node.type === 'button' ? '600' : '400'), options: ['300', '400', '500', '600', '700', '800', '900'], onChange: (v) => props.patchStyle('fontWeight', v) }));
            rows.push(h(LabeledSelect, { key: 'aligntext', label: 'Text Align', value: value('textAlign', 'left'), options: ['left', 'center', 'right', 'justify'], onChange: (v) => props.patchStyle('textAlign', v) }));
            rows.push(h(ColorField, { key: 'color', label: 'Text Color', value: value('color', '#111111'), onChange: (v) => props.patchStyle('color', v) }));
        }

        if (CONTAINER_TYPES.includes(node.type)) {
            rows.push(h(SectionTitle, { key: 'background-title' }, 'Background'));
            const fallbackBackgroundType = value('backgroundColor', '') && value('backgroundColor', '') !== 'transparent' ? 'color' : 'none';
            const backgroundType = value('backgroundType', fallbackBackgroundType);
            const backgroundUrl = value('backgroundImageUrl', 'none');
            rows.push(h(LabeledSelect, {
                key: 'background-type', label: 'Type', value: backgroundType,
                options: [{ value: 'none', label: 'None' }, { value: 'color', label: 'Color' }, { value: 'image', label: 'Image' }],
                onChange: (v) => {
                    if (v === 'none') props.patchStyles({ backgroundType: 'none', backgroundImageId: 0, backgroundImageUrl: 'none' });
                    else if (v === 'color') props.patchStyles({ backgroundType: 'color', backgroundImageId: 0, backgroundImageUrl: 'none', backgroundColor: value('backgroundColor', '#ffffff') === 'transparent' ? '#ffffff' : value('backgroundColor', '#ffffff') });
                    else props.patchStyles(Object.assign({ backgroundType: 'image' }, {
                        backgroundSize: value('backgroundSize', BACKGROUND_IMAGE_DEFAULTS.backgroundSize),
                        backgroundPosition: value('backgroundPosition', BACKGROUND_IMAGE_DEFAULTS.backgroundPosition),
                        backgroundRepeat: value('backgroundRepeat', BACKGROUND_IMAGE_DEFAULTS.backgroundRepeat),
                        backgroundAttachment: value('backgroundAttachment', BACKGROUND_IMAGE_DEFAULTS.backgroundAttachment)
                    }));
                }
            }));
            if (backgroundType === 'color' || backgroundType === 'image') {
                rows.push(h(ColorField, { key: 'bg-color', label: backgroundType === 'image' ? 'Fallback Color' : 'Color', value: value('backgroundColor', backgroundType === 'image' ? 'transparent' : '#ffffff'), onChange: (v) => props.patchStyle('backgroundColor', v) }));
            }
            if (backgroundType === 'image') {
                rows.push(h('div', { className: 'scfvb-media-row scfvb-background-media', key: 'background-media' },
                    backgroundUrl && backgroundUrl !== 'none'
                        ? h('img', { src: backgroundUrl, alt: '' })
                        : h('div', { className: 'scfvb-media-empty' }, 'No background image'),
                    h('div', { className: 'scfvb-media-actions' },
                        h(Button, { variant: 'secondary', onClick: () => chooseMediaImage('Select background image', (item) => props.patchStyles({
                            backgroundType: 'image', backgroundImageId: item.id, backgroundImageUrl: item.url,
                            backgroundSize: value('backgroundSize', BACKGROUND_IMAGE_DEFAULTS.backgroundSize),
                            backgroundPosition: value('backgroundPosition', BACKGROUND_IMAGE_DEFAULTS.backgroundPosition),
                            backgroundRepeat: value('backgroundRepeat', BACKGROUND_IMAGE_DEFAULTS.backgroundRepeat),
                            backgroundAttachment: value('backgroundAttachment', BACKGROUND_IMAGE_DEFAULTS.backgroundAttachment)
                        })) }, 'Choose Image'),
                        backgroundUrl && backgroundUrl !== 'none' && h(Button, { variant: 'tertiary', isDestructive: true, onClick: () => props.patchStyles({ backgroundType: 'none', backgroundImageId: 0, backgroundImageUrl: 'none' }) }, 'Remove')
                    )
                ));
                rows.push(h(LabeledSelect, { key: 'bg-size', label: 'Size', value: value('backgroundSize', 'cover'), options: ['cover', 'contain', 'auto'], onChange: (v) => props.patchStyle('backgroundSize', v) }));
                rows.push(h(LabeledSelect, { key: 'bg-position', label: 'Position', value: value('backgroundPosition', 'center center'), options: [
                    { value: 'center center', label: 'Center' }, { value: 'center top', label: 'Top' }, { value: 'center bottom', label: 'Bottom' },
                    { value: 'left center', label: 'Left' }, { value: 'right center', label: 'Right' },
                    { value: 'left top', label: 'Top Left' }, { value: 'right top', label: 'Top Right' },
                    { value: 'left bottom', label: 'Bottom Left' }, { value: 'right bottom', label: 'Bottom Right' }
                ], onChange: (v) => props.patchStyle('backgroundPosition', v) }));
                rows.push(h(LabeledSelect, { key: 'bg-repeat', label: 'Repeat', value: value('backgroundRepeat', 'no-repeat'), options: ['no-repeat', 'repeat', 'repeat-x', 'repeat-y'], onChange: (v) => props.patchStyle('backgroundRepeat', v) }));
                rows.push(h(LabeledSelect, { key: 'bg-attachment', label: 'Attachment', value: value('backgroundAttachment', 'scroll'), options: ['scroll', 'fixed', 'local'], onChange: (v) => props.patchStyle('backgroundAttachment', v) }));
            }
        } else if (node.type === 'button') {
            rows.push(h(SectionTitle, { key: 'background-title' }, 'Background'));
            rows.push(h(ColorField, { key: 'bg', label: 'Background Color', value: value('backgroundColor', '#111111'), onChange: (v) => props.patchStyle('backgroundColor', v) }));
        }

        if (node.type === 'image' || node.type === 'button' || CONTAINER_TYPES.includes(node.type)) {
            rows.push(h(SectionTitle, { key: 'border-title' }, 'Border'));
            rows.push(h(ResponsiveInput, { key: 'radius', label: 'Border Radius', value: value('borderRadius', '0px'), inherited: inherited('borderRadius'), onChange: (v) => props.patchStyle('borderRadius', v) }));
            rows.push(h(ResponsiveInput, { key: 'borderwidth', label: 'Border Width', value: value('borderWidth', '0px'), inherited: inherited('borderWidth'), onChange: (v) => props.patchStyle('borderWidth', v) }));
            rows.push(h(ColorField, { key: 'bordercolor', label: 'Border Color', value: value('borderColor', '#dddddd'), onChange: (v) => props.patchStyle('borderColor', v) }));
        }

        return h(Fragment, null, rows);
    }

    function ResponsiveInput(props) {
        return h('label', { className: 'scfvb-field' + (props.inherited ? ' is-inherited' : '') },
            h('span', null, props.label, props.inherited && h('em', null, ' inherited')),
            h('input', { type: 'text', value: props.value == null ? '' : props.value, onChange: (e) => props.onChange(e.target.value) })
        );
    }

    function SpacingGrid(props) {
        return h('div', { className: 'scfvb-spacing-grid' },
            h('span', { className: 'scfvb-spacing-title' }, props.title),
            ['Top', 'Right', 'Bottom', 'Left'].map((side) => {
                const key = props.prefix + side;
                return h('label', { key, className: props.inherited(key) ? 'is-inherited' : '' },
                    h('span', null, side.charAt(0)),
                    h('input', { type: 'text', value: props.value(key, '0px'), title: side, onChange: (e) => props.patchStyle(key, e.target.value) })
                );
            })
        );
    }

    function ColorField(props) {
        const raw = String(props.value || '');
        let safe = '#000000';
        if (/^#[0-9a-fA-F]{6}$/.test(raw)) safe = raw;
        else if (/^#[0-9a-fA-F]{8}$/.test(raw)) safe = raw.slice(0, 7);
        else if (/^#[0-9a-fA-F]{3,4}$/.test(raw)) {
            const rgb = raw.slice(1, 4).split('').map((char) => char + char).join('');
            safe = '#' + rgb;
        }
        return h('label', { className: 'scfvb-field scfvb-color-field' },
            h('span', null, props.label),
            h('div', null,
                h('input', { type: 'color', value: safe, onChange: (e) => props.onChange(e.target.value) }),
                h('input', { type: 'text', value: props.value || '', onChange: (e) => props.onChange(e.target.value) })
            )
        );
    }

    const root = document.getElementById('scfvb-editor-root');
    if (root) {
        if (wp.element.createRoot) wp.element.createRoot(root).render(h(App));
        else wp.element.render(h(App), root);
    }
}());
