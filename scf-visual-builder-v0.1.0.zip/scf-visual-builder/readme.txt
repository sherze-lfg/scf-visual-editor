=== SCF Visual Builder ===
Contributors: openai
Tags: secure custom fields, scf, page builder, visual builder, custom fields
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 0.1.0
License: GPLv2 or later

A schema-aware visual page builder integrated with Secure Custom Fields.

== Description ==

SCF Visual Builder v0.1 provides a visual editor for WordPress Pages with:

* Section and Container layout nodes
* Heading, Text, Image, and Button content nodes
* Nested tree editing and drag-to-reparent
* Basic flexbox styling
* Desktop, tablet, and mobile style overrides
* Undo and redo
* JSON layout persistence in page post meta
* Static or Secure Custom Fields-backed content
* Automatic SCF local field group registration
* Safe field-name migration for existing SCF-bound values
* Frontend rendering through the normal WordPress page content area

Secure Custom Fields is required only for Editable field bindings. Static content can still be built without it.

== Installation ==

1. Install and activate Secure Custom Fields.
2. Upload and activate SCF Visual Builder.
3. Go to Pages.
4. Hover a page and click "Edit with Visual Builder".
5. Add a Section, add a Container inside it, then add content elements.
6. Mark content as "Editable with SCF" when you want structured WordPress content.
7. Save the builder layout.
8. Click "Edit SCF Content" to edit generated SCF fields on the normal WordPress page screen.

== Changelog ==

= 0.1.0 =
* Initial MVP.
